# MetropolisJS: Seamless Frontend-Backend Integration Framework

<p align="center">
  <img src="https://raw.githubusercontent.com/nitrogenlabs/metropolisjs/main/docs/assets/metropolisjs-mark.svg" alt="MetropolisJS winged V logo" width="432">
</p>

> **The Ultimate Frontend Integration Library for Modern Web Applications**

[![npm version](https://img.shields.io/npm/v/@nlabs/metropolisjs.svg?style=flat-square)](https://www.npmjs.com/package/@nlabs/metropolisjs)
[![npm downloads](https://img.shields.io/npm/dm/@nlabs/metropolisjs.svg?style=flat-square)](https://www.npmjs.com/package/@nlabs/metropolisjs)
[![Documentation](https://img.shields.io/badge/docs-metropolisjs.nitrogenx.co-6d28d9?style=flat-square)](https://metropolisjs.nitrogenx.co)
[![Issues](http://img.shields.io/github/issues/nitrogenlabs/metropolisjs.svg?style=flat-square)](https://github.com/nitrogenlabs/metropolisjs/issues)
[![TypeScript](https://badges.frapsoft.com/typescript/version/typescript-next.svg?v=101)](https://github.com/ellerbrock/typescript-badges/)
[![MIT license](http://img.shields.io/badge/license-MIT-brightgreen.svg?style=flat-square)](http://opensource.org/licenses/MIT)
[![Chat](https://img.shields.io/discord/446122412715802649.svg)](https://discord.gg/Ttgev58)

MetropolisJS is the bridge that connects your frontend dreams to backend reality. Built on the powerful combination of **Reaktor** (backend services) and **ArkhamJS** (frontend data store), MetropolisJS provides a seamless, real-time integration layer that handles everything from user authentication to real-time messaging and notifications.

## Opaque browser sessions

`createWebSessionActions` is exported from the public root and `/actions`; `useWebSessionActions` is exported from the root. Pass `webSession` to `Metropolis` to use Reaktor's same-origin HttpOnly cookie profile. `onInit(flux, webSession)` supports non-React boot. The root, hook, and factory share one binding per Flux instance; conflicting scope, endpoint, or preservation callback bindings are rejected.

```tsx
const webSession: WebSessionOptions = {
  endpoints: {
    activity: '/auth/activity', restore: '/auth/session',
    signIn: '/auth/signin', signOut: '/auth/signout'
  },
  onBeforeSessionClear: (reason, previous, scope) => {
    // Capture a product draft in volatile owner-scoped state, if needed.
    // Recovery requires a newly verified app/environment/owner match.
  },
  scope: {appId: 'vault', environment: 'production', ownerUserId: 'configured-owner'}
};

<Metropolis webSession={webSession}><Editor /></Metropolis>;
```

Call `signIn({email, password})` or `signIn({username, password})` for explicit credential admission. The `username` form accepts a username or email through Reaktor; supply exactly one identifier. Credentials are captured for this attempt and never stored in session state. Call `restore()` for read-only verification, `ensureSession()` before private work, and `recordActivity()` only for actual user input. Focus, visibility, polling, reload, API reads, and timers never POST activity. Input arriving while a touch is pending receives another accepted server touch. Database `observedAt`/`idleExpiresAt` define the budget; monotonic full round-trip elapsed time can only reduce it. Local deadline and foreground checks revalidate read-only. Unavailable verification blocks private work without reporting confirmed logout.

Authenticated REST (`authenticate: true`) and GraphQL calls preflight this runtime, omit bearer credentials, reject denied sessions, and fence responses before cache ingestion. Cookie requests use Rip-Hunter with explicit same-origin credentials, JSON/CSRF POSTs, and no offline queue or mutation replay. Endpoints must be same-origin URLs; browsers supply Origin/Referer/Fetch Metadata. No cookie secret, password, draft, or token is stored in `webSession` state.

Private API failures invalidate the cookie session only for HTTP 401 or explicit `invalid_session` / `expired_session` error codes. Ordinary domain failures (including HTTP 400, 403, and 405) reject the original error without invoking success/ingestion, replaying the request, or changing the verified identity, private cache, or idle deadline. They do not record activity. Authentication endpoint verification keeps its own admission policy; stale request generations are rejected before classifying API errors.

Session endpoints use Rip-Hunter's public `/http` default native browser binding with a finite 30,000ms request/body deadline. Cookie mutations serialize per Flux, including genuine disposal/rebinding; queued superseded credential work is fenced before dispatch. This contract requires native browser fetch cancellation (qualified in Chromium and WebKit), not a custom/polyfilled fetch that ignores AbortSignal. A canceled mutation has an unknown server outcome and is never automatically replayed; cancellation is not server rollback. Older accepted activity still proves that touch succeeded, but cannot replace a newer verified same-session identity/deadline or clear its private caches. This is not cross-tab coordination.

`signOut()` returns `{remote: 'revoked' | 'unknown'}` and blocks admission before remote cleanup. A dedicated Arkham Flux with the public synchronous browser adapter persists an app/environment/owner-scoped, nonexpiring local suppression marker before `WEB_SESSION_SIGNED_OUT`; only successful explicit credential sign-in clears it. Failed writes report `marker_persistence`. Identity/status state precedes `WEB_SESSION_AUTHENTICATED` listeners. The volatile preservation callback runs synchronously before account caches clear; failure cannot prevent invalidation and reports `preservation_failed`. Disposal releases local timers/listeners and fences pending work without remote logout, including React effect replay.

The mounted root dispatches `APP_CONSTANTS.SESSION_HYDRATION_STARTED` and `APP_CONSTANTS.SESSION_HYDRATION_COMPLETED` with only `{type}`, after committing `app.sessionHydrated` to `false` and `true`, respectively. The public app reducer handles these actions too; the root commits explicitly to preserve consumers' pre-registered app reducers. Completion includes authenticated, anonymous, suppressed and blocked cookie restoration; it reports that initialization settled and grants no session privileges. Consumers can observe both this flag and `webSession.status` through public `useFluxState`. A genuine configuration change starts hydration again; stale or unmounted effects do not complete it. A failed cookie verification also emits `WEB_SESSION_CONSTANTS.BLOCKED` with `{scope, type}` after committing blocked state, including verification failures after startup. This notification retains existing identity metadata and does not authenticate or sign out the user.

Adoption requires compatible published packages and product editor/draft/private-asset browser acceptance. Client generation fences cannot stop browsers applying a late response's `Set-Cookie`: read-only/private authorization failures must not clear a newer session cookie. The retained Reaktor 1.20.0 candidate still has that cross-request race and is insufficient for adoption by itself.

## Why MetropolisJS?

### **Seamless Integration**

Connect your React frontend to Reaktor-powered backend services with zero configuration headaches. MetropolisJS handles all the complex data flow, state management, and real-time communication.

### **Real-Time Everything**

Built-in WebSocket and Server-Sent Events (SSE) support for instant messaging, live notifications, and real-time data synchronization. Your users will never miss a beat.

### **Type-Safe & Reliable**

Full TypeScript support with comprehensive type definitions. Catch errors at compile time, not runtime.

### **Developer Experience First**

Clean, intuitive APIs that make complex operations feel simple. Focus on building features, not boilerplate.

## What Can You Build?
MetropolisJS powers applications that need:

- **User Authentication & Authorization**
- **Role-Based Access Control (RBAC)** with 5-level permission system
- **Real-Time Messaging Systems**
- **Live Notifications**
- **Social Media Features** (posts, reactions, tags)
- **Location-Based Services**
- **Media Management** (images, files)
- **Event Management**
- **User Connections & Relationships**

## Quick Start

### Installation

```bash
npm install @nlabs/metropolisjs @nlabs/arkhamjs @nlabs/arkhamjs-utils-react
```

### Basic Setup

```tsx
import {Metropolis, useUserActions, useMessageActions, useRestActions, useWebsocketActions} from '@nlabs/metropolisjs';

const App = () => {
  return (
    <Metropolis config={{
      development: {
        environment: 'development',
        app: {
          api: {
            url: 'http://localhost:3000/app',
            public: 'http://localhost:3000/public'
          }
        }
      }
    }}>
      <YourApp />
    </Metropolis>
  );
};

const YourApp = () => {
  // Use specialized hooks for better performance
  const userActions = useUserActions();
  const messageActions = useMessageActions();
  const websocketActions = useWebsocketActions();

  // Start building amazing features!
  return <div>Your app content</div>;
};
```

### Using Actions

MetropolisJS provides multiple ways to access actions:

```tsx
// Option 1: Specialized hooks (recommended - best performance)
const userActions = useUserActions();
const postActions = usePostActions();
const restActions = useRestActions();

// Option 2: Selective creation
const {userActions, postActions, restActions} = useMetropolis(['user', 'post', 'rest']);

// Option 3: Create an explicit action group
const {messageActions} = useMetropolis(['message']);
```

### External REST Endpoints

MetropolisJS includes a `rest` action group for APIs that are not part of Reaktor. It delegates to `@nlabs/rip-hunter`, so app code can keep using Metropolis actions instead of importing rip-hunter directly.

```tsx
<Metropolis
  config={{
    development: {
      app: {
        api: {
          endpoints: {
            weather: 'https://api.example.com/weather'
          },
          public: 'http://localhost:3000/public',
          url: 'http://localhost:3000/app'
        }
      }
    }
  }}
>
  <YourApp />
</Metropolis>

const WeatherPanel = () => {
  const restActions = useRestActions();

  const loadWeather = async () => {
    const weather = await restActions.get('weather', {zip: '60601'}, {cache: true});
    return weather;
  };
};
```

Use `authenticate: true` when an external endpoint should receive the current Metropolis session token:

```tsx
const profile = await restActions.request(
  'https://api.example.com/profile',
  'PATCH',
  {displayName: 'Ada'},
  {authenticate: true}
);
```

## Configuration

The `Metropolis` component accepts three main props: `config`, `adapters`, and `translations`. Here's how to configure each:

### RUM analytics

Configure the public analytics identifier returned by Reaktor under `app.rum.analyticsId` and the collection endpoint under `app.api.endpoints.rum`. MetropolisJS sends the identifier in the JSON batch body; it is not placed in the URL or an authorization header.

```tsx
<Metropolis
  config={{
    production: {
      app: {
        name: 'My App',
        api: {
          endpoints: {
            rum: 'https://events.example.com/track'
          }
        },
        rum: {
          analyticsId: '00000000-0000-4000-8000-000000000000',
          analyticsTransport: 'graphql',
          debounceMs: 250,
          dedupeMs: 1000,
          enabled: true,
          respectPrivacySignals: true,
          throttleMs: 1000
        }
      }
    }
  }}>
  <YourApp />
</Metropolis>
```

Configure the endpoint at `app.api.endpoints.rum`. RUM delivery is unauthenticated and each batch contains `analyticsId` and up to 50 sanitized events.

#### Delivery transport

`app.rum.analyticsTransport` selects how batches leave the client:

- `graphql` (default) — sends batches with the normal RUM request, matching the beacon fallback described below.
- `websocket` — sends batches over the shared Metropolis websocket connection instead, using the same `wsSend` queue as notifications and typing indicators. Requires `app.urls.websocket` to be configured; batches queue until the connection opens rather than falling back per flush.

#### Beacon delivery

When the page is hidden or receives `pagehide`, the `Metropolis` provider automatically flushes pending RUM events with `navigator.sendBeacon()`. This gives terminal analytics a chance to finish without delaying navigation or page shutdown.

Beacon delivery is best-effort:

- If `navigator.sendBeacon` is unavailable, throws, or declines the payload, MetropolisJS immediately falls back to its normal asynchronous RUM request.
- A batch accepted by `sendBeacon` is not sent again through the normal request path.
- Scheduled and explicit `flush()` calls continue to use the normal request path unless `useBeacon` is requested.
- Privacy signals and the `enabled` option are respected for both delivery paths.

Use the specialized hook when an application needs to track or flush events directly:

```tsx
import {useAwsRum} from '@nlabs/metropolisjs';

const SaveButton = () => {
  const rum = useAwsRum();

  const onSave = () => {
    rum.track({
      name: 'settings_saved',
      path: '/settings',
      properties: {section: 'profile'},
      type: 'click'
    });
  };

  return <button onClick={onSave}>Save</button>;
};
```

For an application-controlled terminal flush, request beacon delivery explicitly:

```ts
await rum.flush({useBeacon: true});
```

Calling `flush({useBeacon: true})` is safe in non-browser environments and older browsers because it falls back to the normal RUM request when the Beacon API cannot be used.

### Configuration Object

The `config` prop accepts a `MetropolisConfiguration` object that supports environment-specific settings:

```tsx
<Metropolis
  config={{
    // Environment-specific configurations
    development: {
      environment: 'development',
      app: {
        api: {
          url: 'http://localhost:3000/app',
          public: 'http://localhost:3000/public',
          uploadImage: 'http://localhost:3000/upload'
        },
        urls: {
          websocket: 'ws://localhost:3000'
        },
        session: {
          maxMinutes: 1440, // 24 hours
          minMinutes: 15
        },
        name: 'My App',
        version: '1.0.0'
      },
      isAuth: () => {
        // Custom authentication check
        const session = flux.getState('user.session', {});
        return !!session.userActive;
      }
    },
    production: {
      environment: 'production',
      app: {
        api: {
          url: 'https://api.example.com/app',
          public: 'https://api.example.com/public',
          uploadImage: 'https://api.example.com/upload'
        },
        urls: {
          websocket: 'wss://api.example.com'
        },
        session: {
          maxMinutes: 2880, // 48 hours
          minMinutes: 30
        }
      }
    }
  }}
>
  <YourApp />
</Metropolis>
```

#### Configuration Options

**Environment Configuration** (`MetropolisEnvironmentConfiguration`):
- `environment`: `'development' | 'production' | 'test' | 'local'` - Current environment
- `app`: Application-specific configuration
  - `api`: API endpoint configuration
    - `endpoints`: Named external REST endpoints for `restActions`
    - `url`: Main API endpoint
    - `public`: Public API endpoint
    - `uploadImage`: Image upload endpoint
  - `urls`: Additional URL configurations
    - `websocket`: WebSocket server URL
  - `session`: Session management settings
    - `maxMinutes`: Maximum session duration in minutes
    - `minMinutes`: Minimum session duration in minutes
  - `name`: Application name
  - `version`: Application version
- `isAuth`: Function that returns a boolean indicating if the user is authenticated
- `adapters`: Custom adapters (can also be passed as a separate prop)

### Custom Adapters

Pass custom adapters to override default data transformation behavior:

```tsx
import {parseUser, parseMessage} from '@nlabs/metropolisjs';

<Metropolis
  adapters={{
    User: parseUser,
    Message: parseMessage,
    // Add other custom adapters as needed
    Content: customContentAdapter,
    Event: customEventAdapter,
    Image: customImageAdapter,
    Location: customLocationAdapter,
    Post: customPostAdapter,
    Persona: customPersonaAdapter,
    Reaction: customReactionAdapter,
    Tag: customTagAdapter,
    Translation: customTranslationAdapter
  }}
>
  <YourApp />
</Metropolis>
```

### Translations

MetropolisJS supports both simple and complex translation formats:

#### Simple Translations

```tsx
<Metropolis
  translations={{
    'welcome': 'Welcome to MetropolisJS!',
    'save': 'Save',
    'cancel': 'Cancel',
    'hello_user': 'Hello {{name}}!',
    'items_count': 'You have {{count}} items'
  }}
>
  <YourApp />
</Metropolis>
```

#### Complex Translations (with locale and namespace)

```tsx
<Metropolis
  translations={{
    'welcome': {
      value: 'Welcome to MetropolisJS!',
      locale: 'en',
      namespace: 'common'
    },
    'save': {
      value: 'Save',
      locale: 'en',
      namespace: 'actions'
    }
  }}
>
  <YourApp />
</Metropolis>
```

### Complete Configuration Example

```tsx
import {Metropolis} from '@nlabs/metropolisjs';
import {parseUser, parseMessage} from '@nlabs/metropolisjs';

const App = () => {
  return (
    <Metropolis
      config={{
        development: {
          environment: 'development',
          app: {
            api: {
              url: 'http://localhost:3000/app',
              public: 'http://localhost:3000/public'
            },
            urls: {
              websocket: 'ws://localhost:3000'
            },
            session: {
              maxMinutes: 1440,
              minMinutes: 15
            }
          },
          isAuth: () => {
            // Your custom auth logic
            return true;
          }
        },
        production: {
          environment: 'production',
          app: {
            api: {
              url: 'https://api.example.com/app',
              public: 'https://api.example.com/public'
            },
            urls: {
              websocket: 'wss://api.example.com'
            }
          }
        }
      }}
      adapters={{
        User: parseUser,
        Message: parseMessage
      }}
      translations={{
        'welcome': 'Welcome!',
        'save': 'Save',
        'cancel': 'Cancel'
      }}
    >
      <YourApp />
    </Metropolis>
  );
};
```

### Environment Detection

MetropolisJS automatically detects the environment based on:

1. The `environment` property in your config
2. `process.env.stage` (if set)
3. `process.env.NODE_ENV` (fallback)
4. Defaults to `'local'` if none are set

The configuration system will merge environment-specific settings with default values, allowing you to override only what you need.

### User Authentication Example

```tsx
import {useUserActions} from '@nlabs/metropolisjs';

const LoginForm = () => {
  const userActions = useUserActions(); // Specialized hook - only creates user actions
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      const session = await userActions.signIn({password, username});
      console.log('User logged in successfully!', session);
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  return (
    <form onSubmit={handleLogin}>
      <input
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        placeholder="Username"
      />
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
      />
      <button type="submit">Sign In</button>
    </form>
  );
};
```

### Billing Setup Sessions

Billing cards are collected through a hosted setup session, so raw card details never pass through application code. Start the flow with an authenticated user action and redirect the browser to the returned checkout URL:

```tsx
import {useUserActions} from '@nlabs/metropolisjs';

const AddBillingCardButton = () => {
  const userActions = useUserActions();

  const addBillingCard = async () => {
    const returnUrl = `${window.location.origin}/settings/billing/complete`;
    const checkoutUrl = await userActions.createBillingSetupSession(returnUrl);
    window.location.assign(checkoutUrl);
  };

  return <button onClick={addBillingCard}>Add billing card</button>;
};
```

On the return page, read the provider's setup-session identifier and complete the flow. The action returns the updated user, refreshes the matching session data, dispatches the standard user update event, and clears related user request caches:

```tsx
const sessionId = new URLSearchParams(window.location.search).get('session_id');

if(sessionId) {
  const user = await userActions.completeBillingSetupSession(sessionId, [
    'stripeCardBrand',
    'stripeCardLast4'
  ]);
}
```

Use `deleteBillingCard()` to remove the saved billing method. Both completion and deletion return sanitized billing metadata; MetropolisJS does not accept raw card numbers or tokens.

### Real-Time Messaging

```tsx
import {useMessageActions, useWebsocketActions} from '@nlabs/metropolisjs';

const ChatComponent = () => {
  const messageActions = useMessageActions();
  const websocketActions = useWebsocketActions();
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    // Initialize WebSocket connection
    websocketActions.wsInit();

    // Load existing messages
    messageActions.list().then(setMessages);
  }, []);

  const sendMessage = async (content) => {
    await messageActions.add({ content });
    // Message automatically appears in real-time for all connected users!
  };

  return (
    <div>
      {messages.map(message => (
        <div key={message.messageId}>{message.content}</div>
      ))}
      <button onClick={() => sendMessage('Hello World!')}>
        Send Message
      </button>
    </div>
  );
};
```

## Architecture

MetropolisJS sits between React and your services. The provider supplies configuration and action access, adapters keep data typed, Rip-Hunter handles transport, and ArkhamJS keeps application state reactive.

<p align="center">
  <img src="https://raw.githubusercontent.com/nitrogenlabs/metropolisjs/main/docs/assets/metropolisjs-architecture.png" alt="MetropolisJS architecture showing React components, the provider and hooks, actions, adapters, ArkhamJS state, Rip-Hunter transport, Reaktor services, and real-time updates" width="960">
</p>

### Core Components

- **Actions**: Handle all API interactions and business logic (factory pattern)
- **Adapters**: Transform data between frontend and backend formats
- **Stores**: Manage application state with ArkhamJS
- **WebSocket Actions**: Handle real-time communication
- **Configuration**: Context-based configuration (React best practices)
- **Hooks**: Specialized hooks for accessing actions and configuration

### Request and State Lifecycle

Actions hide the full request lifecycle behind a typed method. They validate inputs, use the request cache when configured, communicate through Rip-Hunter, update the ArkhamJS store, and then dispatch Flux events to subscribers. WebSocket and SSE messages enter the same reactive state flow.

<p align="center">
  <img src="https://raw.githubusercontent.com/nitrogenlabs/metropolisjs/main/docs/assets/metropolisjs-request-lifecycle.svg" alt="Sequence diagram showing a React component calling a MetropolisJS action, input validation and caching, Rip-Hunter transport, a Reaktor response, and an ArkhamJS state update followed by a Flux event" width="960">
</p>

### Cached data and sessions

Metropolis initializes its stores per Flux instance, including after a reload.
Identified response objects merge recursively into canonical domain maps before
success listeners run. Missing or undefined fields preserve existing values;
explicit null clears a field. Arrays replace membership, while partial objects
inside an array merge by ID. Dispatch `replace: true` with a success action to
replace its incoming record instead. `mergeCachedRecord` and its
`CacheIngestionOptions` type are also exported from `@nlabs/metropolisjs/utils`.

Read persistent data through `flux.getState` or `useFluxState`. The configured
Arkham storage adapter hydrates and persists that state. Entity ingestion always
runs; `cacheTimeout` separately controls request reuse. Reused results resolve
against canonical records where available. Image/video item lists and reaction
lists use separate keys so one response cannot replace another query's list.

Authentication reads `user.session.token` at request time. Session patches merge
without losing credentials, and token wrappers update together on rotation.
Temporary refresh failures retain a valid session. Expiry, logout, and a new login
clear prior account caches while retaining app configuration. Responses from a
previous login, including uploads and refreshes, cannot restore its credentials.

Use an ArkhamJS release containing the cache invalidation and immediate-write
fixes with this behavior. Configure `storageWait: 0` if session persistence must
complete before listeners run. Storage choice, inactivity UI monitoring, and
application-specific optimistic rollback remain the application's responsibility.

### Modern Architecture Features

MetropolisJS follows React best practices:

- **Context-Based Configuration**: No global state, configuration through React Context
- **Factory Pattern**: Functional action creation with dependency injection
- **Selective Action Creation**: Only create actions you need for better performance
- **Type Safety**: Full TypeScript support with proper type inference
- **Specialized Hooks**: Individual hooks for each action type
- **Flux State Integration**: Configuration stored in flux state for non-React code access

## Available Actions

MetropolisJS provides comprehensive actions for all your needs. Access them using specialized hooks or `useMetropolis(actionTypes)`:

### Specialized Hooks (Recommended)

- `useAwsRum()` - Analytics tracking, batching, and terminal beacon delivery
- `useUserActions()` - Authentication, personas, user management
- `useMessageActions()` - Real-time messaging and conversations
- `usePermissionActions()` - Permission and role management (RBAC)
- `usePostActions()` - Social media posts and content
- `useReactionActions()` - Likes, reactions, and interactions
- `useTagActions()` - Content categorization and discovery
- `useEventActions()` - Event management and scheduling
- `useImageActions()` - Media upload and management
- `useLocationActions()` - Geolocation and location-based features
- `useWebsocketActions()` - Real-time communication setup
- `useContentActions()` - Content management
- `usePersonaActions()` - Persona management
- `useTranslationActions()` - Translation management

### Using Collection Actions

```tsx
// Recommended: Use specialized hooks (only creates what you need)
const userActions = useUserActions();
const postActions = usePostActions();
const permissionActions = usePermissionActions();

// Alternative: Selective creation
const {userActions, postActions, permissionActions} = useMetropolis(['user', 'post', 'permission']);

// Create every action you use explicitly
const {messageActions, permissionActions} = useMetropolis(['message', 'permission']);
```

## Factory Pattern Guide

MetropolisJS uses a **factory function pattern** for actions. This provides functional composition, straightforward testing, and dependency injection.

### Key Benefits

1. **Functional Programming**: Pure functions instead of classes with side effects
2. **Better Testability**: Easier to mock and test individual functions
3. **Composability**: Actions can be easily combined and extended
4. **Dependency Injection**: Custom adapters can be injected and merged with defaults
### Basic Usage

```typescript
import {createAction, createActions, createUserActions} from '@nlabs/metropolisjs';

const userActions = createUserActions(flux);
const user = await userActions.addUser(userData);

const postActions = createAction('post', flux);
const post = await postActions.add({content: 'Hello!'});

const actions = createActions(['user', 'post', 'message'], flux);
await actions.message.sendMessage({
  content: 'Welcome!',
  recipientId: user.userId
});
```

Factory results preserve their selected types. `createAction('post', flux)` returns `PostActions`, while `createActions(['user', 'post'], flux)` returns only typed `user` and `post` keys. `createAllActions(flux)` returns the complete `ActionMap`.

### Advanced Usage with Custom Adapters

#### Custom Validation Adapter

```typescript
import type {User} from '@nlabs/metropolisjs';

// Custom adapter that extends default behavior
const customUserAdapter = (input: unknown): User => {
  // input is already validated by default adapter
  const user = input as User;

  // Add business-specific validation
  if (user.email && !user.email.includes('@company.com')) {
    throw new Error('Only company emails allowed');
  }

  // Add computed fields
  return {
    ...user,
    fullName: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
    isAdmin: (user.userAccess || 0) >= 3
  };
};

const userActions = createUserActions(flux, {
  userAdapter: customUserAdapter
});
```

#### Configuration-based Adapters

```typescript
const userActions = createUserActions(flux, {
  userAdapterOptions: {
    strict: true,
    environment: 'production',
    customValidation: (input) => {
      // Additional validation logic
      return input;
    }
  }
});
```

#### Runtime Adapter Updates

```typescript
const userActions = createUserActions(flux);

// Update adapter at runtime
userActions.updateUserAdapter(customUserAdapter);

// Update options at runtime
userActions.updateUserAdapterOptions({
  strict: true,
  environment: 'production'
});
```

### Available Factory Functions

All action files now export factory functions:

- `createUserActions(flux, options?)` - User management
- `createPostActions(flux, options?)` - Post management
- `createEventActions(flux, options?)` - Event management
- `createMessageActions(flux, options?)` - Messaging
- `createImageActions(flux, options?)` - Image handling
- `createLocationActions(flux, options?)` - Location services
- `createReactionActions(flux, options?)` - Reactions
- `createTagActions(flux, options?)` - Tag management
- `createWebsocketActions(flux)` - WebSocket connections

### Adapter Options Interface

All adapters support the same options interface:

```typescript
interface AdapterOptions {
  strict?: boolean;                    // Enable strict validation
  allowPartial?: boolean;              // Allow partial data
  environment?: 'development' | 'production' | 'test';
  customValidation?: (input: unknown) => unknown;
}
```

### Using Actions in Components

The recommended approach is to use specialized hooks:

```typescript
// Recommended: Use specialized hooks
import {useUserActions, usePostActions} from '@nlabs/metropolisjs';

const MyComponent = () => {
  const userActions = useUserActions();
  const postActions = usePostActions();
  // ...
};

// Alternative: Use useMetropolis with selective creation
import {useMetropolis} from '@nlabs/metropolisjs';

const MyComponent = () => {
  const {userActions, postActions} = useMetropolis(['user', 'post']);
  // ...
};
```

### Configuration Access

Access configuration using React hooks:

```typescript
import {useMetropolisConfig} from '@nlabs/metropolisjs';

const MyComponent = () => {
  const config = useMetropolisConfig();
  const apiUrl = config.app?.api?.url;
  // ...
};
```

For non-React code (actions, utilities), use:

```typescript
import {getConfigFromFlux} from '@nlabs/metropolisjs';

const config = getConfigFromFlux(flux);
const apiUrl = config.app?.api?.url || '';
```

**Note:** The `Config` class has been removed. Use `useMetropolisConfig()` in React components or `getConfigFromFlux()` in non-React code.

### Testing Examples

#### Unit Testing Actions

```typescript
import {createUserActions, type UserActions} from '@nlabs/metropolisjs';

describe('userActions', () => {
  let flux: FluxFramework;
  let userActions: UserActions;

  beforeEach(() => {
    flux = createMockFlux();
    // Store config in flux state for actions to access
    flux.setState('app.config', {
      app: { api: { url: 'http://localhost:3000/app' } }
    });
    userActions = createUserActions(flux);
  });

  it('should add user with validation', async () => {
    const userData = {username: 'test', email: 'test@example.com'};
    const result = await userActions.addUser(userData);
    expect(result).toBeDefined();
  });
});
```

#### Testing with Custom Adapters

```typescript
const mockAdapter = vi.fn((input) => ({
  ...input,
  validated: true
}));

const userActions = createUserActions(flux, {
  userAdapter: mockAdapter
});

expect(mockAdapter).toHaveBeenCalled();
```

#### Testing React Components

```typescript
import {renderHook} from '@testing-library/react';
import {Metropolis, useUserActions} from '@nlabs/metropolisjs';

describe('useUserActions', () => {
  it('should return user actions', () => {
    const wrapper = ({children}) => (
      <Metropolis config={{development: {app: {api: {url: 'http://localhost'}}}}}>
        {children}
      </Metropolis>
    );

    const {result} = renderHook(() => useUserActions(), {wrapper});
    expect(result.current).toBeDefined();
    expect(result.current.add).toBeDefined();
  });
});
```

### Best Practices

1. **Use Specialized Hooks**: Prefer `useUserActions()` over `useMetropolis(['user'])` when you only need one action type
2. **Selective Creation**: Use `useMetropolis(['user', 'post'])` when you need multiple specific actions
3. **Context-Based Config**: Use `useMetropolisConfig()` for accessing configuration
4. **Leverage Adapter Injection**: Pass custom adapters through the `Metropolis` component
5. **Type Safety**: Always use TypeScript interfaces for better type checking
6. **Error Handling**: Custom adapters should throw meaningful errors
7. **Wrap Components**: Always wrap components using hooks with `<Metropolis>` provider

### Removed APIs

The following APIs have been removed:

- `Config.get()` - Use `useMetropolisConfig()` in React components or `getConfigFromFlux(flux)` in non-React code
- `Config.set()` - Pass configuration to the `<Metropolis>` component instead

### Performance Considerations

- **Specialized hooks** only create the specific action type (best performance)
- **Selective creation** creates only requested actions
- Factory functions are lightweight and create minimal overhead
- Adapter validation is only performed when needed
- Options are merged efficiently without deep cloning
- Better tree-shaking opportunities with specialized hooks

## Adapters

Customize data transformation with powerful adapters. Pass adapters to the `Metropolis` component:

- **User**: User account and authentication data
- **Permission**: Permission and role data with RBAC support
- **Message**: Chat and messaging data
- **Post**: Social media content
- **Event**: Event and scheduling data
- **Image**: Media and file data
- **Location**: Geolocation data
- **Tag**: Categorization data
- **Reaction**: User interaction data
- **Content**: Content management
- **Persona**: Persona management
- **Translation**: Translation data

## Real-Time Features

### WebSocket Integration

```tsx
import {useWebsocketActions} from '@nlabs/metropolisjs';

const MyComponent = () => {
  const websocketActions = useWebsocketActions();

  useEffect(() => {
    // Initialize real-time connections
    websocketActions.wsInit();
  }, []);

  // Messages, notifications, and data updates
  // are automatically synchronized across all clients
};
```

### Server-Sent Events

Built-in SSE support for lightweight real-time updates without the overhead of WebSocket connections.

## Customization

### Custom Data Adapters

You can customize data transformation by providing custom adapters. Adapters are functions that transform and validate data:

```tsx
// Custom adapter function
const customUserAdapter = (input: unknown, options?: UserAdapterOptions) => {
  const user = input as any;

  // Add custom transformation logic
  return {
    ...user,
    displayName: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
    customField: 'custom value',
    isVerified: user.email?.endsWith('@company.com')
  };
};

// Pass adapters through the Metropolis component (recommended)
<Metropolis
  adapters={{
    User: customUserAdapter,
    Message: customMessageAdapter
  }}
>
  <YourApp />
</Metropolis>
```

The adapters will be automatically used by all action hooks. For more details on the factory pattern and adapter customization, see the [Factory Pattern Guide](#-factory-pattern-guide) section above.

### Accessing Configuration

```tsx
import {useMetropolisConfig} from '@nlabs/metropolisjs';

const MyComponent = () => {
  const config = useMetropolisConfig();
  const apiUrl = config.app?.api?.url;
  const websocketUrl = config.app?.urls?.websocket;

  // Use configuration values
  return <div>API: {apiUrl}</div>;
};
```

**Note:** `useMetropolisConfig()` must be used within a component wrapped by `<Metropolis>`.

## Performance Features

- **Selective Action Creation** - Only create actions you need with specialized hooks
- **Debounced API calls** - Prevent excessive requests
- **Intelligent caching** - With ArkhamJS
- **Optimistic updates** - Instant UI feedback
- **Connection pooling** - WebSocket efficiency
- **Lazy loading** - Support for large datasets
- **Tree-shaking friendly** - Better bundle optimization

## Security

- **Automatic token refresh** for seamless sessions
- **Secure WebSocket connections** with authentication
- **Input validation** and sanitization
- **CSRF protection** built-in
- **Session management** with configurable timeouts
- **5-Level RBAC permission system** for granular access control

## Permission System (RBAC)

MetropolisJS includes a comprehensive 5-level Role-Based Access Control (RBAC) system that integrates seamlessly with the Reaktor backend. This system provides granular control over user permissions and access levels throughout your application.

### Permission Levels

The system defines five hierarchical permission levels:

```typescript
enum PermissionLevel {
  GUEST = 0,        // Unauthenticated users
  USER = 1,         // Authenticated users
  MODERATOR = 2,    // Content moderators
  ADMIN = 3,        // Application administrators
  SUPER_ADMIN = 4   // System administrators
}
```

| Level | Name | Value | Description |
|-------|------|-------|-------------|
| 0 | Guest | `PermissionLevel.GUEST` | Unauthenticated users with limited read access |
| 1 | User | `PermissionLevel.USER` | Authenticated users who can create and edit their own content |
| 2 | Moderator | `PermissionLevel.MODERATOR` | Can moderate content and manage users |
| 3 | Admin | `PermissionLevel.ADMIN` | Full access to application features |
| 4 | Super Admin | `PermissionLevel.SUPER_ADMIN` | Complete system access, can manage admins |

### Using the Permission System

#### 1. Permission Hook

The `usePermissions()` hook provides comprehensive permission checking capabilities:

```tsx
import { usePermissions, PermissionLevel } from '@nlabs/metropolisjs';

const MyComponent = () => {
  const {
    userLevel,      // Current user's permission level
    isGuest,        // Boolean checks
    isUser,
    isModerator,
    isAdmin,
    isSuperAdmin,
    hasPermission,  // Function to check specific level
    checkResource   // Function to check resource-specific permissions
  } = usePermissions();

  return (
    <div>
      <p>Your level: {userLevel}</p>
      {isAdmin && <button>Admin Panel</button>}
      {hasPermission(PermissionLevel.MODERATOR) && (
        <button>Moderate Content</button>
      )}
    </div>
  );
};
```

#### 2. Permission Guard Component

Conditionally render components based on permission requirements:

```tsx
import { PermissionGuard, PermissionLevel } from '@nlabs/metropolisjs';

const ProtectedContent = () => {
  return (
    <>
      <PermissionGuard
        requiredLevel={PermissionLevel.USER}
        fallback={<p>Please log in to view this content</p>}
      >
        <p>This content is visible to authenticated users</p>
      </PermissionGuard>

      <PermissionGuard
        requiredLevel={PermissionLevel.ADMIN}
        fallback={null} // Hides content completely
      >
        <button>Admin Settings</button>
      </PermissionGuard>

      <PermissionGuard
        requiredLevel={PermissionLevel.MODERATOR}
        resource="posts" // Resource-specific permission
        fallback={<p>Moderator access required</p>}
      >
        <button>Moderate Posts</button>
      </PermissionGuard>
    </>
  );
};
```

#### 3. Managing Permissions with Actions

Use `usePermissionActions()` to manage permissions programmatically:

```tsx
import { usePermissionActions, PermissionLevel } from '@nlabs/metropolisjs';

const PermissionManager = () => {
  const permissionActions = usePermissionActions();

  const grantModeratorRole = async (userId: string) => {
    try {
      const permission = await permissionActions.add({
        userId,
        name: 'Moderator Role',
        level: PermissionLevel.MODERATOR,
        resource: 'posts',
        description: 'Can moderate posts and comments'
      });
      console.log('Permission granted:', permission);
    } catch (error) {
      console.error('Failed to grant permission:', error);
    }
  };

  const checkUserAccess = async (userId: string) => {
    const hasAccess = await permissionActions.check(
      userId,
      'posts',
      PermissionLevel.MODERATOR
    );
    return hasAccess;
  };

  const loadUserPermissions = async (userId: string) => {
    const permissions = await permissionActions.listByUser(userId);
    return permissions;
  };

  return (
    <div>
      <button onClick={() => grantModeratorRole('user123')}>
        Grant Moderator Permission
      </button>
    </div>
  );
};
```

#### 4. Resource-Specific Permissions

The permission system supports resource-specific access control:

```tsx
import { usePermissions, PermissionLevel } from '@nlabs/metropolisjs';

const ResourceProtectedComponent = () => {
  const { checkResource } = usePermissions();

  const canEditPosts = checkResource('posts', PermissionLevel.MODERATOR);
  const canDeleteUsers = checkResource('users', PermissionLevel.ADMIN);
  const canViewReports = checkResource('reports', PermissionLevel.MODERATOR);

  return (
    <div>
      {canEditPosts && <button>Edit Post</button>}
      {canDeleteUsers && <button>Delete User</button>}
      {canViewReports && <button>View Reports</button>}
    </div>
  );
};
```

### Permission Levels

The `userAccess` field uses the numeric `PermissionLevel` values from 0 through 4.

### Available Permission Actions

The `usePermissionActions()` hook provides the following methods:

- **`add(permissionData)`** - Grant a new permission
- **`check(userId, resource, requiredLevel)`** - Check if a user has access
- **`itemById(permissionId)`** - Retrieve a specific permission
- **`list(from?, to?)`** - List all permissions with pagination
- **`listByUser(userId)`** - Get all permissions for a specific user
- **`remove(permissionId)`** - Revoke a permission
- **`update(permission)`** - Update an existing permission

### Integration with Reaktor Backend

The permission system integrates with the Reaktor backend through GraphQL mutations and queries:

```graphql
# Grant permission
mutation {
  permissions {
    add(permission: {
      userId: "user123"
      level: 2
      resource: "posts"
      name: "Moderator"
    }) {
      permissionId
      level
      resource
    }
  }
}

# Check permission
query {
  permissions {
    check(
      userId: "user123"
      resource: "posts"
      requiredLevel: 2
    )
  }
}

# List user permissions
query {
  permissions {
    listByUser(userId: "user123") {
      permissionId
      name
      level
      resource
      description
    }
  }
}
```

### Best Practices

1. **Use Permission Guards for UI**: Wrap sensitive UI elements with `<PermissionGuard>` components
2. **Check Permissions in Actions**: Always verify permissions before executing sensitive operations
3. **Resource-Specific Permissions**: Use resource-based permissions for fine-grained control
4. **Leverage Boolean Helpers**: Use `isAdmin`, `isModerator`, etc. for cleaner code
5. **Test Permission Logic**: Write tests for permission checks to ensure security
6. **Document Required Levels**: Clearly document what permission level each feature requires

### Example: Complete Permission Workflow

```tsx
import {
  Metropolis,
  usePermissions,
  usePermissionActions,
  PermissionGuard,
  PermissionLevel
} from '@nlabs/metropolisjs';

const App = () => {
  return (
    <Metropolis config={{/* your config */}}>
      <Dashboard />
    </Metropolis>
  );
};

const Dashboard = () => {
  const { isAdmin, isModerator, userLevel } = usePermissions();
  const permissionActions = usePermissionActions();

  return (
    <div>
      <h1>Dashboard - Level: {userLevel}</h1>

      {/* Everyone sees this */}
      <section>
        <h2>Public Content</h2>
      </section>

      {/* Only authenticated users */}
      <PermissionGuard requiredLevel={PermissionLevel.USER}>
        <section>
          <h2>User Content</h2>
          <button>Create Post</button>
        </section>
      </PermissionGuard>

      {/* Only moderators and above */}
      {isModerator && (
        <section>
          <h2>Moderation Tools</h2>
          <button>Review Content</button>
        </section>
      )}

      {/* Only admins */}
      {isAdmin && (
        <section>
          <h2>Admin Panel</h2>
          <button>Manage Users</button>
          <button>System Settings</button>
        </section>
      )}
    </div>
  );
};
```

For more detailed examples, see [`examples/permission-system-usage.tsx`](./examples/permission-system-usage.tsx).

## 📦 Installation & Setup

### Prerequisites

- Node.js 16+
- React 19+
- TypeScript 7+

### Full Installation

```bash
# Install MetropolisJS and dependencies
npm install @nlabs/metropolisjs @nlabs/arkhamjs @nlabs/arkhamjs-utils-react

# For development
npm install --save-dev @types/react @types/node
```

### Environment Setup

MetropolisJS automatically detects the environment from:

- `process.env.stage` (if set)
- `process.env.NODE_ENV` (fallback)
- Defaults to `'local'` if none are set

Configure your environment-specific settings in the `config` prop of the `Metropolis` component.

## Contributing

The shared durable-chat factories are exported from `@nlabs/metropolisjs/actions`.
See [Durable chat protocol](docs/DURABLE_CHAT.md) for typed adapters, configurable
selection fields, transport integration, and application ownership boundaries.

Before opening a pull request, run the same quality gates used for source, tests, examples, and the published declarations:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

`npm run typecheck` checks the production source, unit and integration tests, every file under `examples/`, and the stricter native-auth source contract without emitting files. `npm run lint` checks source and examples without modifying them; both use the shared `eslint.config.mjs`.

TypeScript configuration is split by purpose: `tsconfig.json` defines source defaults, `tsconfig.build.json` controls Lex's declaration build, `tsconfig.test.json` covers source and tests (also used by ESLint), `tsconfig.examples.json` covers examples, and `tsconfig.native-auth.json` applies stricter checks to native-auth source.

To contribute:

1. **Fork** the repository
2. **Create** a feature branch (`git checkout -b feature/amazing-feature`)
3. **Commit** your changes (`git commit -m 'Add amazing feature'`)
4. **Push** to the branch (`git push origin feature/amazing-feature`)
5. **Open** a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Additional Documentation

- **[Actions Reference](./docs/ACTIONS.md)** - Action families, hooks, factories, and RUM beacon delivery
- **[Factory Pattern Guide](./factoryPatternGuide.md)** - Detailed guide on using the factory pattern
- **[Architecture Analysis](./ARCHITECTURE_ANALYSIS.md)** - Deep dive into the architecture
- **[Changelog](./CHANGELOG.md)** - Complete list of changes and improvements

## Support

- **Documentation**: See above for detailed guides
- **Issues**: [GitHub Issues](https://github.com/nitrogenlabs/metropolisjs/issues)
- **Discussions**: [GitHub Discussions](https://github.com/nitrogenlabs/metropolisjs/discussions)
- **Email**: <giraldo@nitrogenlabs.com>

## About Nitrogen Labs

MetropolisJS is proudly developed by [Nitrogen Labs](http://nitrogenlabs.com), a team passionate about building powerful, developer-friendly tools that make web development faster, more reliable, and more enjoyable.

---

**Ready to build the future?** Start with MetropolisJS today and experience the power of seamless frontend-backend integration! 🚀

## CRUD Operations

MetropolisJS now provides comprehensive CRUD (Create, Read, Update, Delete) operations for all Reaktor collections:

### Supported Collections

- **users** - User accounts and authentication data
- **posts** - User posts and content
- **groups** - Group entities and communities
- **messages** - Direct messages
- **conversations** - Conversation threads
- **files** - File attachments
- **images** - Image media
- **videos** - Video media
- **apps** - Application entities
- **personas** - Extended user persona details
- **tags** - Tag entities for categorization

### Basic CRUD Example

```tsx
import {useFlux} from '@nlabs/arkhamjs-utils-react';
import {createPostActions, createGroupActions} from '@nlabs/metropolisjs';

const MyComponent = () => {
  const flux = useFlux();
  const postActions = createPostActions(flux);
  const groupActions = createGroupActions(flux);

  // Create
  const createPost = async () => {
    const post = await postActions.add({
      content: "Hello World",
      userId: "user123",
      name: "My First Post"
    });
  };

  // Read
  const getPost = async (postId: string) => {
    const post = await postActions.itemById(postId);
  };

  // Update
  const updatePost = async (postId: string) => {
    await postActions.update({
      postId,
      content: "Updated content"
    });
  };

  // Delete
  const deletePost = async (postId: string) => {
    await postActions.delete(postId);
  };

  // List with pagination
  const listPosts = async () => {
    const posts = await postActions.listByLatest(0, 10);
  };
};
```

### Relationship Management

Connect and manage relationships between collections:

```tsx
import {createConnectionActions, CONNECTION_TYPES} from '@nlabs/metropolisjs';

const connectionActions = createConnectionActions(flux);

// Add user to group
await connectionActions.addConnection(
  'users',
  userId,
  'groups',
  groupId,
  CONNECTION_TYPES.MEMBER
);

// Get all connections
const connections = await connectionActions.getConnections('users', userId);

// Remove connection
await connectionActions.removeConnection('users', userId, 'groups', groupId);
```

### Extensible Fields

All CRUD operations support custom fields:

```tsx
const post = await postActions.add({
  content: "Hello",
  userId: "user123",
  // Custom fields
  customField1: "value",
  customField2: 42,
  metadata: {
    source: "mobile",
    version: "1.0"
  }
});
```

### Documentation

For comprehensive guides and examples, see:

- [CRUD Integration Guide](./docs/CRUD_INTEGRATION.md) - Complete guide to CRUD operations
- [Actions Reference](./docs/ACTIONS.md) - Action families, hooks, creators, and method map
- [Collections Reference](./docs/COLLECTIONS.md) - Detailed information about each collection
- [Connections Guide](./docs/CONNECTIONS.md) - Managing relationships between collections
- [CRUD Examples](./examples/crud-usage.tsx) - Practical code examples
- [Connection Examples](./examples/connections-usage.tsx) - Relationship management examples
- [Extensibility Examples](./examples/extensibility-usage.tsx) - Custom field examples

## Generation, sessions, and realtime

See the [complete generation and sessions guide](docs/GENERATION.md) for the provider matrix, durable transports, ArkhamJS events, bearer sessions, and release policy.

### Generate content with a selected provider

Use the existing factory, with provider selection in the request:

```ts
const content = createContentActions(flux);
await content.generateContent({prompt: 'Write a scene', provider: 'claude'});
```

This calls Reaktor's `contents.generateContent` GraphQL mutation. It stores the confirmed
result at `content.generation` before dispatching `CONTENT_GENERATION_CONSTANTS.SUCCESS`;
failures dispatch `CONTENT_GENERATION_CONSTANTS.ERROR`. Paid generation is not queued for
offline replay. Listen to Arkham events to update the UI.

For an application-owned durable job, pass `{transport: async (input) => enqueue(input)}`
as the second argument. The transport receives the full application input (including its
provider and idempotency key) and returns the confirmed job result. Ownership, billing and
reconciliation belong to that application endpoint; provider credentials remain server-side.

### Image/video generation and bearer sockets

`createImageActions(flux).generateImage({provider: 'openai', prompt: 'A paper moon'})` uses Reaktor's `images.generateImage` mutation. Existing image upload and CRUD actions are unchanged. `createVideoActions(flux).generateVideo({provider: 'higgsfield', prompt: 'A slow camera move', imageUrl: 'https://example.com/reference.png'})` uses Reaktor's generic `videos.generateVideo` mutation. Both methods also accept `{transport: async (input) => ...}` for application-owned durable jobs. They update `image.generation`/`video.generation` before dispatching `IMAGE_GENERATE_SUCCESS`/`VIDEO_GENERATE_SUCCESS`; errors dispatch the matching error event. Paid defaults disable offline replay.

Use `createWebsocketActions(flux, {authentication: 'message', url, authenticateMessage: (token) => ({token})})` with a server that authenticates the first frame. Tokens are omitted from its URL. Existing query authentication remains the compatibility default. A policy close (1008) stops reconnection and dispatches the close code. Configure `app.session.autoRefresh: false` for nonrenewable bearer sessions; the existing `storeSession` and `clearPersistedSession` helpers own Flux session state.

`createVideoActions(flux).generateVideo({imageUrl, prompt, provider: 'higgsfield'})` requires an explicit provider and calls
Reaktor's generic `videos.generateVideo` GraphQL mutation. An explicit input `provider`
overrides the factory's optional `provider` setting. Neither has an implicit provider default. The normalized
provider is also passed to custom transports. Generation stores results before its Arkham
success event and disables offline replay.

Generation providers are explicit: generic content actions support `claude`, `gemini`,
and `openai`; image actions support `gemini`, `higgsfield`, and `openai`; video actions
support `gemini` (Veo) and `higgsfield`. No generation provider is inferred. The same
GraphQL actions and Arkham events apply to each provider. Provider credentials remain
in Reaktor server configuration; applications retain responsibility for durable jobs,
credit accounting, and private object storage.

### Higgsfield catalog model inputs

Image and video generation actions accept a Higgsfield route in `model` and its documented nested parameters in `modelInput`. The generic GraphQL transport forwards this JSON to Reaktor's allowlisted catalog and schema validator; custom authenticated transports retain the same Flux completion/error events. Read available models from the application's server catalog rather than embedding provider credentials or duplicating the model list in the UI.

### Grok text and media

Text generation accepts `provider: "grok"`; Reaktor uses server-side `contentGeneration.grokKey` and optional `grokModel` (default `grok-4.7`) for the xAI Responses API. Owned image inputs can accompany a text prompt. Grok image/video models are available through the Higgsfield model catalog and its existing webhook transport; this integration does not add a direct xAI media polling adapter. Application code owns callback persistence, retention, and accounting.

### Assistant actions

Use `createAction('assistant', flux)` to call Reaktor's GraphQL assistant through the standard MetropolisJS transport. Set `app.api.public` to `https://api.reaktor.io` for NitrogenX.

```ts
import {createAction} from '@nlabs/metropolisjs/utils';
import {ASSISTANT_CONSTANTS} from '@nlabs/metropolisjs/stores';

// flux is your application's initialized ArkhamJS Flux instance.
// Configure app.api.public as 'https://api.reaktor.io'.
const assistant = createAction('assistant', flux, {instanceId: 'site-help'});
flux.on(ASSISTANT_CONSTANTS.CHAT_SUCCESS, ({instanceId, result}) => {
  // assistant.instances[instanceId] is updated before this event.
  console.log(result.answer, result.sources);
});
flux.on(ASSISTANT_CONSTANTS.CHAT_ERROR, ({error}) => {
  console.error(error.message);
});

void assistant.chat({
  context: 'nitrogen',
  history: [],
  language: 'en-US',
  name: 'Alfred',
  question: 'What does Nitrogen build?'
}).catch(() => { /* The error event handles presentation. */ });
```

| Action | GraphQL operation | Result |
| --- | --- | --- |
| `assistant.chat(input)` | Mutation `assistant.chat` | Grounded answer and source links |
| `assistant.faqs({context: 'nitrogen'})` | Query `assistant.faqs` | Public FAQ items |
| `assistant.submitSupport(input)` | Mutation `assistant.submitSupport` | Confirmed ticket number or durable queue acknowledgement |

Listen for `ASSISTANT_CONSTANTS` chat/FAQ/support success and error events. State updates before events at `assistant.instances[instanceId]`. Support requires user confirmation, valid contact details and a stable `web-UUID` request ID; retry unchanged details with the same ID. Knowledge, credentials and delivery configuration remain server-owned.

See [Assistant actions](docs/ASSISTANT.md) for the complete inputs, responses, Flux events, Alfred callback mapping and support example.

### Vault transport qualification

The Vault compatibility candidate uses the published Rip-Hunter `^3.5.1` contract. Its release consumer pins the same public transport version and checks that REST refusals retain `ApiError` identity, status and parsed JSON without replaying requests. Qualification also checks strict NodeNext/Bundler declarations and the installed runner/compiler graph. The `vault-cutover` distribution tag does not promote `latest`.

After cloning, run `git config core.hooksPath .githooks` once to install the repository hooks.

`npm test` runs only unit tests. `npm run test:e2e` builds the package with Lex and runs both existing browser suites. Git hooks select units from staged JavaScript/TypeScript and browser checks from all pushed JavaScript/TypeScript/CSS commits. Documentation and JSON changes do not trigger either suite. Hook rules have regression tests using the actual scripts in temporary repositories with npm stubbed.

The build uses Lex directly; the obsolete unlisted `tsc-esm-fix` postbuild download is removed. The public consumer verifies that generated runtime imports and declarations resolve without an extension-repair script.

### Cookie ticket WebSocket connections

`createWebsocketActions` supports an optional explicit connection mode without changing its default bearer-query `wsInit()` behavior. Use `authentication: 'none'`, `register: false`, `reconnect: false`, and `resolveUrl: async () => completeTicketUrl` for a receive-only, cookie-authenticated ticket service. The resolver belongs to the application adapter and should acquire the ticket through authenticated `restRequest` with `queueOffline: false`; the shared owner never invents a token, appends identity parameters, or refreshes a ticket automatically in this mode.

Call `wsConnect()` to wait for open; concurrent calls share one attempt and return the same promise. It resolves to the public Sockette instance on open and `null` when URL resolution fails, returns no URL, the transport fails, the connection closes, or its deadline expires. `connectTimeoutMs` defaults to 5000 milliseconds, counts URL resolution and opening together, accepts finite nonnegative durations, supports durations above the platform timer limit, and preserves zero as disabled. `wsClose()` invalidates pending URL resolution and old transport callbacks, settles a pending connection, and clears the deadline. A later explicit `wsConnect()` resolves a fresh URL. Explicitly closing an active socket, or a terminal transport error, clears the public websocket store’s `isOpen` state and emits one `WEBSOCKET_CLOSE`; repeated closes and obsolete native callbacks do not duplicate that transition. `WEBSOCKET_OPEN`, `WEBSOCKET_MESSAGE`, `WEBSOCKET_ERROR`, and `WEBSOCKET_CLOSE` remain the shared Flux channels; consumers retain domain validation and authoritative reads. Existing `wsSend()` queue semantics and default reconnect/session registration behavior remain unchanged.
