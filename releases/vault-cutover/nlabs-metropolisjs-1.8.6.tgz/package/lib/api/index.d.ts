/** Compatible with the public Rip-Hunter /graphql binding; transport owns deadlines and errors. */
export interface ApiOperation {
    readonly operationName: string;
    readonly query: string;
    readonly variables?: Record<string, unknown>;
}
export interface ApiRequestOptions {
    readonly signal?: AbortSignal;
    readonly timeout?: number;
    readonly token?: string;
}
export type GraphqlBinding = <T>(endpoint: string, operation: ApiOperation, options?: ApiRequestOptions) => Promise<T>;
export interface NativeApi {
    request<T>(operation: ApiOperation, options: ApiRequestOptions & {
        readonly authenticated: boolean;
    }): Promise<T>;
}
export declare const createNativeApi: ({ endpoint, request, preflight, timeout }: {
    readonly endpoint: string;
    readonly request: GraphqlBinding;
    readonly preflight?: () => Promise<string>;
    readonly timeout: number;
}) => NativeApi;
