import type { FluxFramework } from '@nlabs/arkhamjs';
import type { NativeNotificationActions, NativeNotificationAdapter, NativeNotificationController, PushActor, PushScope } from '../types/nativeNotifications.types.js';
type Binding = PushScope & PushActor & {
    installationId: string;
};
export declare const createNativeNotificationController: ({ actions, actionsForBinding, adapter, flux, now }: {
    actions: NativeNotificationActions;
    actionsForBinding?: (binding: Binding) => NativeNotificationActions;
    adapter: NativeNotificationAdapter;
    flux: FluxFramework;
    now?: () => number;
}) => NativeNotificationController;
export {};
