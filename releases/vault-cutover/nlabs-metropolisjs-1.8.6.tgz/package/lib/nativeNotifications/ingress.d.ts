import type { FluxFramework } from '@nlabs/arkhamjs';
export declare const bindNativeNotificationIngress: (flux: FluxFramework, handler: (payload: unknown) => Promise<boolean>) => (() => void);
export declare const routeNativeNotificationIngress: (flux: FluxFramework, payload: unknown) => boolean;
