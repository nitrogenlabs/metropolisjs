export declare const nativePushContractFixture: {
    notification: {
        body: string;
        createdAt: string;
        data: {
            conversationId: string;
            flags: boolean[];
            nested: {
                count: number;
            };
        };
        kind: string;
        notificationId: string;
        title: string;
        version: 1;
    };
    recipientUserId: string;
    scope: {
        appId: string;
        environment: string;
    };
};
