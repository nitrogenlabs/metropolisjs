import type { NativeNotificationAdapter } from '../../types/nativeNotifications.types.js';
type Subscription = {
    remove(): void;
};
export interface ExpoNotificationsPort {
    AndroidImportance: {
        DEFAULT: number;
    };
    addNotificationReceivedListener(listener: (notification: any) => void): Subscription;
    addNotificationResponseReceivedListener(listener: (response: any) => void): Subscription;
    addPushTokenListener(listener: (token: any) => void): Subscription;
    clearLastNotificationResponseAsync(): Promise<void>;
    getDevicePushTokenAsync(): Promise<{
        data: unknown;
        type: string;
    }>;
    getLastNotificationResponseAsync(): Promise<unknown>;
    getPermissionsAsync(): Promise<{
        status: string;
    }>;
    requestPermissionsAsync(): Promise<{
        status: string;
    }>;
    setNotificationChannelAsync(id: string, channel: {
        importance: number;
        name: string;
    }): Promise<unknown>;
}
export declare const createExpoNativeNotificationAdapter: ({ androidChannelId, androidChannelName, apnsEnvironment, notifications, platform }: {
    androidChannelId?: string;
    androidChannelName?: string;
    apnsEnvironment?: 'production' | 'sandbox';
    notifications: ExpoNotificationsPort;
    platform: 'android' | 'ios';
}) => NativeNotificationAdapter;
export {};
