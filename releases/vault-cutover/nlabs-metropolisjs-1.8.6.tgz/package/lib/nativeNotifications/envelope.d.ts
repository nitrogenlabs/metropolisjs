import type { NativeNotification, NativePushEnvelope } from '../types/nativeNotifications.types.js';
export declare const normalizeNativeNotification: (payload: unknown) => NativeNotification | null;
export declare const parseNativePushEnvelope: (payload: unknown) => NativePushEnvelope | null;
