import type { PaymentPlanType, PaymentSubscriptionType } from '../types/subscriptions.types.js';
export declare const SUBSCRIPTION_CONSTANTS: {
    readonly ADD_PLAN_ERROR: 'SUBSCRIPTION_ADD_PLAN_ERROR';
    readonly ADD_PLAN_SUCCESS: 'SUBSCRIPTION_ADD_PLAN_SUCCESS';
    readonly ADD_SUBSCRIPTION_ERROR: 'SUBSCRIPTION_ADD_SUBSCRIPTION_ERROR';
    readonly ADD_SUBSCRIPTION_SUCCESS: 'SUBSCRIPTION_ADD_SUBSCRIPTION_SUCCESS';
    readonly DELETE_SUBSCRIPTION_ERROR: 'SUBSCRIPTION_DELETE_SUBSCRIPTION_ERROR';
    readonly DELETE_SUBSCRIPTION_SUCCESS: 'SUBSCRIPTION_DELETE_SUBSCRIPTION_SUCCESS';
    readonly GET_PLAN_ERROR: 'SUBSCRIPTION_GET_PLAN_ERROR';
    readonly GET_PLAN_SUCCESS: 'SUBSCRIPTION_GET_PLAN_SUCCESS';
    readonly GET_SUBSCRIPTION_ERROR: 'SUBSCRIPTION_GET_SUBSCRIPTION_ERROR';
    readonly GET_SUBSCRIPTION_LIST_ERROR: 'SUBSCRIPTION_GET_SUBSCRIPTION_LIST_ERROR';
    readonly GET_SUBSCRIPTION_LIST_SUCCESS: 'SUBSCRIPTION_GET_SUBSCRIPTION_LIST_SUCCESS';
    readonly GET_SUBSCRIPTION_SUCCESS: 'SUBSCRIPTION_GET_SUBSCRIPTION_SUCCESS';
};
export interface SubscriptionState {
    readonly error?: Error;
    readonly plansByItem: Record<string, PaymentPlanType>;
    readonly subscriptionList: PaymentSubscriptionType[];
    readonly subscriptionsByItem: Record<string, PaymentSubscriptionType>;
}
export declare const initialSubscriptionState: SubscriptionState;
type SubscriptionStoreAction = {
    readonly error?: Error;
    readonly itemKey?: string;
    readonly list?: PaymentSubscriptionType[];
    readonly plan?: PaymentPlanType;
    readonly subscription?: PaymentSubscriptionType;
};
export declare const subscriptionStore: (type: string, data: SubscriptionStoreAction, state?: SubscriptionState) => SubscriptionState;
export declare const subscriptions: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: SubscriptionState) => SubscriptionState;
    initialState: SubscriptionState;
    name: string;
};
export {};
