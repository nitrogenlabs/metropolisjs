import type { NativePermission, NativePushRegistration } from '../types/nativeNotifications.types.js';
export declare const NATIVE_NOTIFICATION_CONSTANTS: {
    readonly ERROR: 'NATIVE_NOTIFICATION_ERROR';
    readonly OPENED: 'NATIVE_NOTIFICATION_OPENED';
    readonly PERMISSION: 'NATIVE_NOTIFICATION_PERMISSION';
    readonly RECEIVED: 'NATIVE_NOTIFICATION_RECEIVED';
    readonly REGISTERED: 'NATIVE_NOTIFICATION_REGISTERED';
    readonly RESET: 'NATIVE_NOTIFICATION_RESET';
    readonly UNREGISTERED: 'NATIVE_NOTIFICATION_UNREGISTERED';
};
export type NativeNotificationState = {
    error: string | null | undefined;
    permission: NativePermission | null | undefined;
    registration: NativePushRegistration | null | undefined;
};
export declare const defaultNativeNotificationState: NativeNotificationState;
export declare const nativeNotificationStore: (type: string, data: Partial<NativeNotificationState>, state?: NativeNotificationState) => NativeNotificationState;
export declare const nativeNotifications: {
    action: typeof nativeNotificationStore;
    initialState: NativeNotificationState;
    name: string;
};
