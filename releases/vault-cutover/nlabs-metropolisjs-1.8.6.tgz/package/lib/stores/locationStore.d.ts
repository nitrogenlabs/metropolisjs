import type { LocationType } from '../adapters/locationAdapter/locationAdapter.js';
export declare const LOCATION_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'LOCATION_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'LOCATION_ADD_ITEM_SUCCESS';
    readonly GET_ITEM_ERROR: 'LOCATION_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'LOCATION_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'LOCATION_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'LOCATION_GET_LIST_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'LOCATION_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'LOCATION_REMOVE_ITEM_SUCCESS';
    readonly SET_CURRENT: 'LOCATION_SET_CURRENT';
    readonly UPDATE_ITEM_ERROR: 'LOCATION_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'LOCATION_UPDATE_ITEM_SUCCESS';
};
interface LocationState {
    current: LocationType | null;
}
export declare const defaultValues: LocationState;
export declare const locationStore: (type: string, data: {
    current?: LocationType;
}, state?: LocationState) => LocationState;
export declare const locations: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: LocationState) => LocationState;
    initialState: LocationState;
    name: string;
};
export {};
