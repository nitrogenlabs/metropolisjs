export declare const VIDEO_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'VIDEO_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'VIDEO_ADD_ITEM_SUCCESS';
    readonly GENERATE_ERROR: 'VIDEO_GENERATE_ERROR';
    readonly GENERATE_SUCCESS: 'VIDEO_GENERATE_SUCCESS';
    readonly GET_ITEM_ERROR: 'VIDEO_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'VIDEO_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'VIDEO_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'VIDEO_GET_LIST_SUCCESS';
    readonly PROCESSING_COMPLETE: 'VIDEO_PROCESSING_COMPLETE';
    readonly REMOVE_ITEM_ERROR: 'VIDEO_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'VIDEO_REMOVE_ITEM_SUCCESS';
    readonly UPDATE_ITEM_ERROR: 'VIDEO_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'VIDEO_UPDATE_ITEM_SUCCESS';
};
export type VideoConstantsType = typeof VIDEO_CONSTANTS[keyof typeof VIDEO_CONSTANTS];
interface VideoState {
    error?: Error;
    item?: Record<string, any>;
    list?: any[];
    videos?: Record<string, any>;
}
export declare const defaultValues: VideoState;
interface VideoData {
    readonly error?: Error;
    readonly list?: any[];
    readonly video?: Record<string, any>;
    readonly videos?: Record<string, any>;
}
export declare const videoStore: (type: string, data: VideoData, state?: VideoState) => VideoState;
export declare const video: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: VideoState) => VideoState;
    initialState: VideoState;
    name: string;
};
export {};
