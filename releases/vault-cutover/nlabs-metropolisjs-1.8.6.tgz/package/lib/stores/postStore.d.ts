import type { PostType } from '../adapters/postAdapter/postAdapter.js';
export declare const POST_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'POST_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'POST_ADD_ITEM_SUCCESS';
    readonly GET_ITEM_ERROR: 'POST_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'POST_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'POST_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'POST_GET_LIST_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'POST_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'POST_REMOVE_ITEM_SUCCESS';
    readonly UPDATE_ITEM_ERROR: 'POST_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'POST_UPDATE_ITEM_SUCCESS';
};
interface PostState {
    lists: Record<string, PostType[]>;
    viewed: Record<string, PostType>;
}
export declare const defaultValues: PostState;
export declare const postStore: (type: string, data: {
    post?: PostType;
}, state?: PostState) => PostState;
export declare const posts: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: PostState) => PostState;
    initialState: PostState;
    name: string;
};
export {};
