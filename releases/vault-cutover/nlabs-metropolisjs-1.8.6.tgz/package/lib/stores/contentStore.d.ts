import type { ContentType } from '../adapters/contentAdapter/contentAdapter.js';
export declare const CONTENT_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'CONTENT_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'CONTENT_ADD_ITEM_SUCCESS';
    readonly GET_ITEM_ERROR: 'CONTENT_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'CONTENT_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'CONTENT_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'CONTENT_GET_LIST_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'CONTENT_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'CONTENT_REMOVE_ITEM_SUCCESS';
    readonly UPDATE_ITEM_ERROR: 'CONTENT_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'CONTENT_UPDATE_ITEM_SUCCESS';
};
export type ContentConstantsType = typeof CONTENT_CONSTANTS[keyof typeof CONTENT_CONSTANTS];
interface ContentState {
    error?: Error;
    content: Record<string, Partial<ContentType>>;
    lists: Record<string, unknown>;
}
interface ContentData {
    readonly content?: ContentType;
    readonly error?: Error;
    readonly list?: ContentType[];
}
export declare const contentStore: (type: string, data: ContentData, state?: ContentState) => ContentState;
export declare const contents: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: ContentState) => ContentState;
    initialState: ContentState;
    name: string;
};
export {};
