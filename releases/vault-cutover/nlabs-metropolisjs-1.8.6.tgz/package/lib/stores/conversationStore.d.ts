export declare const CONVERSATION_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'CONVERSATION_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'CONVERSATION_ADD_ITEM_SUCCESS';
    readonly GET_ITEM_ERROR: 'CONVERSATION_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'CONVERSATION_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'CONVERSATION_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'CONVERSATION_GET_LIST_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'CONVERSATION_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'CONVERSATION_REMOVE_ITEM_SUCCESS';
    readonly UPDATE_ITEM_ERROR: 'CONVERSATION_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'CONVERSATION_UPDATE_ITEM_SUCCESS';
};
export type ConversationConstantsType = typeof CONVERSATION_CONSTANTS[keyof typeof CONVERSATION_CONSTANTS];
interface ConversationState {
    error?: Error;
    item?: Record<string, any>;
    list?: any[];
    conversations?: Record<string, any>;
}
export declare const defaultValues: ConversationState;
interface ConversationData {
    readonly conversation?: Record<string, any>;
    readonly conversations?: Record<string, any>;
    readonly error?: Error;
    readonly list?: any[];
}
export declare const conversationStore: (type: string, data: ConversationData, state?: ConversationState) => ConversationState;
export declare const conversation: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: ConversationState) => ConversationState;
    initialState: ConversationState;
    name: string;
};
export {};
