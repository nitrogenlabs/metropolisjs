/**
 * Copyright (c) 2026-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import type { Permission } from '../adapters/permissionAdapter/permissionAdapter.js';
export declare const PERMISSION_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'PERMISSION_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'PERMISSION_ADD_ITEM_SUCCESS';
    readonly CHECK_PERMISSION_ERROR: 'PERMISSION_CHECK_PERMISSION_ERROR';
    readonly CHECK_PERMISSION_SUCCESS: 'PERMISSION_CHECK_PERMISSION_SUCCESS';
    readonly GET_ITEM_ERROR: 'PERMISSION_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'PERMISSION_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'PERMISSION_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'PERMISSION_GET_LIST_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'PERMISSION_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'PERMISSION_REMOVE_ITEM_SUCCESS';
    readonly UPDATE_ITEM_ERROR: 'PERMISSION_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'PERMISSION_UPDATE_ITEM_SUCCESS';
};
export type PermissionConstantsType = typeof PERMISSION_CONSTANTS[keyof typeof PERMISSION_CONSTANTS];
interface PermissionState {
    error?: Error;
    lists: Record<string, unknown>;
    permissions: Record<string, Partial<Permission>>;
    userPermissions: Record<string, Permission[]>;
}
export declare const defaultValues: PermissionState;
interface PermissionData {
    readonly error?: Error;
    readonly list?: Permission[];
    readonly permission?: Permission;
    readonly userId?: string;
}
export declare const permissionStore: (type: string, data: PermissionData, state?: PermissionState) => PermissionState;
export declare const permissions: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: PermissionState) => PermissionState;
    initialState: PermissionState;
    name: string;
};
export {};
