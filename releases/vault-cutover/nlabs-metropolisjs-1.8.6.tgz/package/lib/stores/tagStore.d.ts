import type { TagType } from '../adapters/tagAdapter/tagAdapter.js';
export declare const TAG_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'TAG_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'TAG_ADD_ITEM_SUCCESS';
    readonly ADD_LINK_SUCCESS: 'TAG_ADD_LINK_SUCCESS';
    readonly ADD_PERSONA_ERROR: 'TAG_ADD_PERSONA_ERROR';
    readonly ADD_PERSONA_SUCCESS: 'TAG_ADD_PERSONA_SUCCESS';
    readonly GET_LIST_ERROR: 'TAG_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'TAG_GET_LIST_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'TAG_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'TAG_REMOVE_ITEM_SUCCESS';
    readonly REMOVE_LINK_SUCCESS: 'TAG_REMOVE_LINK_SUCCESS';
    readonly REMOVE_PERSONA_ERROR: 'TAG_REMOVE_PERSONA_ERROR';
    readonly REMOVE_PERSONA_SUCCESS: 'TAG_REMOVE_PERSONA_SUCCESS';
    readonly UPDATE_ITEM_ERROR: 'TAG_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'TAG_UPDATE_ITEM_SUCCESS';
};
interface TagState {
    expires: number;
    list: TagType[];
}
export declare const defaultValues: TagState;
export declare const tagStore: (type: string, data: {
    tag?: TagType;
    tags?: TagState['list'];
}, state?: TagState) => TagState;
export declare const tags: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: TagState) => TagState;
    initialState: TagState;
    name: string;
};
export {};
