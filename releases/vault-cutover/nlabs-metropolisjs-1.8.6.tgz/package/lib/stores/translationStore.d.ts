export interface TranslationType {
    readonly key: string;
    readonly locale: string;
    readonly value: string;
    readonly namespace?: string;
    readonly timestamp?: number;
}
export interface TranslationState {
    readonly error?: Error;
    readonly translations: Record<string, TranslationType>;
    readonly pendingKeys: Set<string>;
    readonly isQueueing: boolean;
    readonly lastSync: number;
}
export declare const TRANSLATION_CONSTANTS: {
    readonly ADD_TRANSLATIONS_SUCCESS: 'TRANSLATION_ADD_TRANSLATIONS_SUCCESS';
    readonly ADD_TRANSLATIONS_ERROR: 'TRANSLATION_ADD_TRANSLATIONS_ERROR';
    readonly GET_TRANSLATIONS_SUCCESS: 'TRANSLATION_GET_TRANSLATIONS_SUCCESS';
    readonly GET_TRANSLATIONS_ERROR: 'TRANSLATION_GET_TRANSLATIONS_ERROR';
    readonly QUEUE_TRANSLATION_KEY: 'TRANSLATION_QUEUE_TRANSLATION_KEY';
    readonly CLEAR_PENDING_KEYS: 'TRANSLATION_CLEAR_PENDING_KEYS';
    readonly SET_QUEUEING_STATE: 'TRANSLATION_SET_QUEUEING_STATE';
};
export type TranslationConstantsType = typeof TRANSLATION_CONSTANTS[keyof typeof TRANSLATION_CONSTANTS];
interface TranslationData {
    readonly error?: Error;
    readonly translations?: TranslationType[];
    readonly key?: string;
    readonly isQueueing?: boolean;
}
export declare const translationStore: (type: string, data: TranslationData, state?: TranslationState) => TranslationState;
export declare const translations: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: TranslationState) => TranslationState;
    initialState: TranslationState;
    name: string;
};
export {};
