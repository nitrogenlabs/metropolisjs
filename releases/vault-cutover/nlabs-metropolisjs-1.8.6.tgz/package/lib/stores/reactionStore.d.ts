/**
 * Copyright (c) 2022-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
export declare const REACTION_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'REACTION_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'REACTION_ADD_ITEM_SUCCESS';
    readonly GET_COUNT_ERROR: 'REACTION_GET_COUNT_ERROR';
    readonly GET_COUNT_SUCCESS: 'REACTION_GET_COUNT_SUCCESS';
    readonly HAS_ERROR: 'REACTION_HAS_ERROR';
    readonly HAS_SUCCESS: 'REACTION_HAS_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'REACTION_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'REACTION_REMOVE_ITEM_SUCCESS';
};
interface ReactionState {
    reactions?: Record<string, {
        count?: number;
        hasReaction?: boolean;
    }>;
}
export declare const defaultValues: ReactionState;
export declare const reactionStore: (type: string, data: Partial<ReactionState>, state?: ReactionState) => ReactionState;
export declare const reactions: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: ReactionState) => ReactionState;
    initialState: ReactionState;
    name: string;
};
export {};
