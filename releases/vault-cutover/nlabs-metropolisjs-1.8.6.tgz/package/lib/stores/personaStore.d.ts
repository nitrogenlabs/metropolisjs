import type { PersonaType } from '../adapters/personaAdapter/personaAdapter.js';
export declare const PERSONA_CONSTANTS: {
    ADD_ITEM_ERROR: string;
    ADD_ITEM_SUCCESS: string;
    DELETE_ITEM_ERROR: string;
    DELETE_ITEM_SUCCESS: string;
    GET_ITEM_ERROR: string;
    GET_ITEM_SUCCESS: string;
    GET_LIST_ERROR: string;
    GET_LIST_SUCCESS: string;
    UPDATE_ITEM_ERROR: string;
    UPDATE_ITEM_SUCCESS: string;
};
export interface PersonaState {
    readonly error?: Error;
    readonly list: PersonaType[];
    readonly listMap: Record<string, PersonaType>;
}
export declare const initialPersonaState: PersonaState;
export declare const personaStore: (state?: PersonaState, action?: {}, _next?: {}) => PersonaState;
export declare const personas: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: PersonaState) => PersonaState;
    initialState: PersonaState;
    name: string;
};
