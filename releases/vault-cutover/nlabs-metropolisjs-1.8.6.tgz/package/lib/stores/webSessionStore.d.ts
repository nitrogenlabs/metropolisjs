import type { WebSessionIdentity, WebSessionScope } from '../session/webSessionPolicy.js';
export declare const WEB_SESSION_CONSTANTS: {
    readonly AUTHENTICATED: 'WEB_SESSION_AUTHENTICATED';
    readonly BLOCKED: 'WEB_SESSION_BLOCKED';
    readonly SIGNED_OUT: 'WEB_SESSION_SIGNED_OUT';
};
export interface WebSessionState {
    readonly generation: number;
    readonly identity?: WebSessionIdentity;
    readonly scope?: WebSessionScope;
    readonly status: 'anonymous' | 'authenticated' | 'blocked';
}
export declare const webSession: {
    action: (_type: string, _data: unknown, state: WebSessionState) => WebSessionState;
    initialState: WebSessionState;
    name: string;
};
/** Independent from account cache clearing; contains no identity or private payload. */
export declare const webSessionSuppression: {
    action: (_type: string, _data: unknown, state: {
        suppressed: boolean;
    }) => {
        suppressed: boolean;
    };
    initialState: {
        suppressed: boolean;
    };
    name: string;
};
