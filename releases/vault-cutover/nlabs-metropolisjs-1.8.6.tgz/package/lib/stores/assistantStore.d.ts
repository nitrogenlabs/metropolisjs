import type { AssistantChatResult, AssistantFaqResult, AssistantSupportResult } from '../actions/assistantActions/assistantActions.js';
export declare const ASSISTANT_CONSTANTS: {
    readonly CHAT_ERROR: 'ASSISTANT_CHAT_ERROR';
    readonly CHAT_SUCCESS: 'ASSISTANT_CHAT_SUCCESS';
    readonly FAQS_ERROR: 'ASSISTANT_FAQS_ERROR';
    readonly FAQS_SUCCESS: 'ASSISTANT_FAQS_SUCCESS';
    readonly SUPPORT_ERROR: 'ASSISTANT_SUPPORT_ERROR';
    readonly SUPPORT_SUCCESS: 'ASSISTANT_SUPPORT_SUCCESS';
};
export interface AssistantState {
    readonly instances: Record<string, {
        chat?: AssistantChatResult;
        error?: Error;
        faqs?: AssistantFaqResult;
        support?: AssistantSupportResult;
    }>;
}
export declare const defaultValues: AssistantState;
export declare const assistantStore: (type: string, data: {
    error?: Error;
    instanceId?: string;
    result?: AssistantChatResult | AssistantFaqResult | AssistantSupportResult;
}, state?: AssistantState) => AssistantState;
export declare const assistant: {
    action: typeof assistantStore;
    initialState: AssistantState;
    name: string;
};
