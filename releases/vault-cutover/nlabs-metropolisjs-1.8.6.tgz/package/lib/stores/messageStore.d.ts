import type { MessageType } from '../adapters/messageAdapter/messageAdapter.js';
export declare const MESSAGE_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'MESSAGE_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'MESSAGE_ADD_ITEM_SUCCESS';
    readonly GET_CONVO_LIST_ERROR: 'MESSAGE_GET_CONVO_LIST_ERROR';
    readonly GET_CONVO_LIST_SUCCESS: 'MESSAGE_GET_CONVO_LIST_SUCCESS';
    readonly GET_ITEM_ERROR: 'MESSAGE_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'MESSAGE_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'MESSAGE_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'MESSAGE_GET_LIST_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'MESSAGE_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'MESSAGE_REMOVE_ITEM_SUCCESS';
    readonly TYPING_STATUS_UPDATE: 'MESSAGE_TYPING_STATUS_UPDATE';
    readonly UPDATE_ITEM_ERROR: 'MESSAGE_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'MESSAGE_UPDATE_ITEM_SUCCESS';
};
export interface MessageTypingStatus {
    readonly conversationId?: string;
    readonly isTyping?: boolean;
    readonly name?: string;
    readonly personaId?: string;
    readonly updatedAt?: number;
    readonly userId?: string;
    readonly username?: string;
}
export interface MessageState {
    readonly conversations: Record<string, MessageType[]>;
    readonly typingByConversation: Record<string, Record<string, MessageTypingStatus>>;
}
export declare const defaultValues: MessageState;
export declare const messageStore: (type: string, data: {
    message?: MessageType;
    list?: MessageType[];
    conversationId?: string;
    typing?: MessageTypingStatus;
}, state?: MessageState) => MessageState;
export declare const messages: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: MessageState) => MessageState;
    initialState: MessageState;
    name: string;
};
