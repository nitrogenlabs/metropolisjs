import type { EventType } from '../adapters/eventAdapter/eventAdapter.js';
export declare const EVENT_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'EVENT_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'EVENT_ADD_ITEM_SUCCESS';
    readonly GET_ITEM_ERROR: 'EVENT_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'EVENT_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'EVENT_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'EVENT_GET_LIST_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'EVENT_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'EVENT_REMOVE_ITEM_SUCCESS';
    readonly RSVP_ITEM_ERROR: 'EVENT_RSVP_ITEM_ERROR';
    readonly RSVP_ITEM_SUCCESS: 'EVENT_RSVP_ITEM_SUCCESS';
    readonly UPDATE_ITEM_ERROR: 'EVENT_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'EVENT_UPDATE_ITEM_SUCCESS';
};
interface EventState {
    lists: Record<string, Record<string, unknown>[]>;
}
export declare const defaultValues: EventState;
export declare const eventStore: (type: string, data: {
    list?: EventType[];
    type?: string;
}, state?: EventState) => EventState;
export declare const events: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: EventState) => EventState;
    initialState: EventState;
    name: string;
};
export {};
