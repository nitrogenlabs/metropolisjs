export declare const APP_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'APP_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'APP_ADD_ITEM_SUCCESS';
    readonly API_NETWORK_ERROR: 'APP_API_NETWORK_ERROR';
    readonly API_NETWORK_SUCCESS: 'APP_API_NETWORK_SUCCESS';
    readonly GET_ITEM_ERROR: 'APP_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'APP_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'APP_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'APP_GET_LIST_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'APP_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'APP_REMOVE_ITEM_SUCCESS';
    readonly SESSION_HYDRATION_COMPLETED: 'APP_SESSION_HYDRATION_COMPLETED';
    readonly SESSION_HYDRATION_STARTED: 'APP_SESSION_HYDRATION_STARTED';
    readonly UPDATE_ITEM_ERROR: 'APP_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'APP_UPDATE_ITEM_SUCCESS';
};
interface AppState {
    network?: {
        error?: Error;
        status?: boolean;
    };
    sessionHydrated?: boolean;
}
export declare const defaultValues: AppState;
export declare const appStore: (type: string, data: Partial<AppState>, state?: AppState) => AppState;
export declare const app: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: AppState) => AppState;
    initialState: AppState;
    name: string;
};
export {};
