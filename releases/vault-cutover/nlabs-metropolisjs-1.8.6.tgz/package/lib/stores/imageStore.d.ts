import type { ImageType } from '../adapters/imageAdapter/imageAdapter.js';
export declare const IMAGE_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'IMAGE_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'IMAGE_ADD_ITEM_SUCCESS';
    readonly GENERATE_ERROR: 'IMAGE_GENERATE_ERROR';
    readonly GENERATE_SUCCESS: 'IMAGE_GENERATE_SUCCESS';
    readonly GET_COUNT_ERROR: 'IMAGE_GET_COUNT_ERROR';
    readonly GET_COUNT_SUCCESS: 'IMAGE_GET_COUNT_SUCCESS';
    readonly GET_ITEM_ERROR: 'IMAGE_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'IMAGE_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'IMAGE_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'IMAGE_GET_LIST_SUCCESS';
    readonly OPEN: 'IMAGE_OPEN';
    readonly REMOVE_ITEM_ERROR: 'IMAGE_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'IMAGE_REMOVE_ITEM_SUCCESS';
    readonly UPDATE_ITEM_ERROR: 'IMAGE_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'IMAGE_UPDATE_ITEM_SUCCESS';
    readonly UPLOAD_ITEM_ERROR: 'IMAGE_UPLOAD_ITEM_ERROR';
    readonly UPLOAD_ITEM_SUCCESS: 'IMAGE_UPLOAD_ITEM_SUCCESS';
};
interface ImageState {
    lists: Record<string, ImageType[]>;
}
export declare const defaultValues: ImageState;
export declare const imageStore: (type: string, data: {
    list?: ImageType[];
    itemId?: string;
}, state?: ImageState) => ImageState;
export declare const images: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: ImageState) => ImageState;
    initialState: ImageState;
    name: string;
};
export {};
