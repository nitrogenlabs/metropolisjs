export declare const NOTIFICATION_CONSTANTS: {
    readonly ADD_ITEM_SUCCESS: 'NOTIFICATION_ADD_ITEM_SUCCESS';
    readonly CLEAR_ITEMS: 'NOTIFICATION_CLEAR_ITEMS';
    readonly SET_NATIVE_BINDING: 'NOTIFICATION_SET_NATIVE_BINDING';
};
export type NotificationType = Record<string, unknown> & {
    readonly added?: number;
    readonly content?: string;
    readonly from?: string;
    readonly modified?: number;
    readonly notificationId?: string;
    readonly read?: boolean;
    readonly to?: string;
    readonly type?: string;
};
export interface NotificationState {
    readonly nativeBindingKey?: string;
    readonly list: NotificationType[];
}
export declare const defaultValues: NotificationState;
export declare const notificationStore: (type: string, data: {
    notification?: NotificationType;
    nativeBindingKey?: string;
}, state?: NotificationState) => NotificationState;
export declare const notifications: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: NotificationState) => NotificationState;
    initialState: NotificationState;
    name: string;
};
