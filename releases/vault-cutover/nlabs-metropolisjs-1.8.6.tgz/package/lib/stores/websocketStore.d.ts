export declare const WEBSOCKET_CONSTANTS: {
    readonly CLOSE: 'WEBSOCKET_CLOSE';
    readonly ERROR: 'WEBSOCKET_ERROR';
    readonly MESSAGE: 'WEBSOCKET_MESSAGE';
    readonly OPEN: 'WEBSOCKET_OPEN';
};
interface WebSocketState {
    isOpen: boolean;
    data?: unknown;
    timestamp?: number;
}
export declare const defaultValues: WebSocketState;
export declare const websocketStore: (type: string, data: Partial<WebSocketState>, state?: WebSocketState) => WebSocketState;
export declare const websocket: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: WebSocketState) => WebSocketState;
    initialState: WebSocketState;
    name: string;
};
export {};
