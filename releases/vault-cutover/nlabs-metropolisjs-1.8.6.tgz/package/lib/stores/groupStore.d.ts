import type { GroupType } from '../types/groups.types.js';
export declare const GROUP_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'GROUP_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'GROUP_ADD_ITEM_SUCCESS';
    readonly GET_ITEM_ERROR: 'GROUP_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'GROUP_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'GROUP_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'GROUP_GET_LIST_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'GROUP_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'GROUP_REMOVE_ITEM_SUCCESS';
    readonly UPDATE_ITEM_ERROR: 'GROUP_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'GROUP_UPDATE_ITEM_SUCCESS';
};
export type GroupConstantsType = typeof GROUP_CONSTANTS[keyof typeof GROUP_CONSTANTS];
interface GroupState {
    lists: Record<string, GroupType[]>;
    viewed: Record<string, GroupType>;
}
export declare const defaultValues: GroupState;
export declare const groupStore: (type: string, data: {
    group?: GroupType;
    list?: GroupType[];
}, state?: GroupState) => GroupState;
export declare const groups: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: GroupState) => GroupState;
    initialState: GroupState;
    name: string;
};
export {};
