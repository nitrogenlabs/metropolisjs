import type { ReactionAdapterType as ReactionType, TagType, User } from '../adapters/index.js';
import type { PersonaType } from '../adapters/personaAdapter/personaAdapter.js';
export declare const USER_CONSTANTS: {
    readonly ADD_ITEM_ERROR: 'USER_ADD_ITEM_ERROR';
    readonly ADD_ITEM_SUCCESS: 'USER_ADD_ITEM_SUCCESS';
    readonly ADD_RELATION_ERROR: 'USER_ADD_RELATION_ERROR';
    readonly ADD_RELATION_SUCCESS: 'USER_ADD_RELATION_SUCCESS';
    readonly AUTHENTICATION_UPDATE: 'USER_AUTHENTICATION_UPDATE';
    readonly BILLING_SETUP_SESSION_SUCCESS: 'USER_BILLING_SETUP_SESSION_SUCCESS';
    readonly CONFIRM_SIGN_UP_ERROR: 'USER_CONFIRM_SIGN_UP_ERROR';
    readonly CONFIRM_SIGN_UP_SUCCESS: 'USER_CONFIRM_SIGN_UP_SUCCESS';
    readonly FORGOT_PASSWORD_ERROR: 'USER_FORGOT_PASSWORD_ERROR';
    readonly FORGOT_PASSWORD_SUCCESS: 'USER_FORGOT_PASSWORD_SUCCESS';
    readonly GET_DETAILS_SUCCESS: 'USER_GET_DETAILS_SUCCESS';
    readonly GET_ITEM_ERROR: 'USER_GET_ITEM_ERROR';
    readonly GET_ITEM_SUCCESS: 'USER_GET_ITEM_SUCCESS';
    readonly GET_LIST_ERROR: 'USER_GET_LIST_ERROR';
    readonly GET_LIST_SUCCESS: 'USER_GET_LIST_SUCCESS';
    readonly GET_SESSION_ERROR: 'USER_GET_SESSION_ERROR';
    readonly GET_SESSION_SUCCESS: 'USER_GET_SESSION_SUCCESS';
    readonly HAS_USER_REACTIONS: 'USER_HAS_USER_REACTIONS';
    readonly RECOVERY_ERROR: 'USER_RECOVERY_ERROR';
    readonly RECOVERY_SUCCESS: 'USER_RECOVERY_SUCCESS';
    readonly REMOVE_ITEM_ERROR: 'USER_REMOVE_ITEM_ERROR';
    readonly REMOVE_ITEM_SUCCESS: 'USER_REMOVE_ITEM_SUCCESS';
    readonly REMOVE_RELATION: 'USER_REMOVE_RELATION';
    readonly RESET_PASSWORD_ERROR: 'USER_RESET_PASSWORD_ERROR';
    readonly RESET_PASSWORD_SUCCESS: 'USER_RESET_PASSWORD_SUCCESS';
    readonly SIGN_IN_ERROR: 'USER_SIGN_IN_ERROR';
    readonly SIGN_IN_SUCCESS: 'USER_SIGN_IN_SUCCESS';
    readonly SIGN_OUT_ERROR: 'USER_SIGN_OUT_ERROR';
    readonly SIGN_OUT_SUCCESS: 'USER_SIGN_OUT_SUCCESS';
    readonly SIGN_UP_ERROR: 'USER_SIGN_UP_ERROR';
    readonly SIGN_UP_SUCCESS: 'USER_SIGN_UP_SUCCESS';
    readonly UPDATE_ITEM_ERROR: 'USER_UPDATE_ITEM_ERROR';
    readonly UPDATE_ITEM_SUCCESS: 'USER_UPDATE_ITEM_SUCCESS';
    readonly UPDATE_PERSONA_ERROR: 'USER_UPDATE_PERSONA_ERROR';
    readonly UPDATE_PERSONA_SUCCESS: 'USER_UPDATE_PERSONA_SUCCESS';
    readonly UPDATE_SESSION_ERROR: 'USER_UPDATE_SESSION_ERROR';
    readonly UPDATE_SESSION_SUCCESS: 'USER_UPDATE_SESSION_SUCCESS';
    readonly VERIFY_ERROR: 'USER_VERIFY_ERROR';
    readonly VERIFY_SUCCESS: 'USER_VERIFY_SUCCESS';
};
export type UserConstantsType = typeof USER_CONSTANTS[keyof typeof USER_CONSTANTS];
interface UserState {
    error?: Error;
    likes: string[];
    lists: Record<string, unknown>;
    session: Partial<User>;
    users: Record<string, Partial<User>>;
}
export declare const defaultValues: UserState;
export declare const countFieldMap: {
    like: string;
    view: string;
};
interface UserData {
    readonly error?: Error;
    readonly itemId?: string;
    readonly itemType?: string;
    readonly list?: User[];
    readonly persona?: PersonaType;
    readonly reaction?: ReactionType;
    readonly session?: User;
    readonly tag?: TagType;
    readonly user?: User;
}
export declare const userStore: (type: string, data: UserData, state?: UserState) => UserState;
export declare const users: {
    action: (type: string, data?: {
        [x: string]: any;
    } & import("../utils/cacheIngestion.js").CacheIngestionOptions, state?: UserState) => UserState;
    initialState: UserState;
    name: string;
};
export {};
