/** Creates a lock owned by one authentication context, with no global state. */
export declare const createSingleFlight: <T = void>() => ((operation: () => T | PromiseLike<T>) => Promise<T>);
