/**
 * Copyright (c) 2026-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
export declare const parseJwtExpiryMs: (token: string) => number;
export declare const parseJwtIssuedMs: (token: string) => number;
/** Strict hosted JWT time hints in epoch seconds; decoding never verifies a signature. */
export declare const parseStrictJwtTimeHints: (token: string) => {
    expires: number;
    issued: number;
} | undefined;
export declare const normalizeSession: (session?: Record<string, unknown>) => Record<string, unknown>;
export declare const isValidSession: (session?: Record<string, unknown>, now?: number) => boolean;
export declare const getRefreshWindowMinutes: (sessionLifetimeMinutes: number, sessionConfig?: SessionRefreshConfig) => number;
export interface SessionRefreshConfig {
    autoRefresh?: boolean;
    readonly maxMinutes?: number;
    readonly minMinutes?: number;
    readonly refreshAfterRatio?: number;
}
export type SessionRefreshDecision = 'inactive' | 'missing-expiry' | 'invalid-expiry' | 'expired' | 'refresh-due' | 'healthy';
export interface SessionRefreshInput {
    readonly active: boolean;
    readonly expiresAt: number | null | undefined;
    readonly mode: 'milliseconds' | 'roundedMinutes';
    readonly now: number;
    readonly refreshWindowMs: number;
}
export declare const getMinutesUntil: (expiresAt: number, now?: number) => number;
export declare const getSessionRefreshDecision: ({ active, expiresAt, mode, now, refreshWindowMs }: SessionRefreshInput) => SessionRefreshDecision;
export declare const shouldRefreshSession: (session: Record<string, unknown>, sessionConfig?: SessionRefreshConfig, now?: number) => boolean;
