/** Nonsecret browser projection of the Reaktor opaque-session HTTP identity. */
export interface WebSessionIdentity {
    readonly idleExpiresAt: number;
    readonly observedAt: number;
    readonly sid: string;
    readonly userId: string;
    readonly username: string;
}
export interface WebSessionScope {
    readonly appId: string;
    readonly environment: string;
    readonly ownerUserId: string;
}
export type WebSessionEndReason = 'expired' | 'rejected' | 'replaced' | 'signout';
export interface WebSessionObservation {
    readonly deadline: number;
    readonly identity: WebSessionIdentity;
}
export declare const DEFAULT_WEB_SESSION_IDLE_MS = 3600000;
export declare const MAX_WEB_SESSION_IDLE_MS = 86400000;
export declare const validWebSessionIdleMs: (value: unknown) => value is number;
/** Database time defines the budget; monotonic elapsed time can only shorten it. */
export declare const observeWebSession: (value: unknown, ownerUserId: string, started: number, received: number, previous?: WebSessionObservation, idleMs?: number) => WebSessionObservation;
export declare const webSessionNeedsVerification: (deadline: number, now: number, resumed: boolean) => boolean;
