import type { DurableChatFields, DurableChatOperation } from './documents.js';
export { createDurableChatDocuments } from './documents.js';
export type { DurableChatFields, DurableChatOperation } from './documents.js';
export type DurableChatProtocol = {
    readonly [K in DurableChatOperation]: {
        readonly input: unknown;
        readonly result: unknown;
    };
};
export type DurableChatErrorCode = 'conflict' | 'forbidden' | 'invalid_request' | 'rate_limited' | 'unavailable';
export declare class DurableChatError extends Error {
    readonly code: DurableChatErrorCode;
    constructor(code: DurableChatErrorCode);
}
export declare const createDurableChatVariables: (operation: DurableChatOperation, input: unknown) => Record<string, unknown>;
export interface DurableChatOptions<Protocol extends DurableChatProtocol, Context> {
    readonly endpoint: string;
    readonly fields?: Partial<DurableChatFields>;
    readonly project: <K extends DurableChatOperation>(operation: K, value: unknown) => Protocol[K]['result'];
    readonly request: (endpoint: string, body: {
        readonly query: string;
        readonly variables: Record<string, unknown>;
    }, context: Context) => Promise<unknown>;
}
/** Opt-in top-level protocol. Transport owns authentication; only projected results leave this boundary. */
export declare const createDurableChatActions: <Protocol extends DurableChatProtocol = DurableChatProtocol, Context = void>(options: DurableChatOptions<Protocol, Context>) => {
    request: <K extends DurableChatOperation>(operation: K, input: Protocol[K]['input'], context: Context) => Promise<Protocol[K]['result']>;
};
