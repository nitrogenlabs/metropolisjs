/** Selection sets are configurable; product policy and response validation belong to the caller. */
export interface DurableChatFields {
    readonly attachment: string;
    readonly conversation: string;
    readonly invite: string;
    readonly membership: string;
    readonly message: string;
    readonly reaction: string;
    readonly receipt: string;
}
export declare const createDurableChatDocuments: (fields?: Partial<DurableChatFields>) => {
    readonly acceptInvite: string;
    readonly changeMemberRole: string;
    readonly chatContacts: 'query($after:ID,$limit:Int){chatContacts(after:$after,limit:$limit){name personaId}}';
    readonly createDirect: string;
    readonly createGroup: string;
    readonly declineInvite: string;
    readonly deleteMessage: string;
    readonly editMessage: string;
    readonly history: `query($input:HistoryInput!){history(input:$input){eventCursor messages{${string}} nextCursor}}`;
    readonly inbox: `query($input:InboxInput!){inbox(input:$input){${string} archived muted unreadCount}}`;
    readonly invitations: `query{invitations(limit:50){${string}}}`;
    readonly inviteMember: string;
    readonly leaveConversation: string;
    readonly participants: `query($conversationId:ID!){participants(conversationId:$conversationId){${string}}}`;
    readonly reactions: `query($input:MessageTarget!){reactions(input:$input){${string}}}`;
    readonly receipts: `query($conversationId:ID!){receipts(conversationId:$conversationId){${string}}}`;
    readonly removeMember: string;
    readonly replayEvents: 'query($input:ReplayInput!){replayEvents(input:$input){cursor events{conversationId eventId eventSequence kind resourceId revision} resyncRequired}}';
    readonly sendMessage: string;
    readonly setInboxState: string;
    readonly setReaction: string;
    readonly setTyping: string;
    readonly socketTicket: 'mutation{socketTicket{expiresAt ticket url}}';
    readonly transferOwnership: string;
    readonly typing: 'query($conversationId:ID!){typing(conversationId:$conversationId){expiresAt personaId}}';
    readonly updateReceipt: string;
};
export type DurableChatOperation = keyof ReturnType<typeof createDurableChatDocuments>;
