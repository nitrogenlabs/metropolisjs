import type { FluxFramework } from '@nlabs/arkhamjs';
import type { TranslationInputType } from '../../adapters/translationAdapter/translationAdapter.js';
import type { TranslationType } from '../../stores/translationStore.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
import type { BaseAdapterOptions } from '../../utils/validatorFactory.js';
export interface TranslationActionsOptions {
    translationAdapter?: (input: unknown, options?: BaseAdapterOptions) => any;
    translationAdapterOptions?: BaseAdapterOptions;
    autoSyncI18n?: boolean;
}
export type TranslationApiResultsType = {
    translations: {
        addTranslations: TranslationType[];
        getTranslations: TranslationType[];
    };
};
export interface TranslationActions {
    addTranslations: (translations: TranslationInputType[], translationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<TranslationType[]>;
    getTranslation: (key: string, locale: string, namespace?: string) => string | null;
    getTranslations: (keys: string[], locale: string, namespace?: string, translationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<TranslationType[]>;
    hasTranslation: (key: string, locale: string, namespace?: string) => boolean;
    processPendingTranslations: (locale: string, namespace?: string, requestOptions?: ActionRequestOptions) => Promise<void>;
    queueTranslationKey: (key: string, locale: string, namespace?: string) => void;
    syncWithI18n: () => void;
    updateTranslationAdapter: (adapter: (input: unknown, options?: BaseAdapterOptions) => any) => void;
    updateTranslationAdapterOptions: (options: BaseAdapterOptions) => void;
}
export declare const createTranslationActions: (flux: FluxFramework, options?: TranslationActionsOptions) => TranslationActions;
