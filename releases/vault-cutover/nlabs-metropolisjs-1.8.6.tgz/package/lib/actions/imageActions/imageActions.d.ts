import type { FluxFramework } from '@nlabs/arkhamjs';
import type { ImageType } from '../../adapters/imageAdapter/imageAdapter.js';
import type { ImageGenerationInput, ImageGenerationResult } from '../../types/imageGeneration.types.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface ImageAdapterOptions {
    strict?: boolean;
    allowPartial?: boolean;
    environment?: 'development' | 'production' | 'test';
    customValidation?: (input: unknown) => unknown;
}
export interface ImageActionsOptions {
    imageAdapter?: (input: unknown, options?: ImageAdapterOptions) => any;
    imageAdapterOptions?: ImageAdapterOptions;
}
export type ImageApiResultsType = {
    addImage: ImageType;
    deleteImage: ImageType;
    image: ImageType;
    getImageById: ImageType;
    getImageListByItem: ImageType[];
    imagesByPersonaReactions: ImageType[];
    getImageListByReactions: ImageType[];
    updateImage: ImageType;
    uploadFileImages: ImageType[];
    getImageCount: number;
};
export type GenerateImage = <TInput extends {
    provider: string;
} = ImageGenerationInput, TResult = ImageGenerationResult>(input: TInput, options?: {
    transport?: (input: TInput) => Promise<TResult>;
}) => Promise<TResult>;
export interface ImageActions {
    generateImage: GenerateImage;
    add: (image: Partial<ImageType>, type?: string, requestOptions?: ActionRequestOptions) => Promise<ImageType>;
    delete: (imageId: string, imageProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ImageType>;
    getImageById: (imageId: string, imageProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ImageType>;
    update: (image: Partial<ImageType>, type?: string, requestOptions?: ActionRequestOptions) => Promise<ImageType>;
    upload: (imageFiles: File[], itemId: string, itemType?: string, requestOptions?: ActionRequestOptions) => Promise<ImageType[]>;
    countByItem: (itemId: string, requestOptions?: ActionRequestOptions) => Promise<number>;
    listByItem: (itemId: string, itemType?: string, from?: number, to?: number, imageProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ImageType[]>;
    listByPersonaReactions: (personaId: string, reactions: string[], from?: number, to?: number, imageProps?: string[], listKey?: string, requestOptions?: ActionRequestOptions) => Promise<ImageType[]>;
    listByReactions: (reactions: string[], from?: number, to?: number, imageProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ImageType[]>;
    updateImageAdapter: (adapter: (input: unknown, options?: ImageAdapterOptions) => any) => void;
    updateImageAdapterOptions: (options: ImageAdapterOptions) => void;
}
/**
 * Factory function to create ImageActions with enhanced adapter injection capabilities.
 * Custom adapters are merged with default behavior, allowing partial overrides.
 *
 * @example
 * // Basic usage with default adapters
 * const imageActions = createImageActions(flux);
 *
 * @example
 * // Custom adapter that extends default behavior
 * const customImageAdapter = (input: unknown, options?: ImageAdapterOptions) => {
 *   // input is already validated by default adapter
 *   if (input.fileSize && input.fileSize > 5000000) {
 *     throw new Error('Image file too large');
 *   }
 *   return input;
 * };
 *
 * const imageActions = createImageActions(flux, {
 *   imageAdapter: customImageAdapter
 * });
 */
export declare const createImageActions: (flux: FluxFramework, options?: ImageActionsOptions) => ImageActions;
