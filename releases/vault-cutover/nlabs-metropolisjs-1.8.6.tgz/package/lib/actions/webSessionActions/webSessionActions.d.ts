import type { FluxFramework } from '@nlabs/arkhamjs';
import type { WebSessionActions, WebSessionOptions } from '../../utils/webSessionRuntime.js';
export type { WebSessionEndReason, WebSessionIdentity, WebSessionScope } from '../../session/webSessionPolicy.js';
export type { WebSessionActions, WebSessionCredentials, WebSessionOptions } from '../../utils/webSessionRuntime.js';
export declare const createWebSessionActions: (flux: FluxFramework, input: WebSessionOptions) => WebSessionActions;
