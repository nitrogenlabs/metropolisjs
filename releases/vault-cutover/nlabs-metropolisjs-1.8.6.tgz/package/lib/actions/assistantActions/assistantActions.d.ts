import type { FluxFramework } from '@nlabs/arkhamjs';
export interface AssistantContext {
    readonly context?: string;
    readonly knowledge?: unknown;
    readonly language?: string;
    readonly name?: string;
}
export interface AssistantChatInput extends AssistantContext {
    readonly history?: readonly {
        role: string;
        text: string;
    }[];
    readonly question: string;
}
export interface AssistantChatResult {
    readonly answer: string;
    readonly sources?: {
        title: string;
        url: string;
    }[];
    readonly supportSuggested?: boolean;
}
export interface AssistantFaqResult {
    readonly items: {
        answer: string;
        id: string;
        question: string;
        sources: {
            title: string;
            url: string;
        }[];
    }[];
}
export interface AssistantSupportInput extends AssistantContext {
    readonly company?: string;
    readonly confirmed: boolean;
    readonly email?: string;
    readonly firstName?: string;
    readonly lastName?: string;
    readonly message: string;
    readonly phone?: string;
    readonly requestId: string;
}
export interface AssistantSupportResult {
    readonly queued?: boolean;
    readonly ticketNumber?: string;
}
export interface AssistantActionsOptions {
    /** Scope state and events when several assistants share a Flux instance. */
    readonly instanceId?: string;
}
export interface AssistantActions {
    chat: (input: AssistantChatInput) => Promise<AssistantChatResult>;
    faqs: (input: AssistantContext) => Promise<AssistantFaqResult>;
    submitSupport: (input: AssistantSupportInput) => Promise<AssistantSupportResult>;
}
export declare const createAssistantActions: (flux: FluxFramework, options?: AssistantActionsOptions) => AssistantActions;
