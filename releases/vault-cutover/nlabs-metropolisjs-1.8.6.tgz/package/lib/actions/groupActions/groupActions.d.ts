import type { FluxFramework } from '@nlabs/arkhamjs';
import type { GroupType } from '../../types/groups.types.js';
import type { BaseAdapterOptions } from '../../utils/validatorFactory.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface GroupAdapterOptions extends BaseAdapterOptions {
}
export interface GroupActionsOptions {
    groupAdapter?: (input: unknown, options?: GroupAdapterOptions) => any;
    groupAdapterOptions?: GroupAdapterOptions;
}
export type GroupApiResultsType = {
    groups: {
        addGroup: GroupType;
        getGroup: GroupType;
        getGroupsByLatest: GroupType[];
        deleteGroup: GroupType;
        updateGroup: GroupType;
    };
};
export interface GroupActions {
    add: (groupData: Partial<GroupType>, groupProps?: string[], requestOptions?: ActionRequestOptions) => Promise<GroupType>;
    itemById: (groupId: string, groupProps?: string[], requestOptions?: ActionRequestOptions) => Promise<GroupType>;
    listByLatest: (from?: number, to?: number, groupProps?: string[], requestOptions?: ActionRequestOptions) => Promise<GroupType[]>;
    delete: (groupId: string, groupProps?: string[], requestOptions?: ActionRequestOptions) => Promise<GroupType>;
    update: (group: Partial<GroupType>, groupProps?: string[], requestOptions?: ActionRequestOptions) => Promise<GroupType>;
    updateGroupAdapter: (adapter: (input: unknown, options?: GroupAdapterOptions) => any) => void;
    updateGroupAdapterOptions: (options: GroupAdapterOptions) => void;
}
export declare const createGroupActions: (flux: FluxFramework, options?: GroupActionsOptions) => GroupActions;
