import type { FluxFramework } from '@nlabs/arkhamjs';
import type { EventType } from '../../adapters/eventAdapter/eventAdapter.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface EventRsvpType {
    readonly added?: number;
    readonly eventId?: string;
    readonly feeCents?: number;
    readonly numberOfGuests?: number;
    readonly paymentId?: string;
    readonly subtotalCents?: number;
    readonly taxCents?: number;
    readonly ticketCostCents?: number;
    readonly totalCents?: number;
    readonly type?: string;
}
export interface EventRsvpInput {
    readonly eventId: string;
    readonly numberOfGuests?: number;
    readonly paymentType?: string;
}
export interface EventAdapterOptions {
    readonly strict?: boolean;
    readonly allowPartial?: boolean;
    readonly environment?: 'development' | 'production' | 'test';
    readonly customValidation?: (input: unknown) => unknown;
}
export interface EventActionsOptions {
    readonly eventAdapter?: (input: unknown, options?: EventAdapterOptions) => any;
    readonly eventAdapterOptions?: EventAdapterOptions;
}
export interface EventActions {
    readonly addEvent: (eventData: Partial<EventType>, eventProps?: string[], requestOptions?: ActionRequestOptions) => Promise<EventType>;
    readonly getEvent: (eventId: string, eventProps?: string[], requestOptions?: ActionRequestOptions) => Promise<EventType>;
    readonly getEventsByTags: (tags: string[], latitude: number, longitude: number, from?: number, to?: number, startDate?: number, eventProps?: string[], requestOptions?: ActionRequestOptions) => Promise<EventType[]>;
    readonly getEventsByReactions: (reactions: string[], latitude: number, longitude: number, from?: number, to?: number, startDate?: number, eventProps?: string[], requestOptions?: ActionRequestOptions) => Promise<EventType[]>;
    readonly rsvpEvent: (rsvp: EventRsvpInput, rsvpProps?: string[], requestOptions?: ActionRequestOptions) => Promise<EventRsvpType>;
    readonly deleteEvent: (eventId: string, eventProps?: string[], requestOptions?: ActionRequestOptions) => Promise<EventType>;
    readonly updateEvent: (event: Partial<EventType>, eventProps?: string[], requestOptions?: ActionRequestOptions) => Promise<EventType>;
    readonly updateEventAdapter: (adapter: (input: unknown, options?: EventAdapterOptions) => any) => void;
    readonly updateEventAdapterOptions: (options: EventAdapterOptions) => void;
}
/**
 * Factory function to create EventActions with enhanced adapter injection capabilities.
 * Custom adapters are merged with default behavior, allowing partial overrides.
 *
 * @example
 * // Basic usage with default adapters
 * const eventActions = createEventActions(flux);
 *
 * @example
 * // Custom adapter that extends default behavior
 * const customEventAdapter = (input: unknown, options?: EventAdapterOptions) => {
 *   // input is already validated by default adapter
 *   if (input.startDate && input.endDate && input.startDate > input.endDate) {
 *     throw new Error('Start date must be before end date');
 *   }
 *   return input;
 * };
 *
 * const eventActions = createEventActions(flux, {
 *   eventAdapter: customEventAdapter
 * });
 */
export declare const createEventActions: (flux: FluxFramework, options?: EventActionsOptions) => EventActions;
