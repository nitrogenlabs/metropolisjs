import type { FluxFramework } from '@nlabs/arkhamjs';
import type { ContentInputType, ContentType } from '../../adapters/contentAdapter/contentAdapter.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
import type { BaseAdapterOptions } from '../../utils/validatorFactory.js';
export interface ContentGenerationInput {
    maxTokens?: number;
    model?: string;
    prompt: string;
    provider: 'claude' | 'gemini' | 'grok' | 'openai';
    search?: boolean;
    system?: string;
}
export interface GeneratedContent {
    sources: {
        title: string;
        url: string;
    }[];
    text: string;
}
export interface ContentGenerationOptions<TInput, TResult> {
    /** Application-owned durable jobs may replace the immediate GraphQL operation. */
    transport?: (input: TInput) => Promise<TResult>;
}
export type GenerateContent = <TInput extends {
    provider: string;
} = ContentGenerationInput, TResult = GeneratedContent>(input: TInput, options?: ContentGenerationOptions<TInput, TResult>) => Promise<TResult>;
export declare const CONTENT_GENERATION_CONSTANTS: {
    readonly ERROR: 'CONTENT_GENERATION_ERROR';
    readonly SUCCESS: 'CONTENT_GENERATION_SUCCESS';
};
export type ContentAdapterOptions = BaseAdapterOptions;
export interface ContentActionsOptions {
    contentAdapter?: (input: unknown, _options?: ContentAdapterOptions) => any;
    contentAdapterOptions?: ContentAdapterOptions;
}
export type ContentApiResultsType = {
    contents: {
        addContent: ContentType;
        getContent: ContentType;
        getContentByKey: ContentType;
        getContentsByCategory: ContentType[];
        getContentsList: ContentType[];
        deleteContent: ContentType;
        updateContent: ContentType;
    };
};
export interface ContentActions {
    generateContent: GenerateContent;
    add: (contentData: ContentInputType, contentProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ContentType>;
    itemById: (contentId: string, contentProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ContentType>;
    itemByKey: (key: string, locale?: string, contentProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ContentType>;
    listByCategory: (category: string, contentProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ContentType[]>;
    list: (contentProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ContentType[]>;
    delete: (contentId: string, contentProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ContentType>;
    update: (content: ContentInputType, contentProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ContentType>;
    updateContentAdapter: (adapter: (input: unknown, _options?: ContentAdapterOptions) => any) => void;
    updateContentAdapterOptions: (options: ContentAdapterOptions) => void;
}
export declare const createContentActions: (flux: FluxFramework, options?: ContentActionsOptions) => ContentActions;
