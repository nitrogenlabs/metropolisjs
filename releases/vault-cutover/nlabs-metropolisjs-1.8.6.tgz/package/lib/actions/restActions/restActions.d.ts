import type { FluxFramework } from '@nlabs/arkhamjs';
import type { RestApiOptions, RestMethod } from '../../utils/api.js';
export declare const REST_CONSTANTS: {
    readonly REQUEST_ERROR: 'REST_REQUEST_ERROR';
    readonly REQUEST_SUCCESS: 'REST_REQUEST_SUCCESS';
};
export interface RestActionsOptions {
    readonly authenticate?: boolean;
    readonly requestOptions?: RestApiOptions;
}
export interface RestActions {
    delete: <T = unknown>(endpoint: string, params?: unknown, requestOptions?: RestApiOptions) => Promise<T>;
    get: <T = unknown>(endpoint: string, params?: unknown, requestOptions?: RestApiOptions) => Promise<T>;
    post: <T = unknown>(endpoint: string, params?: unknown, requestOptions?: RestApiOptions) => Promise<T>;
    put: <T = unknown>(endpoint: string, params?: unknown, requestOptions?: RestApiOptions) => Promise<T>;
    request: <T = unknown>(endpoint: string, method?: RestMethod, params?: unknown, requestOptions?: RestApiOptions) => Promise<T>;
}
export declare const createRestActions: (flux: FluxFramework, options?: RestActionsOptions) => RestActions;
