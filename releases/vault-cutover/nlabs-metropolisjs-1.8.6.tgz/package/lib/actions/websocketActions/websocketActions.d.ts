import Sockette from 'sockette';
import type { FluxFramework } from '@nlabs/arkhamjs';
import type { NotificationType } from '../../stores/notificationStore.js';
export interface WebSocketMessage {
    readonly action: string;
    readonly data?: Record<string, unknown>;
}
export interface WebsocketActionsOptions {
    authentication?: 'query' | 'message' | 'none';
    authenticateMessage?: (token: string) => Record<string, unknown>;
    /** Absolute URL-resolution/open budget; zero disables it. Defaults to 5000 milliseconds. */
    connectTimeoutMs?: number;
    /** False prevents reuse of an issued URL after transport failure. Defaults to true. */
    reconnect?: boolean;
    /** False disables the session registration frame. Defaults to true. */
    register?: boolean;
    /** Resolve a fresh complete URL for each explicit connection, for example a cookie-authenticated ticket. */
    resolveUrl?: () => Promise<string | undefined>;
    url?: string;
}
export interface WebsocketActions {
    readonly sendNotification: (notification: NotificationType) => NotificationType | null;
    readonly sendTyping: (conversationId: string, isTyping: boolean, options?: {
        readonly name?: string;
        readonly personaId?: string;
        readonly userId?: string;
        readonly username?: string;
        readonly users?: Array<Record<string, unknown>>;
    }) => void;
    readonly wsSend: (message: WebSocketMessage) => void;
    readonly wsClose: () => void;
    /** Single-flight connection that resolves on open, or null on failure, close or deadline. */
    readonly wsConnect: () => Promise<Sockette | null>;
    readonly onReceive: (event: any) => void;
    readonly onClose: (event: any) => void;
    readonly onError: (event: any) => void;
    readonly onOpen: (event: any) => void;
    readonly wsInit: (token?: string, personaId?: string) => Sockette | null;
}
export declare const createWebsocketActions: (flux: FluxFramework, options?: WebsocketActionsOptions) => WebsocketActions;
