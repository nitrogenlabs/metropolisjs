import type { FluxFramework } from '@nlabs/arkhamjs';
import type { AppType } from '../../types/apps.types.js';
import type { BaseAdapterOptions } from '../../utils/validatorFactory.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export type AppAdapterOptions = BaseAdapterOptions;
export interface AppActionsOptions {
    appAdapter?: (input: unknown, options?: AppAdapterOptions) => any;
    appAdapterOptions?: AppAdapterOptions;
}
export type AppApiResultsType = {
    apps: {
        add?: AppType;
        itemById?: AppType;
        list?: AppType[];
        remove?: AppType;
        update?: AppType;
    };
};
export interface AppActions {
    add: (appData: Partial<AppType>, appProps?: string[], requestOptions?: ActionRequestOptions) => Promise<AppType>;
    delete: (appId: string, appProps?: string[], requestOptions?: ActionRequestOptions) => Promise<AppType>;
    itemById: (appId: string, appProps?: string[], requestOptions?: ActionRequestOptions) => Promise<AppType>;
    list: (from?: number, to?: number, appProps?: string[], requestOptions?: ActionRequestOptions) => Promise<AppType[]>;
    update: (app: Partial<AppType>, appProps?: string[], requestOptions?: ActionRequestOptions) => Promise<AppType>;
    updateAppAdapter: (adapter: (input: unknown, options?: AppAdapterOptions) => any) => void;
    updateAppAdapterOptions: (options: AppAdapterOptions) => void;
}
export declare const createAppActions: (flux: FluxFramework, options?: AppActionsOptions) => AppActions;
