import type { FluxFramework } from '@nlabs/arkhamjs';
import type { User } from '../../adapters/userAdapter/userAdapter.js';
import type { SessionType } from '../../utils/api.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
import type { BaseAdapterOptions } from '../../utils/validatorFactory.js';
export type UserAdapterOptions = BaseAdapterOptions;
export interface UserActionsOptions {
    readonly userAdapter?: (input: unknown, options?: UserAdapterOptions) => any;
    readonly userAdapterOptions?: UserAdapterOptions;
}
export interface VerificationEmailOptions {
    readonly subject?: string;
    readonly template?: string;
    readonly text?: string;
}
export interface PasswordResetRequest {
    readonly email?: string;
    readonly phone?: string;
    readonly username?: string;
}
export interface PasswordResetConfirmation extends PasswordResetRequest {
    readonly code: string;
    readonly password: string;
    readonly type?: 'email' | 'phone';
}
export interface UserApiResultsType {
    readonly users: {
        readonly activeCount?: number;
        readonly addUser?: Partial<User>;
        readonly confirmCode?: boolean;
        readonly completeBillingSetupSession?: Partial<User>;
        readonly createBillingSetupSession?: string;
        readonly deactivate?: Partial<User>;
        readonly forgotPassword?: boolean;
        readonly itemById?: Partial<User>;
        readonly getUserByAttribute?: Partial<User>;
        readonly getUserBySession?: Partial<User>;
        readonly itemBySession?: Partial<User>;
        readonly itemByToken?: Partial<User>;
        readonly itemByUsername?: Partial<User>;
        readonly getUserList?: User[];
        readonly list?: User[];
        readonly listByConnection?: User[];
        readonly listByLatest?: User[];
        readonly listByReactions?: User[];
        readonly listByTags?: User[];
        readonly search?: User[];
        readonly refreshSession?: SessionType;
        readonly remove?: Partial<User>;
        readonly resetPassword?: boolean;
        readonly sendVerificationEmail?: boolean;
        readonly session?: Partial<User>;
        readonly signIn?: Partial<User>;
        readonly signUp?: Partial<User>;
        readonly deleteBillingCard?: Partial<User>;
        readonly updateUser?: Partial<User>;
        readonly updatePassword?: Partial<boolean>;
        readonly updatePlan?: Partial<User>;
    };
}
export interface UserActions {
    registerAndSignIn: (userInput: Partial<User>, expires?: number, userProps?: string[]) => Promise<SessionType>;
    addUser: (userInput: Partial<User>, userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User>;
    confirmCode: (code: number, { type, value }: {
        type: 'email' | 'phone';
        value: string;
    }, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    confirmSignUp: (code: string, type: 'email' | 'phone', requestOptions?: ActionRequestOptions) => Promise<boolean>;
    completeBillingSetupSession: (sessionId: string, userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User>;
    createBillingSetupSession: (returnUrl: string, requestOptions?: ActionRequestOptions) => Promise<string>;
    currentAuthenticatedUser: (requestOptions?: ActionRequestOptions) => Promise<User>;
    list: (userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User[]>;
    listByConnection: (userId: string, from?: number, to?: number, userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User[]>;
    itemById: (userId: string, userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User>;
    getUserByAttribute: (attribute: 'email' | 'username', value: string, userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User>;
    deleteBillingCard: (userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User>;
    listByLatest: (username?: string, from?: number, to?: number, userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User[]>;
    listByReactions: (username: string, reactionNames: string[], from?: number, to?: number, personaProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User[]>;
    listByTags: (username: string, tagNames: string[], from?: number, to?: number, personaProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User[]>;
    forgotPassword: (username: string, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    requestPasswordReset: (request: string | PasswordResetRequest, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    isLoggedIn: () => boolean;
    refreshSession: (token?: string, expires?: number, requestOptions?: ActionRequestOptions) => Promise<SessionType>;
    remove: (userId: string, requestOptions?: ActionRequestOptions) => Promise<User>;
    resetPassword: (username: string, password: string, code: string, type: 'email' | 'phone', requestOptions?: ActionRequestOptions) => Promise<boolean>;
    completePasswordReset: (confirmation: PasswordResetConfirmation, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    search: (query: string, userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User[]>;
    sendVerificationEmail: (email: string, emailOptions?: VerificationEmailOptions, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    session: (userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User>;
    signIn: (user: Partial<User>, expires?: number, requestOptions?: ActionRequestOptions) => Promise<SessionType>;
    signOut: (requestOptions?: ActionRequestOptions) => Promise<boolean>;
    signUp: (userInput: Partial<User>, userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User>;
    updatePassword: (password: string, newPassword: string, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    updateUser: (userInput: Partial<User>, userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User>;
    updatePlan: (planId: string, userProps?: string[], requestOptions?: ActionRequestOptions) => Promise<User>;
    updateUserAdapter: (adapter: (input: unknown, options?: UserAdapterOptions) => any) => void;
    updateUserAdapterOptions: (options: UserAdapterOptions) => void;
}
export declare const createUserActions: (flux: FluxFramework, options?: UserActionsOptions) => UserActions;
