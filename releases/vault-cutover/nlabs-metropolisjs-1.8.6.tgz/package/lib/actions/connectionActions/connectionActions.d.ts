import type { FluxFramework } from '@nlabs/arkhamjs';
import type { CollectionType, ConnectionType } from '../../constants/Collections.js';
import type { ApiResultsType } from '../../utils/api.js';
import type { ConnectionEdge } from '../../types/edges.types.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface ConnectionActions {
    addConnection: (fromType: CollectionType, fromId: string, toType: CollectionType, toId: string, connectionType?: ConnectionType, metadata?: Record<string, any>, requestOptions?: ActionRequestOptions) => Promise<ConnectionEdge>;
    getConnections: (fromType: CollectionType, fromId: string, toType?: CollectionType, filters?: Record<string, any>, requestOptions?: ActionRequestOptions) => Promise<ConnectionEdge[]>;
    removeConnection: (fromType: CollectionType, fromId: string, toType: CollectionType, toId: string, requestOptions?: ActionRequestOptions) => Promise<boolean>;
}
export interface ConnectionApiResultsType extends ApiResultsType {
    connections?: {
        add?: ConnectionEdge;
        list?: ConnectionEdge[];
        remove?: boolean;
    };
}
export declare const createConnectionActions: (flux: FluxFramework) => ConnectionActions;
