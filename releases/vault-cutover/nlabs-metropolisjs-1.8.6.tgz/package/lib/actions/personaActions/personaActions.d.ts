import type { FluxFramework } from '@nlabs/arkhamjs';
import type { PersonaType } from '../../adapters/personaAdapter/personaAdapter.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface PersonaAdapterOptions {
    readonly strict?: boolean;
    readonly allowPartial?: boolean;
    readonly environment?: 'development' | 'production' | 'test';
    readonly customValidation?: (input: unknown) => unknown;
}
export interface PersonaActionsOptions {
    readonly personaAdapter?: (input: unknown, options?: PersonaAdapterOptions) => any;
    readonly personaAdapterOptions?: PersonaAdapterOptions;
}
export interface PersonaApiResultsType {
    readonly personas: {
        readonly addConnection?: boolean;
        readonly addPersona?: PersonaType;
        readonly deleteConnection?: boolean;
        readonly deletePersona?: PersonaType;
        readonly getPersonaById?: PersonaType;
        readonly getPersonaListByIds?: PersonaType[];
        readonly listByRelation?: PersonaType[];
        readonly listByTags?: PersonaType[];
        readonly updatePersona?: PersonaType;
    };
}
export type PersonaRelationFilter = 'followers' | 'following' | 'friends';
export interface PersonaActions {
    readonly blockPersona: (targetPersonaId: string) => Promise<boolean>;
    readonly followPersona: (targetPersonaId: string) => Promise<boolean>;
    readonly addPersona: (personaData: Partial<PersonaType>, personaProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PersonaType>;
    readonly getPersonaById: (personaId: string, personaProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PersonaType>;
    readonly getPersonaListByIds: (personaIds: string[], personaProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PersonaType[]>;
    readonly listByRelation: (relation: PersonaRelationFilter, personaId?: string, from?: number, to?: number, personaProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PersonaType[]>;
    readonly listByTags: (username: string, tags: string[], from?: number, to?: number, personaProps?: string[], filters?: Record<string, unknown>, requestOptions?: ActionRequestOptions) => Promise<PersonaType[]>;
    readonly unfollowPersona: (targetPersonaId: string) => Promise<boolean>;
    readonly unblockPersona: (targetPersonaId: string) => Promise<boolean>;
    readonly deletePersona: (personaId: string, personaProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PersonaType>;
    readonly updatePersona: (persona: Partial<PersonaType>, personaProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PersonaType>;
    readonly updatePersonaAdapter: (adapter: (input: unknown, options?: PersonaAdapterOptions) => any) => void;
    readonly updatePersonaAdapterOptions: (options: PersonaAdapterOptions) => void;
}
export declare const syncPersonaToSession: (flux: FluxFramework, persona?: Partial<PersonaType>) => Promise<void>;
export declare const syncPersonaTagsToSession: (flux: FluxFramework, personaId?: string) => Promise<Record<string, unknown>>;
/**
 * Factory function to create PersonaActions with enhanced adapter injection capabilities.
 * Custom adapters are merged with default behavior, allowing partial overrides.
 *
 * @example
 * // Basic usage with default adapters
 * const personaActions = createPersonaActions(flux);
 *
 * @example
 * // Custom adapter that extends default behavior
 * const customPersonaAdapter = (input: unknown, options?: PersonaAdapterOptions) => {
 *   // input is already validated by default adapter
 *   return input;
 * };
 *
 * const personaActions = createPersonaActions(flux, {
 *   personaAdapter: customPersonaAdapter
 * });
 */
export declare const createPersonaActions: (flux: FluxFramework, options?: PersonaActionsOptions) => PersonaActions;
