import type { FluxFramework } from '@nlabs/arkhamjs';
import type { NativeNotificationActions } from '../../types/nativeNotifications.types.js';
export declare const createNativeNotificationActions: (flux: FluxFramework) => NativeNotificationActions;
