import type { FluxFramework } from '@nlabs/arkhamjs';
import type { PaymentPlanType, PaymentSubscriptionType } from '../../types/subscriptions.types.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export type SubscriptionApiResultsType = {
    subscriptions: {
        addPlan?: PaymentPlanType;
        addSubscription?: PaymentSubscriptionType;
        deleteSubscription?: boolean;
        getPlanByItem?: PaymentPlanType;
        getSubscription?: PaymentSubscriptionType;
        getSubscriptionListByUser?: PaymentSubscriptionType[];
        getSubscriptionByItem?: PaymentSubscriptionType;
    };
};
export interface SubscriptionActions {
    addPlan: (plan: Partial<PaymentPlanType>, planProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PaymentPlanType>;
    addSubscription: (subscription: Partial<PaymentSubscriptionType>, subscriptionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PaymentSubscriptionType>;
    deleteSubscription: (itemId: string, itemType?: string, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    getPlanByItem: (itemId: string, itemType?: string, planProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PaymentPlanType>;
    getSubscriptionListByUser: (userId: string, from?: number, to?: number, subscriptionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PaymentSubscriptionType[]>;
    getSubscriptionByItem: (itemId: string, itemType?: string, subscriptionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PaymentSubscriptionType>;
}
export declare const createSubscriptionActions: (flux: FluxFramework) => SubscriptionActions;
