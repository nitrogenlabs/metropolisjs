/**
 * Copyright (c) 2025-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import type { FluxFramework } from '@nlabs/arkhamjs';
export interface SSEEvent {
    readonly data: string;
    readonly event?: string;
    readonly id?: string;
    readonly retry?: number;
}
export interface SSEConnectionOptions {
    readonly headers?: Record<string, string>;
    readonly maxRetries?: number;
    readonly retryInterval?: number;
    readonly timeout?: number;
    readonly url: string;
    readonly withCredentials?: boolean;
}
export interface SSEActionsOptions {
    readonly onClose?: (event: CloseEvent) => void;
    readonly onError?: (error: Event) => void;
    readonly onMessage?: (event: SSEEvent) => void;
    readonly onOpen?: (event: Event) => void;
    readonly sseOptions?: SSEConnectionOptions;
}
export interface SSEActions {
    readonly connect: (options?: SSEConnectionOptions) => Promise<void>;
    readonly disconnect: () => void;
    readonly reconnect: () => Promise<void>;
    readonly isConnected: () => boolean;
    readonly sendMessage: (data: string, eventType?: string) => void;
    readonly addEventListener: (eventType: string, handler: (event: SSEEvent) => void) => void;
    readonly removeEventListener: (eventType: string, handler: (event: SSEEvent) => void) => void;
    readonly updateSSEOptions: (options: SSEActionsOptions) => void;
}
export declare const createSSEActions: (flux: FluxFramework, options?: SSEActionsOptions) => SSEActions;
