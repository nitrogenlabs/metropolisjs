import type { FluxFramework } from '@nlabs/arkhamjs';
import type { HiggsfieldRequest, MarketingStudioImageInput, SeedanceReferenceVideoInput, SeedanceVideoInput, SoulImageInput } from '../../adapters/higgsfieldAdapter/higgsfieldAdapter.js';
export declare const HIGGSFIELD_CONSTANTS: {
    readonly CANCEL_ERROR: 'HIGGSFIELD_CANCEL_ERROR';
    readonly CANCEL_SUCCESS: 'HIGGSFIELD_CANCEL_SUCCESS';
    readonly GENERATE_ERROR: 'HIGGSFIELD_GENERATE_ERROR';
    readonly GENERATE_SUCCESS: 'HIGGSFIELD_GENERATE_SUCCESS';
    readonly STATUS_ERROR: 'HIGGSFIELD_STATUS_ERROR';
    readonly STATUS_SUCCESS: 'HIGGSFIELD_STATUS_SUCCESS';
};
export interface HiggsfieldActions {
    cancelRequest: (requestId: string) => Promise<boolean>;
    generateMarketingStudioImage: (input: MarketingStudioImageInput, webhookUrl?: string) => Promise<HiggsfieldRequest>;
    generateSeedanceReferenceVideo: (input: SeedanceReferenceVideoInput, webhookUrl?: string) => Promise<HiggsfieldRequest>;
    generateSeedanceVideo: (input: SeedanceVideoInput, webhookUrl?: string) => Promise<HiggsfieldRequest>;
    generateSoulImage: (input: SoulImageInput, webhookUrl?: string) => Promise<HiggsfieldRequest>;
    getRequestStatus: (requestId: string) => Promise<HiggsfieldRequest>;
}
export declare const createHiggsfieldActions: (flux: FluxFramework) => HiggsfieldActions;
