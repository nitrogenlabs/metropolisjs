import type { FluxFramework } from '@nlabs/arkhamjs';
import type { LocationType } from '../../adapters/locationAdapter/locationAdapter.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface LocationAdapterOptions {
    strict?: boolean;
    allowPartial?: boolean;
    environment?: 'development' | 'production' | 'test';
    customValidation?: (input: unknown) => unknown;
}
export interface LocationActionsOptions {
    locationAdapter?: (input: unknown, options?: LocationAdapterOptions) => any;
    locationAdapterOptions?: LocationAdapterOptions;
}
export type LocationApiResultsType = {
    addLocation: LocationType;
    deleteLocation: LocationType;
    getLocation: LocationType;
    getLocationsByItem: LocationType[];
    updateLocation: LocationType;
};
export interface LocationActions {
    autocompleteLocation: (address: string, latitude?: number, longitude?: number, locationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<LocationType[]>;
    add: (location: Partial<LocationType>, locationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<LocationType>;
    delete: (locationId: string, requestOptions?: ActionRequestOptions) => Promise<LocationType>;
    getCurrentLocation: (setLocation?: (location: LocationType) => void, requestOptions?: ActionRequestOptions) => Promise<LocationType>;
    getGoogleLocation: (address: string, requestOptions?: ActionRequestOptions) => Promise<{
        latitude: number;
        location: string;
        longitude: number;
    }>;
    getLocation: (location: Partial<LocationType>, locationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<LocationType>;
    listByItem: (itemId: string, locationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<LocationType[]>;
    update: (location: Partial<LocationType>, locationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<LocationType>;
    updateLocationAdapter: (adapter: (input: unknown, options?: LocationAdapterOptions) => any) => void;
    updateLocationAdapterOptions: (options: LocationAdapterOptions) => void;
}
/**
 * Factory function to create LocationActions with enhanced adapter injection capabilities.
 * Custom adapters are merged with default behavior, allowing partial overrides.
 *
 * @example
 * // Basic usage with default adapters
 * const locationActions = createLocationActions(flux);
 *
 * @example
 * // Custom adapter that extends default behavior
 * const customLocationAdapter = (input: unknown, options?: LocationAdapterOptions) => {
 *   // input is already validated by default adapter
 *   if (input.latitude && (input.latitude < -90 || input.latitude > 90)) {
 *     throw new Error('Invalid latitude');
 *   }
 *   return input;
 * };
 *
 * const locationActions = createLocationActions(flux, {
 *   locationAdapter: customLocationAdapter
 * });
 */
export declare const createLocationActions: (flux: FluxFramework, options?: LocationActionsOptions) => LocationActions;
