import type { FluxFramework } from '@nlabs/arkhamjs';
import type { PostType } from '../../adapters/postAdapter/postAdapter.js';
import type { BaseAdapterOptions } from '../../utils/validatorFactory.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface PostAdapterOptions extends BaseAdapterOptions {
}
export interface PostActionsOptions {
    postAdapter?: (input: unknown, options?: PostAdapterOptions) => any;
    postAdapterOptions?: PostAdapterOptions;
}
export type PostApiResultsType = {
    posts: {
        addPost: PostType;
        getPost: PostType;
        getPostsByLatest: PostType[];
        getPostsByLocation: PostType[];
        getPostsByReactions: PostType[];
        getPostsByTags: PostType[];
        deletePost: PostType;
        updatePost: PostType;
    };
};
export interface PostActions {
    add: (postData: Partial<PostType>, postProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PostType>;
    itemById: (postId: string, postProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PostType>;
    listByLatest: (from?: number, to?: number, postProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PostType[]>;
    listByLocation: (latitude: number, longitude: number, from?: number, to?: number, postProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PostType[]>;
    listByReactions: (reactionNames: string[], latitude: number, longitude: number, from?: number, to?: number, postProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PostType[]>;
    listByTags: (tags: string[], latitude: number, longitude: number, from?: number, to?: number, postProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PostType[]>;
    delete: (postId: string, postProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PostType>;
    update: (post: Partial<PostType>, postProps?: string[], requestOptions?: ActionRequestOptions) => Promise<PostType>;
    updatePostAdapter: (adapter: (input: unknown, options?: PostAdapterOptions) => any) => void;
    updatePostAdapterOptions: (options: PostAdapterOptions) => void;
}
export declare const createPostActions: (flux: FluxFramework, options?: PostActionsOptions) => PostActions;
