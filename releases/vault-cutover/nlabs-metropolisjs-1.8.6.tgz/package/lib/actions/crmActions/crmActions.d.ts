import type { FluxFramework } from '@nlabs/arkhamjs';
import type { User } from '../../adapters/userAdapter/userAdapter.js';
import type { ApiOptions } from '../../utils/api.js';
import type { CustomerNotification, CustomerOrder, MailingList, ShopifyCustomerOrderInput, SupportTicket, SupportTicketEvent, SupportTicketMessage, SupportTicketStatus } from '../../types/crm.types.js';
export declare const CRM_CONSTANTS: {
    readonly ADD_SUPPORT_TICKET_MESSAGE_ERROR: 'CRM_ADD_SUPPORT_TICKET_MESSAGE_ERROR';
    readonly ADD_SUPPORT_TICKET_MESSAGE_SUCCESS: 'CRM_ADD_SUPPORT_TICKET_MESSAGE_SUCCESS';
    readonly ADD_USER_TO_MAILING_LIST_ERROR: 'CRM_ADD_USER_TO_MAILING_LIST_ERROR';
    readonly ADD_USER_TO_MAILING_LIST_SUCCESS: 'CRM_ADD_USER_TO_MAILING_LIST_SUCCESS';
    readonly CREATE_MAILING_LIST_ERROR: 'CRM_CREATE_MAILING_LIST_ERROR';
    readonly CREATE_MAILING_LIST_SUCCESS: 'CRM_CREATE_MAILING_LIST_SUCCESS';
    readonly CREATE_SUPPORT_TICKET_ERROR: 'CRM_CREATE_SUPPORT_TICKET_ERROR';
    readonly CREATE_SUPPORT_TICKET_SUCCESS: 'CRM_CREATE_SUPPORT_TICKET_SUCCESS';
    readonly CUSTOMER_NOTIFICATIONS_BY_USER_ERROR: 'CRM_CUSTOMER_NOTIFICATIONS_BY_USER_ERROR';
    readonly CUSTOMER_NOTIFICATIONS_BY_USER_SUCCESS: 'CRM_CUSTOMER_NOTIFICATIONS_BY_USER_SUCCESS';
    readonly CUSTOMER_ORDERS_BY_USER_ERROR: 'CRM_CUSTOMER_ORDERS_BY_USER_ERROR';
    readonly CUSTOMER_ORDERS_BY_USER_SUCCESS: 'CRM_CUSTOMER_ORDERS_BY_USER_SUCCESS';
    readonly ELIGIBLE_MAILING_USERS_ERROR: 'CRM_ELIGIBLE_MAILING_USERS_ERROR';
    readonly ELIGIBLE_MAILING_USERS_SUCCESS: 'CRM_ELIGIBLE_MAILING_USERS_SUCCESS';
    readonly INGEST_SHOPIFY_CUSTOMER_ORDER_ERROR: 'CRM_INGEST_SHOPIFY_CUSTOMER_ORDER_ERROR';
    readonly INGEST_SHOPIFY_CUSTOMER_ORDER_SUCCESS: 'CRM_INGEST_SHOPIFY_CUSTOMER_ORDER_SUCCESS';
    readonly MAILING_LIST_USERS_ERROR: 'CRM_MAILING_LIST_USERS_ERROR';
    readonly MAILING_LIST_USERS_SUCCESS: 'CRM_MAILING_LIST_USERS_SUCCESS';
    readonly MAILING_LISTS_ERROR: 'CRM_MAILING_LISTS_ERROR';
    readonly MAILING_LISTS_SUCCESS: 'CRM_MAILING_LISTS_SUCCESS';
    readonly REMOVE_USER_FROM_MAILING_LIST_ERROR: 'CRM_REMOVE_USER_FROM_MAILING_LIST_ERROR';
    readonly REMOVE_USER_FROM_MAILING_LIST_SUCCESS: 'CRM_REMOVE_USER_FROM_MAILING_LIST_SUCCESS';
    readonly SUPPORT_TICKET_EVENTS_ERROR: 'CRM_SUPPORT_TICKET_EVENTS_ERROR';
    readonly SUPPORT_TICKET_EVENTS_SUCCESS: 'CRM_SUPPORT_TICKET_EVENTS_SUCCESS';
    readonly SUPPORT_TICKET_MESSAGES_ERROR: 'CRM_SUPPORT_TICKET_MESSAGES_ERROR';
    readonly SUPPORT_TICKET_MESSAGES_SUCCESS: 'CRM_SUPPORT_TICKET_MESSAGES_SUCCESS';
    readonly SUPPORT_TICKETS_ERROR: 'CRM_SUPPORT_TICKETS_ERROR';
    readonly SUPPORT_TICKETS_SUCCESS: 'CRM_SUPPORT_TICKETS_SUCCESS';
    readonly UPDATE_SUPPORT_TICKET_STATUS_ERROR: 'CRM_UPDATE_SUPPORT_TICKET_STATUS_ERROR';
    readonly UPDATE_SUPPORT_TICKET_STATUS_SUCCESS: 'CRM_UPDATE_SUPPORT_TICKET_STATUS_SUCCESS';
    readonly USERS_BY_PURCHASED_PRODUCT_ERROR: 'CRM_USERS_BY_PURCHASED_PRODUCT_ERROR';
    readonly USERS_BY_PURCHASED_PRODUCT_SUCCESS: 'CRM_USERS_BY_PURCHASED_PRODUCT_SUCCESS';
};
export interface CrmActionsOptions {
}
export type CrmApiResultsType = {
    readonly crm: {
        readonly addSupportTicketMessage?: SupportTicketMessage;
        readonly addUserToMailingList?: MailingList;
        readonly createMailingList?: MailingList;
        readonly createSupportTicket?: SupportTicket;
        readonly customerNotificationsByUser?: CustomerNotification[];
        readonly customerOrdersByUser?: CustomerOrder[];
        readonly eligibleMailingUsers?: User[];
        readonly ingestShopifyCustomerOrder?: CustomerOrder;
        readonly mailingLists?: MailingList[];
        readonly mailingListUsers?: User[];
        readonly removeUserFromMailingList?: boolean;
        readonly supportTicketEvents?: SupportTicketEvent[];
        readonly supportTicketMessages?: SupportTicketMessage[];
        readonly supportTickets?: SupportTicket[];
        readonly updateSupportTicketStatus?: SupportTicket;
        readonly usersByPurchasedProduct?: User[];
    };
};
export interface CrmActions {
    readonly addSupportTicketMessage: (message: Partial<SupportTicketMessage>, messageProps?: string[], requestOptions?: ApiOptions) => Promise<SupportTicketMessage>;
    readonly addUserToMailingList: (userId: string, mailingListId: string, source?: string, mailingListProps?: string[], requestOptions?: ApiOptions) => Promise<MailingList>;
    readonly createMailingList: (mailingList: Partial<MailingList>, mailingListProps?: string[], requestOptions?: ApiOptions) => Promise<MailingList>;
    readonly createSupportTicket: (ticket: Partial<SupportTicket>, ticketProps?: string[], requestOptions?: ApiOptions) => Promise<SupportTicket>;
    readonly customerNotificationsByUser: (userId: string, notificationProps?: string[], requestOptions?: ApiOptions) => Promise<CustomerNotification[]>;
    readonly customerOrdersByUser: (userId: string, orderProps?: string[], requestOptions?: ApiOptions) => Promise<CustomerOrder[]>;
    readonly eligibleMailingUsers: (options?: {
        readonly excludeOpenSupportTickets?: boolean;
        readonly mailingListId?: string;
        readonly productId?: string;
    }, userProps?: string[], requestOptions?: ApiOptions) => Promise<User[]>;
    readonly ingestShopifyCustomerOrder: (order: ShopifyCustomerOrderInput, orderProps?: string[], requestOptions?: ApiOptions) => Promise<CustomerOrder>;
    readonly mailingLists: (mailingListProps?: string[], requestOptions?: ApiOptions) => Promise<MailingList[]>;
    readonly mailingListUsers: (mailingListId: string, userProps?: string[], requestOptions?: ApiOptions) => Promise<User[]>;
    readonly removeUserFromMailingList: (userId: string, mailingListId: string, requestOptions?: ApiOptions) => Promise<boolean>;
    readonly supportTicketEvents: (supportTicketId: string, eventProps?: string[], requestOptions?: ApiOptions) => Promise<SupportTicketEvent[]>;
    readonly supportTicketMessages: (supportTicketId: string, messageProps?: string[], requestOptions?: ApiOptions) => Promise<SupportTicketMessage[]>;
    readonly supportTickets: (filters?: {
        readonly status?: string;
        readonly userId?: string;
    }, ticketProps?: string[], requestOptions?: ApiOptions) => Promise<SupportTicket[]>;
    readonly updateSupportTicketStatus: (supportTicketId: string, status: SupportTicketStatus, resolutionSummary?: string, ticketProps?: string[], requestOptions?: ApiOptions) => Promise<SupportTicket>;
    readonly usersByPurchasedProduct: (productId: string, userProps?: string[], requestOptions?: ApiOptions) => Promise<User[]>;
}
export declare const createCrmActions: (flux: FluxFramework, _options?: CrmActionsOptions) => CrmActions;
