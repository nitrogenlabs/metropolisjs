import type { FluxFramework } from '@nlabs/arkhamjs';
import type { WebSocketMessage } from '../websocketActions/websocketActions.js';
export declare const AWS_RUM_CONSTANTS: {
    readonly TRACK_ERROR: 'AWS_RUM_TRACK_ERROR';
    readonly TRACK_QUEUED: 'AWS_RUM_TRACK_QUEUED';
    readonly TRACK_SUCCESS: 'AWS_RUM_TRACK_SUCCESS';
};
export type AwsRumEventType = 'click' | 'page_view' | (string & {});
export type AwsRumProperty = boolean | number | string;
export interface AwsRumTrackInput {
    readonly name: string;
    readonly path?: string;
    readonly properties?: Record<string, AwsRumProperty>;
    readonly type: AwsRumEventType;
}
export interface AwsRumEvent extends AwsRumTrackInput {
    readonly eventId: string;
    readonly journeyId: string;
    readonly sequence: number;
    readonly timestamp: number;
}
export interface AwsRumActionsOptions {
    readonly analyticsId?: string;
    /**
     * Delivery transport for RUM batches. Defaults to `graphql`, which sends
     * batches with `rumRequest` (falling back to `navigator.sendBeacon` on
     * terminal flushes). `websocket` sends batches with `wsSend` instead,
     * queuing until the shared connection is open (same behavior as
     * `sendNotification`/`sendTyping`); falls back to `graphql` delivery only
     * when no `wsSend` was supplied.
     */
    readonly analyticsTransport?: 'graphql' | 'websocket';
    readonly debounceMs?: number;
    readonly dedupeMs?: number;
    readonly enabled?: boolean;
    readonly respectPrivacySignals?: boolean;
    readonly throttleMs?: number;
    readonly wsSend?: (message: WebSocketMessage) => void;
}
export interface AwsRumActions {
    readonly destroy: () => Promise<void>;
    readonly flush: (options?: AwsRumFlushOptions) => Promise<void>;
    readonly track: (event: AwsRumTrackInput) => void;
}
export interface AwsRumFlushOptions {
    /**
     * Prefer navigator.sendBeacon for terminal delivery. Falls back to the
     * standard RUM request when the Beacon API cannot accept the batch.
     */
    readonly useBeacon?: boolean;
}
export declare const createAwsRumActions: (flux: FluxFramework, options?: AwsRumActionsOptions) => AwsRumActions;
