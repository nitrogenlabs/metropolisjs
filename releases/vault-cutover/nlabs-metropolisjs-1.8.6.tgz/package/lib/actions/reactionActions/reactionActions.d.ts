/**
 * Copyright (c) 2019-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import type { FluxFramework } from '@nlabs/arkhamjs';
import type { ReactionType } from '../../adapters/reactionAdapter/reactionAdapter.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface ReactionAdapterOptions {
    strict?: boolean;
    allowPartial?: boolean;
    environment?: 'development' | 'production' | 'test';
    customValidation?: (input: unknown) => unknown;
}
export interface ReactionActionsOptions {
    reactionAdapter?: (input: unknown, options?: ReactionAdapterOptions) => any;
    reactionAdapterOptions?: ReactionAdapterOptions;
}
export type ReactionApiResultsType = {
    reactions: {
        addPersonaReaction: ReactionType;
        addReaction: ReactionType;
        deletePersonaReaction: ReactionType;
        deleteReaction: ReactionType;
        getReactionCount: number;
        hasPersonaReaction: boolean;
        hasReaction: boolean;
    };
};
export interface ReactionActions {
    addPersonaReaction: (personaId: string, itemId: string, itemType: string, reaction: Partial<ReactionType>, reactionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ReactionType>;
    addReaction: (itemId: string, itemType: string, reaction: Partial<ReactionType>, reactionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ReactionType>;
    deletePersonaReaction: (personaId: string, itemId: string, itemType: string, reactionName: string, reactionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ReactionType>;
    deleteReaction: (itemId: string, itemType: string, reactionName: string, reactionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ReactionType>;
    getReactionCount: (itemId: string, itemType: string, reactionName: string, requestOptions?: ActionRequestOptions) => Promise<number>;
    hasPersonaReaction: (personaId: string, itemId: string, itemType: string, reactionName: string, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    hasReaction: (itemId: string, itemType: string, reactionName: string, direction: string, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    abbreviateCount: (count: number) => string;
    updateReactionAdapter: (adapter: (input: unknown, options?: ReactionAdapterOptions) => any) => void;
    updateReactionAdapterOptions: (options: ReactionAdapterOptions) => void;
}
export declare const createReactionActions: (flux: FluxFramework, options?: ReactionActionsOptions) => ReactionActions;
