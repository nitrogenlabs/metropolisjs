import type { FluxFramework } from '@nlabs/arkhamjs';
import type { VideoMultipartUploadType, VideoType, VideoUploadPartInput, VideoUploadPartUrl } from '../../types/videos.types.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
import type { BaseAdapterOptions } from '../../utils/validatorFactory.js';
export type VideoAdapterOptions = BaseAdapterOptions;
export type VideoActionsOptions = Readonly<{
    provider?: string;
    videoAdapter?: (input: unknown, options?: VideoAdapterOptions) => any;
    videoAdapterOptions?: VideoAdapterOptions;
}>;
export type VideoApiResultsType = Readonly<{
    videos: Readonly<{
        add?: VideoType;
        abortMultipartUpload?: boolean;
        completeMultipartUpload?: VideoType;
        createMultipartUpload?: VideoMultipartUploadType;
        getMultipartUploadPartUrls?: VideoUploadPartUrl[];
        getVideoById?: VideoType;
        getVideoListByItem?: VideoType[];
        getVideoListByReactions?: VideoType[];
        list?: VideoType[];
        remove?: VideoType;
        update?: VideoType;
    }>;
}>;
export interface VideoGenerationInput {
    aspectRatio?: string;
    audioUrls?: string[];
    endImageUrl?: string;
    duration?: number;
    generateAudio?: boolean;
    imageUrl?: string;
    imageUrls?: string[];
    model?: string;
    modelInput?: Record<string, unknown>;
    outputFormat?: string;
    prompt?: string;
    provider?: string;
    resolution?: string;
    videoUrls?: string[];
}
export interface VideoGenerationResult {
    provider: string;
    status: string;
    cancelUrl?: string;
    requestId: string;
    statusUrl: string;
}
export type GenerateVideo = <TInput extends object = VideoGenerationInput, TResult = VideoGenerationResult>(input: TInput, options?: {
    transport?: (input: TInput) => Promise<TResult>;
}) => Promise<TResult>;
export type VideoActions = Readonly<{
    generateVideo: GenerateVideo;
    add: (videoData: Partial<VideoType>, videoProps?: string[], requestOptions?: ActionRequestOptions) => Promise<VideoType>;
    abortMultipartUpload: (videoId: string, uploadId: string, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    completeMultipartUpload: (videoId: string, uploadId: string, parts: VideoUploadPartInput[], videoProps?: string[], requestOptions?: ActionRequestOptions) => Promise<VideoType>;
    createMultipartUpload: (videoData: Partial<VideoType>, partCount: number, videoProps?: string[], requestOptions?: ActionRequestOptions) => Promise<VideoMultipartUploadType>;
    delete: (videoId: string, videoProps?: string[], requestOptions?: ActionRequestOptions) => Promise<VideoType>;
    getMultipartUploadPartUrls: (videoId: string, uploadId: string, partNumbers: number[], requestOptions?: ActionRequestOptions) => Promise<VideoUploadPartUrl[]>;
    getVideoById: (videoId: string, videoProps?: string[], requestOptions?: ActionRequestOptions) => Promise<VideoType>;
    list: (from?: number, to?: number, videoProps?: string[], requestOptions?: ActionRequestOptions) => Promise<VideoType[]>;
    listByItem: (itemId: string, from?: number, to?: number, videoProps?: string[], requestOptions?: ActionRequestOptions) => Promise<VideoType[]>;
    listByReactions: (reactions: string[], from?: number, to?: number, videoProps?: string[], requestOptions?: ActionRequestOptions) => Promise<VideoType[]>;
    update: (video: Partial<VideoType>, videoProps?: string[], requestOptions?: ActionRequestOptions) => Promise<VideoType>;
    updateVideoAdapter: (adapter: (input: unknown, options?: VideoAdapterOptions) => any) => void;
    updateVideoAdapterOptions: (options: VideoAdapterOptions) => void;
}>;
export declare const createVideoActions: (flux: FluxFramework, options?: VideoActionsOptions) => VideoActions;
