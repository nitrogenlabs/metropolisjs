import type { FluxFramework } from '@nlabs/arkhamjs';
import type { TagType } from '../../adapters/tagAdapter/tagAdapter.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface TagAdapterOptions {
    strict?: boolean;
    allowPartial?: boolean;
    environment?: 'development' | 'production' | 'test';
    customValidation?: (input: unknown) => unknown;
}
export interface TagActionsOptions {
    tagAdapter?: (input: unknown, options?: TagAdapterOptions) => any;
    tagAdapterOptions?: TagAdapterOptions;
}
export type TagApiResultsType = {
    tags: {
        addTag: TagType;
        addTagToItem: TagType;
        deleteTag: TagType;
        deleteTagFromItem: boolean;
        getTagsByItem: TagType[];
        getTags: TagType[];
        updateTag: TagType;
    };
};
export interface TagActions {
    addTag: (tag: Partial<TagType>, tagProps?: string[], requestOptions?: ActionRequestOptions) => Promise<TagType>;
    addTagToItem: (tagId: string, itemDocId?: string, tagProps?: string[], requestOptions?: ActionRequestOptions) => Promise<TagType>;
    deleteTag: (tagId: string, tagProps?: string[], requestOptions?: ActionRequestOptions) => Promise<TagType>;
    deleteTagFromItem: (tagId: string, itemDocId?: string, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    getTagsByItem: (itemDocId: string, tagProps?: string[], requestOptions?: ActionRequestOptions) => Promise<TagType[]>;
    getTags: (searchQuery?: string, tagProps?: string[], options?: ActionRequestOptions) => Promise<TagType[]>;
    updateTag: (tag: Partial<TagType>, tagProps?: string[], requestOptions?: ActionRequestOptions) => Promise<TagType>;
    updateTagAdapter: (adapter: (input: unknown, options?: TagAdapterOptions) => any) => void;
    updateTagAdapterOptions: (options: TagAdapterOptions) => void;
}
export declare const createTagActions: (flux: FluxFramework, options?: TagActionsOptions) => TagActions;
