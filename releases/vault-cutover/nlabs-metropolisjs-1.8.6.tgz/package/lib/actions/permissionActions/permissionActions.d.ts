import type { BaseAdapterOptions } from '../../utils/validatorFactory.js';
import type { FluxFramework } from '@nlabs/arkhamjs';
import type { Permission } from '../../adapters/permissionAdapter/permissionAdapter.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface PermissionAdapterOptions extends BaseAdapterOptions {
}
export interface PermissionActionsOptions {
    permissionAdapter?: (input: unknown, options?: PermissionAdapterOptions) => any;
    permissionAdapterOptions?: PermissionAdapterOptions;
}
export type PermissionApiResultsType = {
    permissions: {
        add?: Permission;
        check?: boolean;
        itemById?: Permission;
        list?: Permission[];
        listByUser?: Permission[];
        remove?: Permission;
        update?: Permission;
    };
};
export interface PermissionActions {
    add: (permissionData: Partial<Permission>, permissionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<Permission>;
    check: (userId: string, resource: string, requiredLevel: number, requestOptions?: ActionRequestOptions) => Promise<boolean>;
    itemById: (permissionId: string, permissionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<Permission>;
    list: (from?: number, to?: number, permissionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<Permission[]>;
    listByUser: (userId: string, permissionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<Permission[]>;
    remove: (permissionId: string, requestOptions?: ActionRequestOptions) => Promise<Permission>;
    update: (permission: Partial<Permission>, permissionProps?: string[], requestOptions?: ActionRequestOptions) => Promise<Permission>;
    updatePermissionAdapter: (adapter: (input: unknown, options?: PermissionAdapterOptions) => any) => void;
    updatePermissionAdapterOptions: (options: PermissionAdapterOptions) => void;
}
export declare const createPermissionActions: (flux: FluxFramework, options?: PermissionActionsOptions) => PermissionActions;
