import type { FluxFramework } from '@nlabs/arkhamjs';
import type { ConversationType } from '../../adapters/conversationAdapter/conversationAdapter.js';
import type { BaseAdapterOptions } from '../../utils/validatorFactory.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface ConversationAdapterOptions extends BaseAdapterOptions {
}
export interface ConversationActionsOptions {
    conversationAdapter?: (input: unknown, options?: ConversationAdapterOptions) => any;
    conversationAdapterOptions?: ConversationAdapterOptions;
}
export type ConversationApiResultsType = {
    conversations: {
        add?: ConversationType;
        itemById?: ConversationType;
        list?: ConversationType[];
        remove?: ConversationType;
        update?: ConversationType;
    };
};
export interface ConversationActions {
    add: (conversationData: Partial<ConversationType>, conversationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ConversationType>;
    delete: (conversationId: string, conversationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ConversationType>;
    itemById: (conversationId: string, conversationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ConversationType>;
    list: (from?: number, to?: number, conversationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ConversationType[]>;
    update: (conversation: Partial<ConversationType>, conversationProps?: string[], requestOptions?: ActionRequestOptions) => Promise<ConversationType>;
    updateConversationAdapter: (adapter: (input: unknown, options?: ConversationAdapterOptions) => any) => void;
    updateConversationAdapterOptions: (options: ConversationAdapterOptions) => void;
}
export declare const createConversationActions: (flux: FluxFramework, options?: ConversationActionsOptions) => ConversationActions;
