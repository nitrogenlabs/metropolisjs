/**
 * Copyright (c) 2019-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import type { FluxFramework } from '@nlabs/arkhamjs';
import type { ConversationType } from '../../adapters/conversationAdapter/conversationAdapter.js';
import type { MessageType } from '../../adapters/messageAdapter/messageAdapter.js';
import type { ActionRequestOptions } from '../../utils/requestCache.js';
export interface MessageAdapterOptions {
    strict?: boolean;
    allowPartial?: boolean;
    environment?: 'development' | 'production' | 'test';
    customValidation?: (input: unknown) => unknown;
}
export interface MessageActionsOptions {
    messageAdapter?: (input: unknown, options?: MessageAdapterOptions) => any;
    messageAdapterOptions?: MessageAdapterOptions;
}
export type MessageApiResultsType = {
    messages?: {
        addMessage?: MessageType;
        conversations?: ConversationType[];
        directConversation?: ConversationType;
        getMessage?: MessageType;
        getMessages?: MessageType[];
        getConversations?: ConversationType[];
    };
};
export interface MessageActions {
    sendMessage: (message: Partial<MessageType>, messageProps?: string[], requestOptions?: ActionRequestOptions) => Promise<MessageType>;
    getDirectConversation: (userId: string, requestOptions?: ActionRequestOptions) => Promise<ConversationType>;
    getMessages: (conversationId: string, messageProps?: string[], requestOptions?: ActionRequestOptions) => Promise<MessageType[]>;
    getConversations: (from?: number, to?: number, requestOptions?: ActionRequestOptions) => Promise<ConversationType[]>;
    updateMessageAdapter: (adapter: (input: unknown, options?: MessageAdapterOptions) => any) => void;
    updateMessageAdapterOptions: (options: MessageAdapterOptions) => void;
}
export declare const createMessageActions: (flux: FluxFramework, options?: MessageActionsOptions) => MessageActions;
