import { PermissionLevel } from '../adapters/permissionAdapter/permissionAdapter.js';
export interface PermissionGuardProps {
    requiredLevel: PermissionLevel;
    resource?: string;
    fallback?: React.ReactNode;
    children: React.ReactNode;
}
export interface UsePermissionsReturn {
    userLevel: number;
    hasPermission: (requiredLevel: PermissionLevel) => boolean;
    isGuest: boolean;
    isUser: boolean;
    isModerator: boolean;
    isAdmin: boolean;
    isSuperAdmin: boolean;
    checkResource: (resource: string, requiredLevel: PermissionLevel) => boolean;
}
export declare const usePermissions: () => UsePermissionsReturn;
export declare const PermissionGuard: React.FC<PermissionGuardProps>;
export { PermissionLevel } from '../adapters/permissionAdapter/permissionAdapter.js';
export type { Permission } from '../adapters/permissionAdapter/permissionAdapter.js';
