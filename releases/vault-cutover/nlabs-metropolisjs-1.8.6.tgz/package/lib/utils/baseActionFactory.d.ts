import type { FluxFramework } from '@nlabs/arkhamjs';
import type { BaseAdapterOptions } from './validatorFactory.js';
export interface BaseActionOptions<T extends BaseAdapterOptions = BaseAdapterOptions> {
    adapter?: (input: unknown, options?: T) => any;
    adapterOptions?: T;
}
export declare const createBaseActions: <T extends BaseAdapterOptions>(flux: FluxFramework, defaultValidator: (input: unknown, options?: T) => any, options?: BaseActionOptions<T>) => {
    createMutationAction: <R = any>(mutationName: string, dataType: string, queryVariables: Record<string, any>, props: string[], successType: string, errorType: string, mutationFn: any) => (input?: unknown) => Promise<R>;
    createQueryAction: <R = any>(queryName: string, dataType: string, queryVariables: Record<string, any>, props: string[], successType: string, errorType: string, queryFn: any) => () => Promise<R>;
    flux: FluxFramework;
    updateAdapter: (adapter: (input: unknown, options?: T) => any) => void;
    updateOptions: (options: T) => void;
    updateAdapterOptions: (options: T) => void;
    validator: (input: unknown, validatorOptions?: T) => any;
};
