/**
 * Copyright (c) 2026-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import type { FluxAction, FluxFramework } from '@nlabs/arkhamjs';
type CacheRecord = Record<string, any>;
export interface CacheIngestionOptions {
    readonly replace?: boolean;
}
type CacheAction = CacheRecord & CacheIngestionOptions;
export declare const mergeCachedRecord: <T>(previous: unknown, incoming: T, replace?: boolean) => T;
export declare const cachedAction: (flux: FluxFramework, action: FluxAction) => FluxAction;
export declare const readCachedResponse: <T>(flux: FluxFramework, scope: string, data: T) => T | undefined;
export declare const withCacheIngestion: <S extends object, D = CacheAction>(name: string, reducer: (type: string, data: D, state: S) => S, initialState: S) => ((type: string, data?: CacheAction, state?: S) => S);
export {};
