import type { ComplexTranslations, SimpleTranslations } from '../index.js';
export declare const buildI18nResources: (translations: ComplexTranslations) => Record<string, Record<string, Record<string, string>>>;
export declare const buildSimpleI18nResources: (translations: SimpleTranslations) => Record<string, Record<string, Record<string, string>>>;
export declare const initI18n: (translations: SimpleTranslations | ComplexTranslations) => void;
export declare const updateI18nResources: (translations: ComplexTranslations) => void;
export declare const i18n: (key: string, params?: Record<string, any>, lng?: string, ns?: string) => string;
