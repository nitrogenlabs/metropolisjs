/**
 * Copyright (c) 2026-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import type { FluxFramework } from '@nlabs/arkhamjs';
import type { SessionType } from './api.js';
export { getRefreshWindowMinutes, normalizeSession, parseJwtExpiryMs, parseJwtIssuedMs } from '../session/sessionPolicy.js';
export declare const isValidSession: (session?: Record<string, unknown>) => boolean;
export declare const storeSession: (flux: FluxFramework, session?: Record<string, unknown>) => Promise<SessionType>;
export declare const readStoredSession: (flux: FluxFramework) => Promise<SessionType>;
export declare const clearPersistedSession: (flux: FluxFramework) => Promise<void>;
export declare const hydrateSessionFromStorage: (flux: FluxFramework) => Promise<SessionType>;
export declare const isLoggedIn: (flux: FluxFramework) => boolean;
