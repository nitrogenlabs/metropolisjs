/**
 * Copyright (c) 2012-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import { FluxFramework } from '@nlabs/arkhamjs';
import { parseLocation } from '../adapters/locationAdapter/locationAdapter.js';
import type { LocationType } from '../adapters/locationAdapter/locationAdapter.js';
export declare const autoCompleteLocation: (this: unknown, flux: FluxFramework, address: string, latitude?: number, longitude?: number, locationProps?: string[], CustomClass?: typeof parseLocation) => Promise<LocationType[]>;
export declare const searchLocations: (flux: FluxFramework, address: string, latitude?: number, longitude?: number, locationProps?: string[], CustomClass?: typeof parseLocation) => Promise<LocationType[]>;
