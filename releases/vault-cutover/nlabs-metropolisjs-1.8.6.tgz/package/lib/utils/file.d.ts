export declare const convertFileToUploadFile: (file: File, maxSize: number, maxBytes?: number) => Promise<File>;
export declare const convertFileToBase64: (file: File, maxSize: number, maxBytes?: number) => Promise<string>;
