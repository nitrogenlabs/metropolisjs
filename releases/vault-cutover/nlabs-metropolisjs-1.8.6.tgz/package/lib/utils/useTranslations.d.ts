export interface UseTranslationsOptions {
    readonly locale?: string;
    readonly namespace?: string;
    readonly autoProcess?: boolean;
    readonly processInterval?: number;
}
export interface UseTranslationsReturn {
    readonly t: (key: string, fallback?: string) => string;
    readonly hasTranslation: (key: string) => boolean;
    readonly queueTranslation: (key: string) => void;
    readonly processPending: () => Promise<void>;
    readonly isLoading: boolean;
    readonly error: Error | null;
}
export declare const useTranslations: (options?: UseTranslationsOptions) => UseTranslationsReturn;
