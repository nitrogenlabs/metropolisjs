import { FluxFramework } from '@nlabs/arkhamjs';
import type { HunterOptionsType } from '@nlabs/rip-hunter';
import type { WebSessionEndReason, WebSessionIdentity, WebSessionScope } from '../session/webSessionPolicy.js';
export interface WebSessionOptions {
    readonly endpoints: {
        readonly activity: string;
        readonly restore: string;
        readonly signIn: string;
        readonly signOut: string;
    };
    /** Longest idle window the server may grant, in ms (default 1 hour, max 24 hours). Must match Reaktor's idleMs. */
    readonly idleMs?: number;
    readonly onBeforeSessionClear?: (reason: WebSessionEndReason, previous: WebSessionIdentity, scope: WebSessionScope) => void;
    readonly scope: WebSessionScope;
}
/** Supply one identifier; username accepts a username or email through Reaktor. */
export type WebSessionCredentials = {
    readonly password: string;
} & ({
    readonly email: string;
    readonly username?: never;
} | {
    readonly email?: never;
    readonly username: string;
});
export interface WebSessionActions {
    dispose(): void;
    ensureSession(): Promise<WebSessionIdentity>;
    recordActivity(): Promise<WebSessionIdentity>;
    restore(): Promise<WebSessionIdentity | undefined>;
    signIn(user: WebSessionCredentials): Promise<WebSessionIdentity>;
    signOut(): Promise<{
        readonly remote: 'revoked' | 'unknown';
    }>;
}
export interface WebSessionRuntime {
    readonly acquire: () => () => void;
    readonly actions: WebSessionActions;
    readonly generation: () => number;
    readonly isAuthenticated: () => boolean;
    readonly options: WebSessionOptions;
    readonly rejectSession: () => Promise<void>;
}
export declare const mutateWebSession: (flux: FluxFramework, operation: () => Promise<unknown>) => Promise<unknown>;
export declare const getWebSessionRuntime: (flux: FluxFramework) => WebSessionRuntime | undefined;
export declare const bindWebSessionRuntime: (flux: FluxFramework, runtime: WebSessionRuntime) => void;
export declare const removeWebSessionRuntime: (flux: FluxFramework, runtime: WebSessionRuntime) => void;
/** Capture configuration once. URL authority comes from the browser, never input. */
export declare const captureWebSessionOptions: (options: WebSessionOptions) => WebSessionOptions;
export declare const assertWebSessionEndpoint: (endpoint: string) => void;
export declare const sameWebSessionOptions: (left: WebSessionOptions, right: WebSessionOptions) => boolean;
/** Overwrite credential policy, preserving unrelated caller headers only. */
export declare const webSessionRequestOptions: (url: string, method: string, options?: HunterOptionsType) => HunterOptionsType;
/** Known synchronous browser adapter, zero debounce, nonexpiring marker-only state. */
export declare const createWebSessionMarker: (scope: WebSessionScope) => {
    read: () => Promise<boolean>;
    write: (suppressed: boolean) => Promise<void>;
};
