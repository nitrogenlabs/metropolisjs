export interface ColumnSize {
    readonly columns: number;
    readonly size: number;
}
export declare const getColumnSize: (width: number, maxItemWidth: number, containerPadding?: number) => ColumnSize;
export declare const isExpired: (expires: number, limitInMin: number) => boolean;
