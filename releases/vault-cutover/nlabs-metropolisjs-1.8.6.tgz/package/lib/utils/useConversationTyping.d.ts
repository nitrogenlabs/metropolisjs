type TypingUser = {
    readonly imageUrl?: string;
    readonly name?: string;
    readonly personaId?: string;
    readonly thumbUrl?: string;
    readonly userId?: string;
    readonly username?: string;
};
export type ConversationTypingOptions = {
    readonly name?: string;
    readonly personaId?: string;
    readonly userId?: string;
    readonly username?: string;
    readonly users?: TypingUser[];
};
export type UseConversationTypingOptions = {
    readonly debounceMs?: number;
    readonly idleMs?: number;
};
export declare const useConversationTyping: ({ debounceMs, idleMs }?: UseConversationTypingOptions) => {
    setConversation: (conversationId: string, options?: ConversationTypingOptions) => void;
    stopTyping: (conversationId?: string, options?: ConversationTypingOptions) => void;
    syncDraft: (conversationId: string, draft: string, options?: ConversationTypingOptions) => void;
};
export {};
