/**
 * Copyright (c) 2019-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
export interface BaseAdapterOptions {
    strict?: boolean;
    allowPartial?: boolean;
    environment?: 'development' | 'production' | 'test';
    customValidation?: (input: unknown) => unknown;
}
/**
 * Creates a validator factory that merges custom adapters with default behavior.
 * This eliminates code duplication across all action files.
 *
 * @param defaultValidator - The default validation function
 * @param customAdapter - Optional custom adapter function
 * @param options - Adapter options
 * @returns A validator function that applies default + custom validation
 *
 * @example
 * const validateUser = createValidatorFactory(
 *   defaultUserValidator,
 *   customUserAdapter,
 *   userAdapterOptions
 * );
 */
export declare const createValidatorFactory: <T extends BaseAdapterOptions>(defaultValidator: (input: unknown, options?: T) => any, customAdapter?: (input: unknown, options?: T) => any, options?: T) => (input: unknown, validatorOptions?: T) => any;
/**
 * Creates a validator manager that handles adapter updates and recreation.
 * This centralizes the update logic that's duplicated across action files.
 *
 * @param defaultValidator - The default validation function
 * @param initialOptions - Initial adapter options
 * @returns An object with validator and update functions
 *
 * @example
 * const { validator, updateAdapter, updateOptions } = createValidatorManager(
 *   defaultUserValidator,
 *   userAdapterOptions
 * );
 */
export declare const createValidatorManager: <T extends BaseAdapterOptions>(defaultValidator: (input: unknown, options?: T) => any, initialOptions?: T) => {
    getCustomAdapter: () => (input: unknown, options?: T) => any;
    getOptions: () => T;
    updateAdapter: (adapter: (input: unknown, options?: T) => any) => void;
    updateOptions: (options: T) => void;
    validator: (input: unknown, validatorOptions?: T) => any;
};
