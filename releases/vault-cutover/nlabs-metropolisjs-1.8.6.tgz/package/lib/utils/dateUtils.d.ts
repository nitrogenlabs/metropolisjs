import { DateTime } from 'luxon';
export declare const parseDateTime: (value: string | number | DateTime) => number;
