import type { FluxFramework } from '@nlabs/arkhamjs';
import type { MetropolisEnvironmentConfiguration } from '../config/index.js';
import type { ActionType } from '../utils/actionFactory.js';
import type { WebSessionActions } from './webSessionRuntime.js';
export declare const useWebSessionActions: () => WebSessionActions;
/**
 * Main hook to access Metropolis actions.
 *
 * @param actionTypes - Action types to create.
 * @returns Object containing the requested actions
 *
 * @example
 * ```tsx
 * const {userActions} = useMetropolis(['user']);
 * const {userActions, postActions} = useMetropolis(['user', 'post']);
 * ```
 */
export declare const useMetropolis: <T extends ActionType[]>(actionTypes: T) => Record<string, any>;
/**
 * Hook to access the Metropolis configuration from context.
 *
 * @returns The resolved environment-specific configuration
 * @throws Error if used outside of Metropolis component
 *
 * @example
 * ```tsx
 * const config = useMetropolisConfig();
 * const apiUrl = config.app?.api?.url;
 * ```
 */
export declare const useMetropolisConfig: () => MetropolisEnvironmentConfiguration;
/**
 * Hook to access the Flux framework instance from context.
 *
 * @returns The Flux framework instance
 * @throws Error if used outside of Metropolis component and no Flux available
 *
 * @example
 * ```tsx
 * const flux = useMetropolisFlux();
 * const state = flux.getState('user.session');
 * ```
 */
export declare const useMetropolisFlux: () => FluxFramework;
/**
 * Specialized hooks for individual action types.
 * These hooks only create the specific action type, improving performance.
 */
export declare const useContentActions: () => any;
export declare const useAwsRum: () => any;
export declare const useCrmActions: () => any;
export declare const useEventActions: () => any;
export declare const useGroupActions: () => any;
export declare const useHiggsfieldActions: () => any;
export declare const useImageActions: () => any;
export declare const useLocationActions: () => any;
export declare const useMessageActions: () => any;
export declare const useSubscriptionActions: () => any;
export declare const usePermissionActions: () => any;
export declare const usePostActions: () => any;
export declare const usePersonaActions: () => any;
export declare const useReactionActions: () => any;
export declare const useRestActions: () => any;
export declare const useTagActions: () => any;
export declare const useVideoActions: () => any;
export declare const useTranslationActions: () => any;
export declare const useUserActions: () => any;
export declare const useWebsocketActions: () => any;
