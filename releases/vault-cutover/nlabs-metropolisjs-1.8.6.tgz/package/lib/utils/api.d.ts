/**
 * Copyright (c) 2022-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import type { FluxAction, FluxFramework } from '@nlabs/arkhamjs';
import type { HunterOptionsType, HunterQueryType } from '@nlabs/rip-hunter';
export interface ApiOptions {
    readonly queueOffline?: boolean;
    readonly onSuccess?: (data: any) => Promise<FluxAction | null>;
    readonly variables?: Record<string, unknown>;
}
export type RestMethod = 'DELETE' | 'GET' | 'PATCH' | 'POST' | 'PUT' | (string & {});
export interface RestApiOptions extends HunterOptionsType {
    readonly queueOffline?: boolean;
    readonly authenticate?: boolean;
    readonly onSuccess?: (data: any) => any;
}
export type ReaktorDbCollection = 'apps' | 'assistant' | 'connections' | 'contents' | 'conversations' | 'crm' | 'events' | 'files' | 'groups' | 'higgsfield' | 'images' | 'locations' | 'messages' | 'nativePush' | 'notifications' | 'payments' | 'permissions' | 'posts' | 'personas' | 'reactions' | 'rum' | 'subscriptions' | 'tags' | 'translations' | 'users' | 'videos';
export interface ApiQueryVariableType {
    readonly type: string;
    readonly value: unknown;
}
export interface ApiQueryVariables {
    readonly [key: string]: ApiQueryVariableType;
}
export interface ApiResultsType {
    readonly [key: string]: unknown;
}
export interface RetryType {
    readonly query?: HunterQueryType | HunterQueryType[];
    readonly request?: {
        readonly method: string;
        readonly params?: unknown;
        readonly url: string;
    };
    readonly responseMethod: (results: ApiResultsType) => void;
}
export interface SessionType {
    readonly expires?: number;
    readonly issued?: number;
    readonly token?: string;
    readonly userId?: string;
    readonly username?: string;
}
export declare const getGraphql: (flux: FluxFramework, url: string, authenticate: boolean, query: HunterQueryType | HunterQueryType[], options: ApiOptions) => Promise<ApiResultsType | null>;
export declare const resolveRestEndpoint: (flux: FluxFramework, endpoint: string) => string;
export declare const restRequest: <T = ApiResultsType>(flux: FluxFramework, endpoint: string, method?: RestMethod, params?: unknown, options?: RestApiOptions) => Promise<T>;
export declare const createQuery: (name: string, dataType: ReaktorDbCollection, variables?: ApiQueryVariables, returnProperties?: string[], type?: string) => {
    query: string;
    variables: Record<string, unknown>;
};
export declare const createMutation: (name: string, dataType: ReaktorDbCollection, variables?: ApiQueryVariables, returnProperties?: string[]) => {
    query: string;
    variables: Record<string, unknown>;
};
export declare const appQuery: <T>(flux: FluxFramework, name: string, dataType: ReaktorDbCollection, queryVariables: ApiQueryVariables, returnProperties: string[], options?: ApiOptions) => Promise<T>;
export declare const appMutation: <T>(flux: FluxFramework, name: string, dataType: ReaktorDbCollection, queryVariables: ApiQueryVariables, returnProperties: string[], options?: ApiOptions) => Promise<T>;
export declare const publicQuery: <T>(flux: FluxFramework, name: string, dataType: ReaktorDbCollection, queryVariables: ApiQueryVariables, returnProperties: string[], options?: ApiOptions) => Promise<T>;
export declare const publicMutation: <T>(flux: FluxFramework, name: string, dataType: ReaktorDbCollection, queryVariables: ApiQueryVariables, returnProperties: string[], options?: ApiOptions) => Promise<T>;
export declare const rumMutation: <T>(flux: FluxFramework, name: string, dataType: ReaktorDbCollection, queryVariables: ApiQueryVariables, returnProperties: string[], options?: ApiOptions) => Promise<T>;
export declare const rumRequest: <T>(flux: FluxFramework, batch: Record<string, unknown>, options?: RestApiOptions) => Promise<T>;
/**
 * Attempts terminal RUM delivery with the Beacon API.
 *
 * Returns false when beacon delivery is unavailable or declined so callers
 * can fall back to the standard request transport.
 */
export declare const rumBeaconRequest: (flux: FluxFramework, batch: Record<string, unknown>) => boolean;
export declare const uploadImage: (flux: FluxFramework, image: FormData | Record<string, unknown>, options?: HunterOptionsType) => Promise<ApiResultsType>;
export declare const refreshSession: (flux: FluxFramework, token?: string, expires?: number) => Promise<FluxAction | null>;
