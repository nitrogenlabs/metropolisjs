import type { FluxFramework } from '@nlabs/arkhamjs';
import type { MetropolisEnvironmentConfiguration } from '../config/index.js';
/**
 * Gets configuration from flux state.
 * Falls back to default config if not found in flux state.
 *
 * @param flux - The Flux framework instance
 * @returns The resolved environment configuration
 */
export declare const getConfigFromFlux: (flux: FluxFramework) => MetropolisEnvironmentConfiguration;
