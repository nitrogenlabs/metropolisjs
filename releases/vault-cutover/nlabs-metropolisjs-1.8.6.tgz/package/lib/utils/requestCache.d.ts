/**
 * Copyright (c) 2026-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import type { FluxFramework } from '@nlabs/arkhamjs';
export interface ActionRequestOptions {
    readonly cacheTimeout?: number;
}
export declare const getCachedRequest: <T>(flux: FluxFramework, scope: string, payload?: Record<string, unknown>, options?: ActionRequestOptions) => T | undefined;
export declare const setCachedRequest: <T>(flux: FluxFramework, scope: string, payload: Record<string, unknown>, data: T, options?: ActionRequestOptions) => Promise<T>;
export declare const clearCachedRequest: (flux: FluxFramework, scope: string) => Promise<void>;
