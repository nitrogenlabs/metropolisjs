/**
 * Copyright (c) 2021-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
export declare const MetropolisConstants: {
    INITIALIZE: string;
    LOADING: string;
    SIGNOUT: string;
    SUBSCRIBE_MESSAGES: string;
    SUBSCRIBE_NOTIFICATIONS: string;
    UPDATE_MESSAGES: string;
    UPDATE_NOTIFICATIONS: string;
    UPDATE_SESSION: string;
};
