/**
 * Copyright (c) 2024-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
export declare const COLLECTIONS: {
    readonly APPS: 'apps';
    readonly CONVERSATIONS: 'conversations';
    readonly CUSTOMER_NOTIFICATIONS: 'customerNotifications';
    readonly CUSTOMER_ORDERS: 'customerOrders';
    readonly FILES: 'files';
    readonly GROUPS: 'groups';
    readonly IMAGES: 'images';
    readonly MAILING_LISTS: 'mailingLists';
    readonly MESSAGES: 'messages';
    readonly POSTS: 'posts';
    readonly PERSONAS: 'personas';
    readonly SHOPIFY_PRODUCTS: 'shopifyProducts';
    readonly SHOPIFY_WEBHOOK_EVENTS: 'shopifyWebhookEvents';
    readonly SUPPORT_TICKET_EVENTS: 'supportTicketEvents';
    readonly SUPPORT_TICKET_MESSAGES: 'supportTicketMessages';
    readonly SUPPORT_TICKETS: 'supportTickets';
    readonly TAGS: 'tags';
    readonly USERS: 'users';
    readonly VIDEOS: 'videos';
};
export type CollectionType = typeof COLLECTIONS[keyof typeof COLLECTIONS];
export declare const EDGES: {
    readonly HAS_CONNECTION: 'hasConnection';
    readonly HAS_CONVERSATION: 'hasConversation';
    readonly HAS_CUSTOMER_NOTIFICATION: 'hasCustomerNotification';
    readonly HAS_CUSTOMER_ORDER: 'hasCustomerOrder';
    readonly HAS_FILE: 'hasFile';
    readonly HAS_MEDIA: 'hasMedia';
    readonly HAS_MAILING_LIST: 'hasMailingList';
    readonly HAS_PERSONA: 'hasPersona';
    readonly HAS_PURCHASED_PRODUCT: 'hasPurchasedProduct';
    readonly HAS_REACTION: 'hasReaction';
    readonly HAS_SUPPORT_TICKET: 'hasSupportTicket';
    readonly HAS_SUPPORT_TICKET_EVENT: 'hasSupportTicketEvent';
    readonly HAS_SUPPORT_TICKET_MESSAGE: 'hasSupportTicketMessage';
    readonly IS_TAGGED: 'isTagged';
};
export type EdgeType = typeof EDGES[keyof typeof EDGES];
export declare const CONNECTION_TYPES: {
    readonly ADMIN: 'admin';
    readonly BLOCKED: 'blocked';
    readonly FOLLOWER: 'follower';
    readonly FOLLOWING: 'following';
    readonly MEMBER: 'member';
};
export type ConnectionType = typeof CONNECTION_TYPES[keyof typeof CONNECTION_TYPES];
export declare const REACTION_TYPES: {
    readonly DISLIKE: 'dislike';
    readonly LIKE: 'like';
    readonly PIN: 'pin';
    readonly RSVP: 'rsvp';
    readonly VIEW: 'view';
};
export type ReactionType = typeof REACTION_TYPES[keyof typeof REACTION_TYPES];
