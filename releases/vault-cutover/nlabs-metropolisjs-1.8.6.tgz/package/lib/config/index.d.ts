import type { MetropolisAdapters } from '../utils/MetropolisContext.js';
export interface ConfigAppSessionType {
    autoRefresh?: boolean;
    readonly maxMinutes?: number;
    readonly minMinutes?: number;
    readonly refreshAfterRatio?: number;
}
export interface ConfigAppUrls {
    readonly websocket?: string;
}
export interface ConfigAppApiType {
    readonly endpoints?: Record<string, string>;
    readonly public?: string;
    readonly rum?: string;
    readonly url?: string;
    readonly uploadImage?: string;
}
export interface ConfigAppType {
    readonly api?: ConfigAppApiType;
    readonly name?: string;
    readonly rum?: {
        readonly analyticsId?: string;
        readonly analyticsTransport?: 'graphql' | 'websocket';
        readonly debounceMs?: number;
        readonly dedupeMs?: number;
        readonly enabled?: boolean;
        readonly respectPrivacySignals?: boolean;
        readonly throttleMs?: number;
    };
    readonly session?: ConfigAppSessionType;
    readonly urls?: ConfigAppUrls;
    readonly version?: string;
}
export interface MetropolisConfiguration {
    readonly [environment: string]: MetropolisEnvironmentConfiguration | undefined;
    readonly local?: MetropolisEnvironmentConfiguration;
    readonly development?: MetropolisEnvironmentConfiguration;
    readonly production?: MetropolisEnvironmentConfiguration;
    readonly test?: MetropolisEnvironmentConfiguration;
}
export interface MetropolisEnvironmentConfiguration {
    readonly adapters?: MetropolisAdapters;
    readonly app?: Partial<ConfigAppType>;
    readonly environment?: string;
    readonly isAuth?: () => boolean;
}
/**
 * Gets the default configuration for a specific environment.
 */
export declare const getDefaultConfig: (environment?: string) => MetropolisEnvironmentConfiguration;
/**
 * Resolves the environment-specific configuration from a MetropolisConfiguration object.
 * This function determines which environment to use based on process.env and merges
 * the appropriate configuration.
 */
export declare const resolveEnvironmentConfig: (config: MetropolisConfiguration, environment?: string) => MetropolisEnvironmentConfiguration;
