export declare const MessageUpdate = "mutate MessageUpdate($message: MessageInput) {\n  onUpdateMessage(message: $message) {\n    added\n    content\n    from\n    modified\n    to\n  }\n}";
export declare const MessageSubscription = "subscription MessageSubscription {\n  onUpdateMessage(message: $message) {\n    added\n    content\n    from\n    modified\n    to\n  }\n}";
