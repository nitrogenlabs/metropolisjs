export interface NativeCredentialEnvelope {
    readonly schemaVersion: 1;
    readonly environment: string;
    readonly userId: string;
    readonly token: string;
    readonly issued: number;
    readonly expires: number;
    readonly sid: string;
    readonly username: string;
}
/** JWT decoding is only an untrusted time hint, never signature verification. */
export declare const parseCredentialEnvelope: (value: unknown, environment: string, now: number) => NativeCredentialEnvelope | undefined;
