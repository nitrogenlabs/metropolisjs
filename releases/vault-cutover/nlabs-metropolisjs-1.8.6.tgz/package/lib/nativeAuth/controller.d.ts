import type { FluxFramework } from '@nlabs/arkhamjs';
import type { NativeApi } from '../api/index.js';
import type { NativeCredentialEnvelope } from './envelope.js';
export type NativeAuthErrorCode = 'configuration' | 'disposed' | 'stale' | 'invalid_session' | 'storage' | 'durable_cleanup';
export declare class NativeAuthError extends Error {
    readonly code: NativeAuthErrorCode;
    constructor(code: NativeAuthErrorCode);
}
/** Both ports must use Arkham ordered storage; promises reject on failure. No plaintext credential projection. */
export interface NativeSessionPersistence {
    available(): Promise<boolean>;
    read(): Promise<unknown>;
    write(envelope: NativeCredentialEnvelope): Promise<void>;
    clear(): Promise<void>;
    readMarker(): Promise<unknown>;
    writeMarker(marker: {
        readonly schemaVersion: 1;
        readonly environment: string;
        readonly userId?: string;
    }): Promise<void>;
    clearMarker(): Promise<void>;
}
export interface NativeAuthOptions {
    readonly api: NativeApi;
    readonly environment: string;
    readonly mode: 'hosted';
    readonly flux: FluxFramework;
    readonly storage: NativeSessionPersistence;
    /** Synchronously removes account-scoped caches and active outbox binding before events. */
    readonly invalidateAccount: () => void;
    readonly now?: () => number;
}
export interface SignOutResult {
    readonly durable: boolean;
    readonly remote: 'revoked' | 'may_remain_active' | 'no_session';
}
export interface NativeAuthController {
    signIn(user: {
        readonly email: string;
        readonly password: string;
    }): Promise<NativeCredentialEnvelope>;
    restore(): Promise<NativeCredentialEnvelope | undefined>;
    ensureAccessToken(): Promise<string>;
    onForeground(): Promise<string>;
    signOut(): Promise<SignOutResult>;
    dispose(): Promise<void>;
}
export declare const createNativeAuthController: (options: NativeAuthOptions) => NativeAuthController;
