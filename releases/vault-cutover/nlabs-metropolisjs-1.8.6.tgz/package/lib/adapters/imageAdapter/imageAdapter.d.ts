export interface ImageType {
    _id?: string;
    _key?: string;
    _rev?: string;
    _oldRev?: string;
    _from?: string;
    _to?: string;
    base64?: string;
    bucket?: string;
    color?: string;
    description?: string;
    file?: File;
    id?: string;
    imageId?: string;
    height?: number;
    itemId?: string;
    itemType?: string;
    model?: string;
    make?: string;
    privacy?: string;
    s3Options?: any;
    taken?: number;
    thumb?: string;
    fileType?: string;
    type?: string;
    url?: string;
    width?: number;
    name?: string;
    [key: string]: any;
}
export declare class ImageValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateImageInput: (image: unknown) => ImageType;
export declare const formatImageOutput: (image: ImageType) => ImageType;
export declare const parseImage: (image: ImageType) => ImageType;
