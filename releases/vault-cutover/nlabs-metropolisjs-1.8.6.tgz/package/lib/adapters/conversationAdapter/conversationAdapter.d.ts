export interface ConversationType {
    _id?: string;
    _key?: string;
    _rev?: string;
    _oldRev?: string;
    _from?: string;
    _to?: string;
    added?: number;
    conversationId?: string;
    id?: string;
    isDirect?: boolean;
    modified?: number;
    name?: string;
    users?: any[];
    [key: string]: any;
}
export declare class ConversationValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateConversationInput: (conversation: unknown) => ConversationType;
export declare const formatConversationOutput: (conversation: ConversationType) => ConversationType;
export declare const parseConversation: (conversation: ConversationType) => ConversationType;
