export interface FileType {
    _from?: string;
    _id?: string;
    _key?: string;
    _oldRev?: string;
    _rev?: string;
    _to?: string;
    base64?: string;
    buffer?: any;
    description?: string;
    fileId?: string;
    fileSize?: number;
    fileType?: string;
    id?: string;
    itemId?: string;
    itemType?: string;
    name?: string;
    url?: string;
    userId?: string;
    [key: string]: any;
}
export declare class FileValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateFileInput: (file: unknown) => FileType;
export declare const formatFileOutput: (file: FileType) => FileType;
export declare const getFileType: (file: FileType) => string;
export declare const parseFile: (file: FileType) => FileType;
