export interface PostType {
    _id?: string;
    _key?: string;
    _rev?: string;
    _oldRev?: string;
    _from?: string;
    _to?: string;
    content?: string;
    endDate?: number;
    files?: any[];
    groupId?: string;
    id?: string;
    latitude?: number;
    location?: string;
    longitude?: number;
    name?: string;
    parentId?: string;
    postId?: string;
    privacy?: string;
    startDate?: number;
    tags?: any[];
    type?: string;
    userId?: string;
    [key: string]: any;
}
export declare class PostValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validatePostInput: (post: unknown) => PostType;
export declare const formatPostOutput: (post: PostType) => PostType;
export declare const parsePost: (post: PostType) => PostType;
