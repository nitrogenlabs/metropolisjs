export interface PersonaType {
    _id?: string;
    _key?: string;
    _rev?: string;
    _oldRev?: string;
    _from?: string;
    _to?: string;
    active?: boolean;
    afterglow?: number;
    birthdate?: number;
    followerCount?: number;
    followingCount?: number;
    gender?: string;
    hasLike?: boolean;
    hasView?: boolean;
    id?: string;
    images?: any[];
    imageCount?: number;
    imageId?: string;
    imageUrl?: string;
    isBlocked?: boolean;
    isFollowedBy?: boolean;
    isFollowing?: boolean;
    isFriend?: boolean;
    latitude?: number;
    location?: string;
    longitude?: number;
    likeCount?: number;
    name?: string;
    personaId?: string;
    tags?: any[];
    thumbUrl?: string;
    userId?: string;
    viewCount?: number;
    [key: string]: any;
}
export declare class PersonaValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validatePersonaInput: (persona: unknown) => PersonaType;
export declare const formatPersonaOutput: (persona: PersonaType) => PersonaType;
export declare const parsePersona: (persona: PersonaType) => PersonaType;
