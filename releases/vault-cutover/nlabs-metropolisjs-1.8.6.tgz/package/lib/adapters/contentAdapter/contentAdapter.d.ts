export interface ContentType {
    _id?: string;
    _key?: string;
    contentId?: string;
    id?: string;
    key: string;
    locale: 'en' | 'es' | 'fr' | 'de' | 'pt' | 'it';
    content: string;
    description?: string;
    category?: string;
    isActive?: boolean;
    userId?: string;
    [key: string]: any;
}
export interface ContentInputType {
    contentId?: string;
    key: string;
    locale?: 'en' | 'es' | 'fr' | 'de' | 'pt' | 'it';
    content: string;
    description?: string;
    category?: string;
    isActive?: boolean;
    [key: string]: any;
}
export declare class ContentValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const parseContent: (content: ContentType) => ContentType;
export declare const parseContentInput: (content: ContentInputType) => ContentInputType;
export declare const parseContentFromDb: (content: ContentType) => ContentType;
