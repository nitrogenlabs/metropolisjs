export interface SessionType {
    _id?: string;
    _key?: string;
    _rev?: string;
    _oldRev?: string;
    _from?: string;
    _to?: string;
    expires?: number;
    id?: string;
    issued?: number;
    sessionId?: string;
    token?: string;
    userId?: string;
    username?: string;
    [key: string]: any;
}
export declare class SessionValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateSessionInput: (session: unknown) => SessionType;
export declare const formatSessionOutput: (session: SessionType) => SessionType;
export declare const parseSession: (session: SessionType) => SessionType;
