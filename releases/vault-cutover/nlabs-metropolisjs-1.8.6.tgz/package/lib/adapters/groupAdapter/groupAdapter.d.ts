export interface Group {
    [key: string]: any;
    _id?: string;
    _key?: string;
    _rev?: string;
    _oldRev?: string;
    _from?: string;
    _to?: string;
    added?: number;
    description?: string;
    groupId?: string;
    id?: string;
    imageId?: string;
    name?: string;
    ownerId?: string;
    privacy?: string;
    tags?: any[];
    type?: string;
    updated?: number;
    userCount?: number;
}
export declare class GroupValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateGroupInput: (group: unknown) => Group;
export declare const parseGroup: (item: any) => Group;
