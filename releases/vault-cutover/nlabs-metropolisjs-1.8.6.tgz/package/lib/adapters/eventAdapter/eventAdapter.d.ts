export interface EventType {
    _id?: string;
    _key?: string;
    _rev?: string;
    _oldRev?: string;
    _from?: string;
    _to?: string;
    address?: string;
    cached?: number;
    content?: string;
    endDate?: number;
    eventId?: string;
    groupId?: string;
    id?: string;
    images?: any[];
    isGoing?: boolean;
    latitude?: number;
    location?: string | {
        address: string;
        latitude: number;
        longitude: number;
    };
    longitude?: number;
    mentions?: any[];
    modified?: number;
    name?: string;
    maxGuestsPerPersona?: number;
    postId?: string;
    reactions?: string[];
    rsvpCount?: number;
    startDate?: number;
    tags?: any[];
    ticketCostCents?: number;
    type?: string;
    user?: any;
    viewCount?: number;
    [key: string]: any;
}
export declare class EventValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateEventInput: (event: unknown) => EventType;
export declare const formatEventOutput: (event: EventType) => EventType;
export declare const parseEvent: (event: EventType) => EventType;
