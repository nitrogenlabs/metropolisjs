import { User } from '../../adapters/userAdapter/userAdapter.js';
export interface MessageType {
    readonly _id?: string;
    readonly _key?: string;
    readonly _rev?: string;
    readonly _oldRev?: string;
    readonly _from?: string;
    readonly _to?: string;
    readonly content?: string;
    readonly conversationId?: string;
    readonly files?: any[];
    readonly id?: string;
    readonly images?: any[];
    readonly itemId?: string;
    readonly itemType?: string;
    readonly messageId?: string;
    readonly personaId?: string;
    readonly read?: boolean;
    readonly saved?: boolean;
    readonly user?: User;
    readonly userId?: string;
    [key: string]: any;
}
export declare class MessageValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateMessageInput: (message: unknown) => MessageType;
export declare const formatMessageOutput: (message: MessageType) => MessageType;
export declare const parseMessage: (message: MessageType) => MessageType;
