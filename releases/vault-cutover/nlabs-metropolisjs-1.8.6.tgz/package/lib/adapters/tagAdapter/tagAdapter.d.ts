export interface TagType {
    _id?: string;
    _key?: string;
    category?: string;
    description?: string;
    id?: string;
    name?: string;
    tagBy?: string;
    tagId?: string;
    userId?: string;
    [key: string]: any;
}
export declare class TagValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateTagInput: (tag: unknown) => TagType;
export declare const formatTagOutput: (tag: TagType) => TagType;
export declare const parseTag: (tag: TagType) => TagType;
