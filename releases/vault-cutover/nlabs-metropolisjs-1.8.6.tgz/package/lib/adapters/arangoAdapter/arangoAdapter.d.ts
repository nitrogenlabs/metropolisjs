export interface DocumentType {
    _from?: string;
    _id?: string;
    _key?: string;
    _oldRev?: string;
    _rev?: string;
    _to?: string;
    added?: number;
    id?: string;
    modified?: number;
    [key: string]: any;
}
export declare class ArangoValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateDocumentInput: (doc: unknown) => DocumentType;
export declare const formatDocumentOutput: (doc: DocumentType) => DocumentType;
export declare const parseDocument: (doc: DocumentType) => DocumentType;
export declare const removeEmptyKeys: <T extends Record<string, any>>(obj: T) => T;
