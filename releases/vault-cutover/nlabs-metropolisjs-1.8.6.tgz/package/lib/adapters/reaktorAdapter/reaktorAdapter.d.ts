export declare class ReaktorValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateReaktorContent: (content?: string, length?: number) => string | undefined;
export declare const validateReaktorDate: (date?: number) => number | undefined;
export declare const validateReaktorItemId: (itemId?: string) => string | undefined;
export declare const validateReaktorName: (name?: string) => string | undefined;
export declare const validateReaktorType: (type?: string) => string | undefined;
export declare const validateReaktorUrl: (url?: string) => string | undefined;
export declare const parseReaktorContent: (content?: string, length?: number) => string | undefined;
export declare const parseReaktorDate: (date?: number) => number | undefined;
export declare const parseReaktorItemId: (itemId?: string) => string | undefined;
export declare const parseReaktorName: (name?: string) => string | undefined;
export declare const parseReaktorType: (type?: string) => string | undefined;
export declare const parseReaktorUrl: (url?: string) => string | undefined;
