import { type CollectionType } from '../../constants/Collections.js';
export interface ReactionType {
    _id?: string;
    _key?: string;
    _rev?: string;
    _oldRev?: string;
    _from?: string;
    _to?: string;
    id?: string;
    name?: string;
    reactionId?: string;
    type?: CollectionType;
    value?: string;
    [key: string]: any;
}
export declare class ReactionValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateReactionInput: (reaction: unknown) => ReactionType;
export declare const formatReactionOutput: (reaction: ReactionType) => ReactionType;
export declare const parseReaction: (reaction: ReactionType) => ReactionType;
