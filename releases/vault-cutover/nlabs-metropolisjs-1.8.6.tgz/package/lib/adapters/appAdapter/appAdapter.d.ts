import type { AppType } from '../../types/apps.types.js';
export declare class AppValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateAppInput: (app: unknown) => AppType;
export declare const parseApp: (app: AppType) => AppType;
