export declare enum PermissionLevel {
    GUEST = 0,
    USER = 1,
    MODERATOR = 2,
    ADMIN = 3,
    SUPER_ADMIN = 4
}
export declare const PermissionLevelNames: Record<PermissionLevel, string>;
export interface Permission {
    _id?: string;
    _key?: string;
    _rev?: string;
    _oldRev?: string;
    added?: number;
    description?: string;
    id?: string;
    level?: PermissionLevel;
    name?: string;
    permissionId?: string;
    resource?: string;
    roleId?: string;
    type?: string;
    updated?: number;
    userId?: string;
    [key: string]: any;
}
export declare class PermissionValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validatePermissionInput: (permission: unknown) => Permission;
export declare const formatPermissionOutput: (permission: Permission) => Permission;
export declare const parsePermission: (permission: Permission) => Permission;
export declare const hasPermission: (userLevel: number, requiredLevel: PermissionLevel) => boolean;
export declare const getPermissionLevelName: (level: number) => string;
export declare const isGuest: (userLevel: number) => boolean;
export declare const isUser: (userLevel: number) => boolean;
export declare const isModerator: (userLevel: number) => boolean;
export declare const isAdmin: (userLevel: number) => boolean;
export declare const isSuperAdmin: (userLevel: number) => boolean;
