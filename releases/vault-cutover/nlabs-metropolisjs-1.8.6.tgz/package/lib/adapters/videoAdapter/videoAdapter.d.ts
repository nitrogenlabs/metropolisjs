import type { VideoType } from '../../types/videos.types.js';
export declare class VideoValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateVideoInput: (video: unknown) => VideoType;
export declare const parseVideo: (video: VideoType) => VideoType;
