export interface LocationType {
    _id?: string;
    _key?: string;
    _rev?: string;
    _oldRev?: string;
    _from?: string;
    _to?: string;
    address?: string;
    city?: string;
    country?: string;
    id?: string;
    latitude?: number;
    location?: string;
    locationId?: string;
    longitude?: number;
    state?: string;
    street?: string;
    zip?: string;
    [key: string]: any;
}
export declare class LocationValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const validateLocationInput: (location: unknown) => LocationType;
export declare const formatLocationOutput: (location: LocationType) => LocationType;
export declare const parseLocation: (location: LocationType) => LocationType;
