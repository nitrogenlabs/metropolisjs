/**
 * Copyright (c) 2026-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import { z } from 'zod';
export declare class HiggsfieldValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
declare const SoulImageInputSchema: z.ZodObject<{
    aspectRatio: z.ZodOptional<z.ZodEnum<{
        "16:9": "16:9";
        "1:1": "1:1";
        "2:3": "2:3";
        "3:2": "3:2";
        "3:4": "3:4";
        "4:3": "4:3";
        "9:16": "9:16";
    }>>;
    batchSize: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<4>]>>;
    enhancePrompt: z.ZodOptional<z.ZodBoolean>;
    prompt: z.ZodString;
    resolution: z.ZodOptional<z.ZodEnum<{
        "1080p": "1080p";
        "720p": "720p";
    }>>;
    seed: z.ZodOptional<z.ZodNumber>;
    styleId: z.ZodOptional<z.ZodString>;
}, z.core.$loose>;
declare const SeedanceVideoInputSchema: z.ZodObject<{
    duration: z.ZodOptional<z.ZodNumber>;
    endImageUrl: z.ZodOptional<z.ZodString>;
    generateAudio: z.ZodOptional<z.ZodBoolean>;
    imageUrl: z.ZodString;
    outputFormat: z.ZodOptional<z.ZodEnum<{
        mov: "mov";
        mp4: "mp4";
    }>>;
    prompt: z.ZodOptional<z.ZodString>;
    resolution: z.ZodOptional<z.ZodEnum<{
        "480p": "480p";
        "720p": "720p";
    }>>;
}, z.core.$loose>;
declare const SeedanceReferenceVideoInputSchema: z.ZodObject<{
    aspectRatio: z.ZodEnum<{
        "16:9": "16:9";
        "1:1": "1:1";
        "21:9": "21:9";
        "3:4": "3:4";
        "4:3": "4:3";
        "9:16": "9:16";
    }>;
    audioUrls: z.ZodOptional<z.ZodArray<z.ZodString>>;
    duration: z.ZodOptional<z.ZodNumber>;
    generateAudio: z.ZodOptional<z.ZodBoolean>;
    imageUrls: z.ZodOptional<z.ZodArray<z.ZodString>>;
    outputFormat: z.ZodOptional<z.ZodEnum<{
        mov: "mov";
        mp4: "mp4";
    }>>;
    prompt: z.ZodOptional<z.ZodString>;
    resolution: z.ZodOptional<z.ZodEnum<{
        "480p": "480p";
        "720p": "720p";
    }>>;
    videoUrls: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$loose>;
declare const MarketingStudioImageInputSchema: z.ZodObject<{
    aspectRatio: z.ZodOptional<z.ZodEnum<{
        "16:9": "16:9";
        "1:1": "1:1";
        "21:9": "21:9";
        "2:3": "2:3";
        "3:2": "3:2";
        "3:4": "3:4";
        "4:3": "4:3";
        "9:16": "9:16";
        auto: "auto";
    }>>;
    enhancePrompt: z.ZodOptional<z.ZodBoolean>;
    imageUrls: z.ZodOptional<z.ZodArray<z.ZodString>>;
    presetId: z.ZodOptional<z.ZodString>;
    prompt: z.ZodString;
    quality: z.ZodOptional<z.ZodEnum<{
        high: "high";
        low: "low";
        medium: "medium";
    }>>;
    resolution: z.ZodOptional<z.ZodEnum<{
        "1k": "1k";
        "2k": "2k";
        "4k": "4k";
    }>>;
}, z.core.$loose>;
export type SoulImageInput = z.infer<typeof SoulImageInputSchema>;
export type SeedanceVideoInput = z.infer<typeof SeedanceVideoInputSchema>;
export type SeedanceReferenceVideoInput = z.infer<typeof SeedanceReferenceVideoInputSchema>;
export type MarketingStudioImageInput = z.infer<typeof MarketingStudioImageInputSchema>;
export interface HiggsfieldRequest {
    cancelUrl?: string;
    error?: string;
    mediaUrl?: string;
    mediaUrls?: string[];
    requestId?: string;
    status?: string;
    statusUrl?: string;
}
export declare const validateSoulImageInput: (input: unknown) => SoulImageInput;
export declare const validateSeedanceVideoInput: (input: unknown) => SeedanceVideoInput;
export declare const validateSeedanceReferenceVideoInput: (input: unknown) => SeedanceReferenceVideoInput;
export declare const validateMarketingStudioImageInput: (input: unknown) => MarketingStudioImageInput;
export {};
