export interface TranslationType {
    readonly key: string;
    readonly locale: string;
    readonly value: string;
    readonly namespace?: string;
    readonly timestamp?: number;
}
export interface TranslationInputType {
    readonly key: string;
    readonly locale: string;
    readonly value: string;
    readonly namespace?: string;
}
export declare class TranslationValidationError extends Error {
    field?: string;
    constructor(message: string, field?: string);
}
export declare const parseTranslation: (translation: TranslationType) => TranslationType;
export declare const parseTranslationInput: (translation: TranslationInputType) => TranslationInputType;
export declare const validateTranslationInput: (input: unknown) => TranslationInputType;
